<?php
    
Router::connect('/', array('controller' => 'index', 'action' => 'index'));
Router::connect('/index', array('controller' => 'index', 'action' => 'index'));
Router::connect('/index/:page', array('controller' => 'index', 'action' => 'index'), array('page' => '[0-9]+'));

// Page
Router::connect('/index/:page', array('controller' => 'index', 'action' => 'index'), array('page' => '[0-9]+'));
Router::connect('/page/*', array('controller' => 'page', 'action' => 'index'));

//nodes
Router::connect('/node-:id', array('controller' => 'node', 'action' => 'redirecttonode'), array('id' => '[0-9]+'));
Router::connect('/node-:id-:slug', array('controller' => 'node', 'action' => 'index'), array('id' => '[0-9]+', 'slug' => '(.)+'));

//items
Router::connect('/category/:type/:id', array('controller' => 'item', 'action' => 'index'), array('type' => '[a-zA-Z_]+', 'id' => '[0-9]+'));
Router::connect('/category/:type/:id-:page', array('controller' => 'item', 'action' => 'index'), array('type' => '[a-zA-Z_]+', 'id' => '[0-9]+', 'page' => '[0-9]+'));
Router::connect('/view/:id', array('controller' => 'item', 'action' => 'redirecttomainitem'), array('id' => '[0-9]+'));
Router::connect('/view/:id/:title', array('controller' => 'item', 'action' => 'view'), array('id' => '[0-9]+', 'title' => '(.)+'));
Router::connect('/print/:id', array('controller' => 'item', 'action' => 'printinfo'), array('id' => '[0-9]+'));


//pos
Router::connect('/branches', array('controller' => 'pos', 'action' => 'index'));
Router::connect('/branch-:id', array('controller' => 'pos', 'action' => 'view'), array('id' => '[0-9]+'));

//clients
Router::connect('/clients', array('controller' => 'sponser', 'action' => 'index'));
Router::connect('/partners', array('controller' => 'sponser', 'action' => 'index'));

//media
Router::connect('/albums', array('controller' => 'media', 'action' => 'albums'));
Router::connect('/album/:id', array('controller' => 'media', 'action' => 'index'), array('id' => '[0-9]+'));
Router::connect('/album/:id/:title', array('controller' => 'media', 'action' => 'index'), array('id' => '[0-9]+', 'title' => '(.)+'));
Router::connect('/album/:id-:page', array('controller' => 'media', 'action' => 'index'), array('page' => '[0-9]+'));

// Contact
Router::connect('/contact', array('controller' => 'Contactus', 'action' => 'index'));
Router::connect('/contacts', array('controller' => 'Contactus', 'action' => 'index'));

//login user
Router::connect('/loginuser/:provider', array('controller' => 'login', 'action' => 'loginuser'), array('provider' => '[a-zA-Z]+'));

App::import('Model', 'Confdb'); $_config = new Confdb();

//Admin
Router::connect('/'.$_config->getValue('admin-panel-url'), array('controller' => 'login', 'action' => 'index'));
Router::connect('/_backup_Db_mySQl', array('controller' => 'index', 'action' => 'database_mysql_dump'));
Router::connect('/logout', array('controller' => 'login', 'action' => 'logout'));
Router::connect('/forgotpasswordadmin', array('controller' => 'admin', 'action' => 'forgotpasswordadmin'));
Router::connect('/resetpasswordadmin/:email/:code', array('controller' => 'admin', 'action' => 'resetpasswordadmin'), array('email' => '(.)+', 'code' => '[0-9a-zA-Z]+'));


Router::connect('/rss', array('controller' => 'rss', 'action' => 'index'));
Router::connect('/sitemap.xml', array('controller' => 'sitemap', 'action' => 'buildSitemap'));
Router::parseExtensions('html');

CakePlugin::routes();
require CAKE . 'Config' . DS . 'routes.php';