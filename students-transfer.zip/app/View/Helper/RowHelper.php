<?php

class RowHelper extends Helper {

    var $color = array("0" => "_white", "1" => "");
    var $last_key = 1;

    function newcolor() {
        if (key($this->color) == $this->last_key) {
            reset($this->color);
        } else {
            next($this->color);
        }
    }

    function color() {
        echo current($this->color);
    }

    var $side = array("0" => "right", "1" => "left");
    var $last_key_side = 1;

    function newside() {
        if (key($this->side) == $this->last_key_side) {
            reset($this->side);
        } else {
            next($this->side);
        }
    }

    function side() {
        echo current($this->side);
    }

    function openUrl($mainUrl, $path) {
        return sprintf('<a href="%s%s" target="_blank">%s</a>', $mainUrl, $path, $path);
    }

    function BooleansSym($value) {
        if ($value >= 1) {
            return '<i class="fa fa-check"></i>';
            //return sprintf ('<img src="%s" alt="%s" title="%s" />', '/img/check.png', 'OK', 'OK');
        }
        if ($value < 1) {
            return '<i class="fa fa-ban"></i>';
            //return sprintf ('<img src="%s" alt="%s" title="%s" />', '/img/block.png', 'N/A', 'N/A');
        }
    }

    function filetype($type_file, $path, $name, $type, $size) {
        switch ($type_file) {
            case 'IMAGE':
                return sprintf('<a href="/download.php?file=%s&type=%s&path=%s"><img src="/img/images2.png" alt="img" /></a>', $name, $type, $path);
                break;

            case 'DOCUMENT':
                return sprintf('<a href="/download.php?file=%s&type=%s&path=%s"><img src="/img/doc.png" alt="document" /></a>', $name, $type, $path);
                break;
        }
    }

    function gallery_type($type_file, $title, $name, $path) {
        switch ($type_file) {
            case 'IMAGE':
                return sprintf('<img src="%s/%s" alt="%s" title="%s" />', $path, $name, $title, $title);
                break;

            case 'VIDEO':
                return sprintf('<img src="https://i2.ytimg.com/vi/%s/mqdefault.jpg" alt="%s" title="%s" />', $name, $title, $title);
                break;
        }
    }

    function file_type($type_file, $title, $name) {
        switch ($type_file) {
            case 'IMAGE':
                return sprintf('<img src="/img/image-type.png" alt="%s" title="%s" />', $name, $title, $title);
                break;

            case 'DOCUMENT':
                return sprintf('<img src="/img/document-type.png" alt="%s" title="%s" />', $name, $title, $title);
                break;
        }
    }

    function display_local($local) {
        switch ($local) {
            case 'ara':
                echo __('Arabic', true);
                break;

            case 'eng':
                echo __('English', true);
                break;

            case 'fre':
                echo __('French', true);
                break;
        }
    }

    function country($id) {
        return sprintf('<img src="/img/flags/%s.png" alt="%s" title="%s" />', strtolower($id), $id, $id);
    }

    function userStatus($value) {
        if (strtolower($value) == 'false') {
            return sprintf('<img src="%s" alt="%s" title="%s" />', '/img/green_dot.png', 'OK', 'OK');
        }
        if (strtolower($value) == 'true') {
            return sprintf('<img src="%s" alt="%s" title="%s" />', '/img/red_dot.png', 'N/A', 'N/A');
        }
    }

}

?>