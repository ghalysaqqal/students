<?php

class ProgressHelper extends Helper
{
	var $increment;
    var $addWidth;
    var $text;

    function ProgressObj(){
        $this->text = "Loading...";
    }

    function DisplayMeter(){
        print("<script type='text/javascript' src='/js/jquery.min.js'></script>");
        print("<link rel='stylesheet' type='text/css' href='/css/progress.css' />");
        print("<div class='meter_container'><h1>" . $this->text . "</h1><div class='meter'><span style='width: 0%'></span><h4></h4></div></div>");
    }

    function Calculate($count){
        $this->increment = 100 / $count;
    }

    function Animate(){
        $this->addWidth += $this->increment;
        $rounded = round($this->addWidth, 2);

        ?><script> 
            jQuery('.meter > span').stop().animate({width: "<?php echo $this->addWidth ?>%"}, "fast");
            jQuery('.meter > h4').html("Percent done: " + <?php echo $rounded; ?> + "%");
        </script><?php    
    }

    function Hide($redirect_url){       
        print("<div class='meter_container'><h1><a href=".$redirect_url.">SUCCESS .. Please Click here to continue</a></h1><div class='meter'><span style='width: 0%'></span><h4></h4></div></div>");        
        die();
    }
}

?>