<?php

App::uses('Helper', 'View');

class LayoutHelper extends Helper {

    var $name = 'Layout';

    // Navigation Design
    public function navigation($Node, $separate) {
        foreach ($Node as $k => $v) {
            if (!empty($v['url'])) {
                $Node[$k] = sprintf('<a href="%s">%s</a> ', $v['url'], $v['name']);
            } else {
                $Node[$k] = sprintf('%s ', $v['name']);
            }
        }
        $separate = sprintf(' %s', $separate);
        return implode($separate, $Node);
    }

    // Navigation Design
    public function navigation_admin($Node) {
        foreach ($Node as $k => $v) {
            if (!empty($v['url'])) {
                $Node[$k] = sprintf('<li><a href="%s">%s</a></li> ', $v['url'], $v['name']);
            } else {
                $Node[$k] = sprintf('<li class="active">%s</li> ', $v['name']);
                #$Node[$k] = sprintf('%s ', $v['name']);
            }
        }
        #$separate = sprintf(' <img src="/img/%s" alt=" > " />', $separate);
        return implode($Node);
    }

    public function buidMenu($menu, $sub_class, $lang, $content, $level = 1, $isMobile = -1) {

        App::import('Model', 'Menutext');
        $menuModel = new Menutext();

        if ($level == 1)
            echo $content = "<ul>";
        else
            echo $content = "<ul>";

        foreach ($menu as $node) {
            if ($node['Menu']['newTab'] == 1)
                echo $content = "<li class='$sub_class'><a target='_blank' href='" . $node['Menu']['path'] . "'>" . $node['Menutext']['title'] . "</a>";
            else
                echo $content = "<li class='$sub_class'><a href='" . $node['Menu']['path'] . "'>" . $node['Menutext']['title'] . "</a>";

            if ($node['Menu']['hasChildren'] == 1) {
                $cond = "`Menu`.`parentID` = '" . $node['Menu']['id'] . "' AND `Menu`.`active` = '1' AND `Menutext`.`local` = '" . $lang . "'";
                $fields = array('Menu.path', 'title');
                $children = $menuModel->getAll($cond, '*');
                $this->buidMenu($children, $sub_class, $lang, $content, 2);
            }
            echo $content = "</li>";
        }
        echo $content = "</ul>";
    }

    function strafter($string, $substring) {
        $pos = strpos($string, $substring);
        if ($pos === false)
            return $string;
        else
            return(substr($string, $pos + strlen($substring)));
    }

    function strbefore($string, $substring) {
        $pos = strpos($string, $substring);
        if ($pos === false)
            return $string;
        else
            return(substr($string, 0, $pos));
    }

}
