<?php

class SliderHelper extends Helper
{
	var $imgTypes 		= array('jpeg', 'jpg', 'png', 'gif'); //The extensions of the images that you want the plugin to read
	var $sliderEffects 	= array('boxes-zoomOut', 'boxesDiagonal-zoomOut', 'verticalStripes-openBookY', 'horizontalStripes-openBookX'); //The effects in the order you wish them to appear
	var $captionEffects = array('openBookY', 'fromLeft', 'openBookX', 'zoomOut'); //The effects in the order you wish them to appear for the captions
	var $randomOrder 	= false; // If is set to true the order of the images will be random each time it load


	function make_slider($id, $folder, $sliderEffects = false, $captionEffects = false){

		if( $sliderEffects == false ){
			$this->sliderEffects;
		}
	

		$list = $this->getDirectoryList($folder);

		if(sizeof($list) == 0){
			echo "<div style='width:100%;text-align:center;color:red;'>";
				echo "<h4>No images were found in this folder: $folder</h4>";
			echo "</div>";
			return;
		}

		$currentEffect = 0;


		echo "<div class='as_slider' id='$id'>";

			foreach ($list as $key => $value) {
				$extension = preg_split('/\.(?=[^.]*$)/', $value);
    			

    			$fx 		= $sliderEffects[$currentEffect];
    			

    			

				echo "<img src='$folder/$value' data-effect='$fx'  />";

				$currentEffect++;
			
				if($currentEffect >= count($sliderEffects)){
					$currentEffect = 0;
				}
			
			}

		echo "</div>";
	}

	function getDirectoryList ($directory) {
	    $this->imgTypes;
	    $this->randomOrder;

	    if( !is_dir($directory)){
	      return array();
	    }

	    $results = array();

	    $handler = opendir($directory);

	    while ($file = readdir($handler)) {
	      if ($file != "." && $file != ".." && $file != ".DS_Store") {
	         $extension = preg_split('/\./',$file);
	         $extension = strtolower($extension[count($extension)-1]);
	         
	         if(array_search($extension, $this->imgTypes) !== FALSE){
	            $results[] = $file;
	         }   
	            
	      }
	    }
	    if( $this->randomOrder ){
	    	shuffle($results);
	    }else{
	    	sort($results);
	    }

	    closedir($handler);
	    return $results;
	  }
}

?>