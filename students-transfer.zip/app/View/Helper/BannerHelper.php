<?php

class BannerHelper extends Helper {

    var $name = 'Banner';
    var $path = '/upload/banners/%s';

    public function DisplayZoneBanner($Banners, $Zone) {
        // it's Some regulare check
        if (!is_array($Banners)) {
            return false;
        }
        if (!isset($Banners[$Zone])) {
            return false;
        }

        if ($Banners[$Zone]['Zone']['isMultiAds'] > 0) {
            return $this->_PrepareSerialBannerZone($Banners[$Zone]);
        } else {
            return $this->_PrepareOneBannerZone($Banners[$Zone]);
        }
    }

    private function _PrepareSerialBannerZone($Zone) {
        $buff = array();
        foreach ($Zone['Banner'] as $Banner) {
            $buff[] = $this->DrowBanner($Banner['Adsbanner']);
        }
        return implode($Zone['Zone']['zoneBreak'], $buff);
    }

    private function _PrepareOneBannerZone($Zone) {
        $buff = $this->DrowBanner($Zone['Banner']['Adsbanner']);
        return $buff;
    }

    private function DrowBanner($banner) {
        switch ($banner['bannerType']) {
            case 'image':
                return $this->_DrowImageBanner($banner);
                break;
            case 'flash':
                return $this->_DrowFlashBanner($banner);
                break;
            case 'js':
                return $this->_DrowJsBanner($banner);
                break;
            case 'html':
				return $this->_DrowHtmlBanner ($banner);
                break;
        } // switch
    }

    private function _DrowImageBanner($banner) {
        if (empty($banner['url'])) {
            return sprintf('<img src="/upload/banners/%s" alt="%s" title="%s" />', $banner['bannerFilename'], $banner['alt'], $banner['alt']);
        } else {
            return sprintf('<a href="%s" target="_blank"><img src="/upload/banners/%s" alt="%s" title="%s" /></a>', $banner['url'], $banner['bannerFilename'], $banner['alt'], $banner['alt']);
        }
    }

    private function _DrowFlashBanner($banner) {
        return sprintf('<object type="application/x-shockwave-flash" data="/upload/banners/%s" width="%s" height="%s">
                          <param name="movie" value="/upload/banners/%s" />
                          <param name="quality" value="high"/>
                        </object>' ,$banner['bannerFilename'], $banner['width'], $banner['height'], $banner['bannerFilename']);
    }
    
    private function _DrowJsBanner($banner) {
        return sprintf('<script type="text/javascript" src="/upload/%s"></script>', $banner['bannerFilename']);
    }
    
    private function _DrowHtmlBanner($banner){
        return file_get_contents(WWW_ROOT.'/upload/banners/'.$banner['bannerFilename']);
	}
}

?>