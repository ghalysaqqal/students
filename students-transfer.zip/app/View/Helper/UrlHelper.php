<?php

class UrlHelper extends Helper
{
	function nice($text, $AddHtmlEnd = TRUE){
		$text = trim ($text);
		#$text = preg_replace('{(.)\1+}','$1',$text);
		$text = ereg_replace(' ', '-', $text);
		$text = ereg_replace('أ|إ|آ', 'ا', $text);
		$text = ereg_replace('ـ', '', $text);
		$text = ereg_replace('ّ', '', $text);
		$text = ereg_replace('َ', '', $text);
		$text = ereg_replace('ً', '', $text);
		$text = ereg_replace('ُ', '', $text);
		$text = ereg_replace('ٌ', '', $text);
		$text = ereg_replace('ِ', '', $text);
		$text = ereg_replace('ٍ', '', $text);
		$text = ereg_replace('~', '', $text);
		$text = ereg_replace('ْ', '', $text);
		$text = ereg_replace('`|\!|\@|\#|\^|\&|\(|\)|\|', '', $text);
		$text = ereg_replace('{|}|\[|\]', '_', $text);
		$text = ereg_replace('\+|\*|\/|\=|\%|\$|×', '', $text);
		$text = ereg_replace(',|\.|\'|;|\?|\<|\>|"|:', '', $text);
		$text = ereg_replace('^_', '', $text);
		$text = ereg_replace('_$', '', $text);
        $text = ereg_replace('…', '', $text);
        
        
		if ($AddHtmlEnd) {
			$text .= '.html';
		}
		return $text;
	}

	function __nice($url, $AddHtmlEnd = TRUE){
		$url = trim ($url);
		$url = ereg_replace (' ', '_', $url);
		$url = eregi_replace ('ـ', '', $url);
		$url = eregi_replace ('[^a-zA-Z0-9_|ذ|ض|ص|ث|ق|ف|غ|ع|ه|خ|ح|ج|د|ش|س|ي|ب|ل|ا|ت|ن|م|ك|ط|ئ|ء|ؤ|ر|لا|ى|ة|و|ز|ظ|إ|ـ|أ|آ]', '', $url);
		if ($AddHtmlEnd) {
			$url .= '.html';
		}
		return $url;
	}

	function AppendGetVar($url, $var){
		if (empty($url)) {
			return false;
		}
		if (!is_array($var)) {
			return $url;
		}
		$buff = array();
		foreach($var as $k => $v){
			$buff[] = sprintf('%s=%s', $k, $v);
		}

		$GETStr = implode('&', $buff);
		unset ($buff);
		return sprintf ('%s?%s', $url, $GETStr);
	}

	function letterBar ($Letters, $filedName, $Data, $url){
		$buff = '<div class="Letters"><div class="TdCenter">';
		foreach($Letters as $k => $v){
			$Data[$filedName] = $k;
			$u = $this->AppendGetVar ($url, $Data);
			$buff .= sprintf ('<div class="letter"><a href="%s">%s</a> . </div>', $u, $v);
		}
		$buff .= '</div></div>';
		return $buff;
	}
}

?>