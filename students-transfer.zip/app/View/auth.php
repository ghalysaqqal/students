<?php
if ( !isset($_SERVER['PHP_AUTH_USER']) ) {
    header('WWW-Authenticate: Basic realm="You Shall Not Pass"');
    header('HTTP/1.0 401 Unauthorized');
    exit;
}
else {
    $password = $_SERVER['PHP_AUTH_PW'];
    $password = md5(Configure::read('Security.salt1') . md5($password) . Configure::read('Security.salt2'));
    if ( $_SERVER['PHP_AUTH_USER'] == $Config['auth_username'] && $password == $Config['auth_password'] ) {} 
    else {
        die('WRONG_PASSWORD');
        exit;
  }
}