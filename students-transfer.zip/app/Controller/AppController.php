<?php

App::uses('Controller', 'Controller');


class AppController extends Controller {
}
