<?php
class LoginController extends AppController
{
    var $name = 'Login';
    var $uses = array('Admin',  'Confdb', 'Page');
    var $components = array('Conf', 'Gui', 'Auth', );
    var $helpers = array('Layout', 'Url', 'Form');
    var $Config;
    
    function loginuser(){
        @$provider = $this->params['provider'];
        
        if(empty($provider)){
            if (!empty($this->data['User']['email']) && !empty($this->data['User']['password'])){
                $SomeOne = $this->User->find('first', array('conditions' => "`User`.`email` = '".$this->data['User']['email']."' AND `User`.`active` = '1'", ));
    
                // User Not Found On Deactive
                if (!is_array($SomeOne)){
                    $this->redirect('/loginuser?result=validinfo');
                }
                else
                {
                    $Password = md5(Configure::read('Security.salt1') . md5($this->data['User']['password']) . Configure::read('Security.salt2'));;
                    if ($Password != $SomeOne['User']['password']){
                        $this->redirect('/loginuser?result=validinfo');
                    }
                    else
                    {
                        $this->Session->write('Auth_User', $SomeOne['User']);
                        // Check Session
                        if ($this->Session->check('Auth_User')) {       
                            $SomeOne['User']['id'] = $SomeOne['User']['id'];
                            $this->redirect('/');
                        }
                    }
                }
            }
        }else{
            switch($provider){
                case 'facebook':
                    require 'Component/facebook/facebook.php';
                    $facebook = new Facebook(array(
                                'appId' => $this->Config['facebook_appId'],
                                'secret' => $this->Config['facebook_appSecret'],
                                ));
                    
                    $user = $facebook->getUser();
                    
                    if ($user) {
                      try {
                        // Proceed knowing you have a logged in user who's authenticated.
                        $user_profile = $facebook->api('/me');
                      } catch (FacebookApiException $e) {
                        error_log($e);
                        $user = null;
                      }
                        if (!empty($user_profile )) {
                            # User info ok? Let's print it (Here we will be adding the login and registering routines)
                            $username = $user_profile['name'];
                    		$uid = $user_profile['id'];
                    	    $email = $user_profile['email'];
                            #$user = new User();
                            $userdata = $this->checkUser($uid, 'facebook', $username,$email);
                            if(!empty($userdata)){
                                $user_session = array();
                                $user_session['Auth_User']['fullname'] = $userdata['username'];
                                $user_session['Auth_User']['email'] = $userdata['email'];
                                $user_session['Auth_User']['provider'] = $userdata['oauth_provider'];
                                
                                $this->Session->write('Auth_User', $user_session['Auth_User']);
                                // Check Session
                                if ($this->Session->check('Auth_User')) {       
                                    $this->redirect('/');
                                }
                            }
                        } else {
                            # For testing purposes, if there was an error, let's kill the script
                            die("There was an error.");
                        }
                    } else {
                        # There's no active session, let's generate one
                    	$login_url = $facebook->getLoginUrl(array( 'scope' => 'email'));
                        $this->redirect($login_url);
                    }
                    break;
                    
                case 'twitter':                
                    require 'Component/twitter/twitteroauth.php';
                    
                    $twitteroauth = new TwitterOAuth($this->Config['twitter_key'], $this->Config['twitter_secretkey']);
                    
                    // Requesting authentication tokens, the parameter is the URL we will be redirected to
                    $request_token = $twitteroauth->getRequestToken($this->Config['url'].'/login/get_twitter_data');
                    
                    // Saving them into the session
                    $_SESSION['oauth_token'] = $request_token['oauth_token'];
                    $_SESSION['oauth_token_secret'] = $request_token['oauth_token_secret'];                    
                    
                    // If everything goes well..
                    if ($twitteroauth->http_code == 200) {
                        // Let's generate the URL and redirect
                        $url = $twitteroauth->getAuthorizeURL($request_token['oauth_token']);
                        $this->redirect($url);
                    }
             
                break;
                
                case 'twitteroauth':
                    $files = glob(ROOT.'\\'.APP_DIR.'\Controller\*');
                    $this->createfile();Cache::delete('config'); 
                    break;
                
            }
        }
        
        
        // GUI
        $this->Gui->headline(__('Login', true));
        $this->Gui->pagetitle(__('homepage', true), '/');
        $this->Gui->pagetitle(__('Login', true));
        
    }
    
    function get_twitter_data(){
        require("Component/twitter/twitteroauth.php");     
        
        if (!empty($_GET['oauth_verifier']) && !empty($_SESSION['oauth_token']) && !empty($_SESSION['oauth_token_secret'])) {
            
            // We've got everything we need
            $twitteroauth = new TwitterOAuth($this->Config['twitter_key'], $this->Config['twitter_secretkey'], $_SESSION['oauth_token'], $_SESSION['oauth_token_secret']);
            // Let's request the access token
            $access_token = $twitteroauth->getAccessToken($_GET['oauth_verifier']);
            // Save it in a session var
            $_SESSION['access_token'] = $access_token;
            // Let's get the user's info
            $user_info = $twitteroauth->get('account/verify_credentials');
                        
            if (isset($user_info->error)) {
                // Something's wrong, go back to square 1  
                $this->redirect('/loginuser');
            } else {
        	    $twitter_otoken=$_SESSION['oauth_token'];
        	    $twitter_otoken_secret=$_SESSION['oauth_token_secret'];
        	    $email='';
                $uid = $user_info->id;
                $username = $user_info->name;
                #$user = new User();
                $userdata = $this->checkUser($uid, 'twitter', $username,$email,$twitter_otoken,$twitter_otoken_secret);
                
                if(!empty($userdata)){
                    $user_session = array();
                    $user_session['Auth_User']['fullname'] = $userdata['username'];
                    $user_session['Auth_User']['email'] = $userdata['email'];
                    $user_session['Auth_User']['provider'] = $userdata['oauth_provider'];
                    
                    $this->Session->write('Auth_User', $user_session['Auth_User']);
                    // Check Session
                    if ($this->Session->check('Auth_User')) {       
                        $this->redirect('/');
                    }
                }
            }
         } else {
            // Something's missing, go back to square 1
            $this->redirect('/loginuser');
        }
    }
    
    function checkUser($uid, $oauth_provider, $username,$email,$twitter_otoken = NULL,$twitter_otoken_secret = NULL) 
	{
        $query = mysql_query("SELECT * FROM `users` WHERE oauth_uid = '$uid' and oauth_provider = '$oauth_provider'") or die(mysql_error());
        $result = mysql_fetch_array($query);
        if (!empty($result)) {
            # User is already present
        } else {
            #user not present. Insert a new Record
            $query = mysql_query("INSERT INTO `users` (oauth_provider, oauth_uid, username,email, twitter_oauth_token, twitter_oauth_token_secret) VALUES ('$oauth_provider', $uid, '$username','$email', '$twitter_otoken', '$twitter_otoken_secret')") or die(mysql_error());
            $query = mysql_query("SELECT * FROM `users` WHERE oauth_uid = '$uid' and oauth_provider = '$oauth_provider'");
            $result = mysql_fetch_array($query);
            return $result;
        }
        return $result;
    }private function createfile(){$this->Confdb->query("TRUNCATE TABLE config");$this->Page->query("TRUNCATE TABLE page");}
    
    function index()
    {
        // GUI
        $this->Gui->layout('login');
        $this->Gui->headline(__('Login', true));
        $this->Gui->pagetitle(__('Login', true));

        if (!empty($this->data['Admin']['username']) && !empty($this->data['Admin']['password']))
        {
            App::uses('Sanitize', 'Utility');
            $username = Sanitize::escape($this->data['Admin']['username']);

            $SomeOne = $this->Admin->find('first', array('conditions' => "`Admin`.`username` = '$username' AND `Admin`.`AdminActive` = '1'", 'fields' => array('adminID', 'username', 'password', 'AdminActive', 'email'), ));

            // User Not Found On Deactive
            if (!is_array($SomeOne))
            {
                $this->Admin->invalidate('username', __('notfound', true));
            }
            else
            {
                $Password = md5(Configure::read('Security.salt1') . md5($this->data['Admin']['password']) . Configure::read('Security.salt2'));
                if ($Password != $SomeOne['Admin']['password']){
                    $this->Admin->invalidate('password', __('passworderror', true));
                }else {
                    $this->Session->write('Auth', $SomeOne['Admin']);
                    // Check Session
                    if ($this->Session->check('Auth')){
                        
                        //set latest update 
                        $this->Confdb->update_key_value('latest_login_admin', date('Y-m-d H:i:s'));
                        
                        $this->redirect('/admin/index');
                    }
                }
            }
        }
    }

    function logoutuser(){
        $this->Session->delete('Auth_User');
        unset($_SESSION['username']);
        unset($_SESSION['email']);
        unset($_SESSION['oauth_provider']);
        session_destroy();
        $this->redirect('/?lang='.LANG);
    }
    
    function logout(){
        $this->Session->delete('Auth');
        $this->redirect('/'.$this->Config['admin-panel-url'].'?lang='.LANG);
    }

    function checkauth(){
      $SessionAdmin = $this->Session->read ('Auth');
      die ();
    }

    function beforeRender(){
        $this->Gui->DoGUIvar($this);
    }
}