<?php

App::uses('AppController', 'Controller');

class CollageController extends AppController {

    var $name = 'Collage';
    var $uses = array('Collage', 'Collagetext', 'Lang');
    var $components = array('Conf', 'Gui', 'Auth',);
    var $helpers = array('Layout', 'Pagination', 'Row', 'Url',);
    var $Config = array();

    function index() {

        $cond = "`Collage`.`active` = '1' AND `Collagetext`.`local` = '" . LANG . "'";
        $fields = array('Collage.id', 'collage', 'Collage.url', 'Collage.thumb');
        $this->set('collages', $this->Collagetext->getAll($cond, $fields));

        $this->Gui->headline(__('Collages', true));
        $this->Gui->pagecollage(__('Collages', true));
        $this->Gui->navigation(__('homepage', true), '/');
        $this->Gui->navigation(__('Collages', true));
    }

    function admin_index() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('browse', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Collages Management', true), '/admin/collage/');
        $this->Gui->navigation(__('browse', true));

        $this->set('collagetexts', $this->Collage->getAll());
        $this->set('Langs', $this->Lang->getLangs());
    }

    function admin_add() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Collages Management', true), '/admin/collage/');
        $this->Gui->navigation(__('add', true));
        $this->set('Langs', $Langs = $this->Lang->getLangs());

        if (!empty($this->data)) {
            if ($this->Collage->validates()) {
                $collage['id'] = null;
                $collage['postDate'] = date('Y-m-d H:i:s');
                $collage['active'] = $this->data['Collage']['active'];

                if ($this->Collage->save($collage)) {
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

                    $collage_id = $this->Collage->getLastInsertID();

                    foreach ($Langs as $lang) {
                        $text['Collagetext']['id'] = NULL;
                        $text['Collagetext']['collage_id'] = $collage_id;
                        $text['Collagetext']['local'] = $lang['Lang']['id'];
                        $text['Collagetext']['collage'] = $this->data['Collagetext']['collage_' . $lang['Lang']['id']];

                        $this->Collagetext->save($text['Collagetext']);
                    }
                    $this->redirect('/admin/collage/index/?result=done');
                }
            } else
                $this->render();
        } else
            $this->render();
    }

    function admin_edit($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $cond = "`Collage`.`id` = '$id'";
        $Collage = $this->Collage->getCollage($cond);
        if (!is_array($Collage)) {
            $this->redirect('/admin/collage');
            die();
        }
        $this->set('collage', $Collage);

        $this->set('collagetext', $collagetext = $this->Collagetext->find('all', array('conditions' => "`Collagetext`.`collage_id` = '" . $Collage['Collage']['id'] . "'")));
        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Collages Management', true), '/admin/collage/');

        if (!empty($this->data)) {
            $this->Collage->set($this->data);

            if ($this->Collage->validates()) {
                $this->Collage->id = $id;

                if ($this->Collage->save($this->Collage->data['Collage'])) {
                    foreach ($collagetext as $data) {
                        $text['Collagetext']['id'] = $data['Collagetext']['id'];
                        $text['Collagetext']['collage'] = $this->data['Collagetext']['collage_' . $data['Collagetext']['local']];

                        $this->Collagetext->save($text, false, array('collage'));
                    }
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

                    $this->redirect('/admin/collage/edit/' . $id . '/?result=done');
                }
            }
        } else {
            $this->Collage->data = $Collage['Collage'];
        }
    }

    function admin_delete($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $Collage = $this->Collage->find('first', array('conditions' => "`Collage`.`id` = '$id'"));
        if (!is_array($Collage)) {
            $this->redirect('/admin/collage');
            die();
        }

        if ($this->Collage->delete($id)) {
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

            $collagetext = $this->Collagetext->find('all', array('conditions' => "`Collagetext`.`collage_id` = '$id'"));

            foreach ($collagetext as $data) {
                $this->Collagetext->delete($data['Collagetext']['id']);
            }
            $this->redirect('/admin/collage/index');
        }
    }

    function admin_active($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }
        $cond = "`Collage`.`id` = '$id'";
        $data = $this->Collage->getCollage($cond);
        $data['Collage']['id'] = $data['Collage']['id'];
        $data['Collage']['active'] = $data['Collage']['active'] * -1;
        if ($this->Collage->save($data, false, array('active'))) {
            $this->redirect('/admin/collage/index/');
        }
    }

    function beforeRender() {
        $this->Gui->DoGUIvar($this);
    }

}
