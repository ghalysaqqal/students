<?php

App::uses('AppController', 'Controller');

class AreaController extends AppController {

    var $name = 'Area';
    var $uses = array('Area', 'Areatext', 'Lang');
    var $components = array('Conf', 'Gui', 'Auth',);
    var $helpers = array('Layout', 'Pagination', 'Row', 'Url',);
    var $Config = array();

    function index() {

        $cond = "`Area`.`active` = '1' AND `Areatext`.`local` = '" . LANG . "'";
        $fields = array('Area.id', 'area', 'Area.url', 'Area.thumb');
        $this->set('areas', $this->Areatext->getAll($cond, $fields));

        $this->Gui->headline(__('Areas', true));
        $this->Gui->pagearea(__('Areas', true));
        $this->Gui->navigation(__('homepage', true), '/');
        $this->Gui->navigation(__('Areas', true));
    }

    function admin_index() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('browse', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Areas Management', true), '/admin/area/');
        $this->Gui->navigation(__('browse', true));

        $this->set('areatexts', $this->Area->getAll());
        $this->set('Langs', $this->Lang->getLangs());
    }

    function admin_add() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Areas Management', true), '/admin/area/');
        $this->Gui->navigation(__('add', true));
        $this->set('Langs', $Langs = $this->Lang->getLangs());

        if (!empty($this->data)) {
            if ($this->Area->validates()) {
                $area['id'] = null;
                $area['postDate'] = date('Y-m-d H:i:s');
                $area['active'] = $this->data['Area']['active'];

                if ($this->Area->save($area)) {
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

                    $area_id = $this->Area->getLastInsertID();

                    foreach ($Langs as $lang) {
                        $text['Areatext']['id'] = NULL;
                        $text['Areatext']['area_id'] = $area_id;
                        $text['Areatext']['local'] = $lang['Lang']['id'];
                        $text['Areatext']['area'] = $this->data['Areatext']['area_' . $lang['Lang']['id']];

                        $this->Areatext->save($text['Areatext']);
                    }
                    $this->redirect('/admin/area/index/?result=done');
                }
            } else
                $this->render();
        } else
            $this->render();
    }

    function admin_edit($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $cond = "`Area`.`id` = '$id'";
        $Area = $this->Area->getArea($cond);
        if (!is_array($Area)) {
            $this->redirect('/admin/area');
            die();
        }
        $this->set('area', $Area);

        $this->set('areatext', $areatext = $this->Areatext->find('all', array('conditions' => "`Areatext`.`area_id` = '" . $Area['Area']['id'] . "'")));
        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Areas Management', true), '/admin/area/');

        if (!empty($this->data)) {
            $this->Area->set($this->data);

            if ($this->Area->validates()) {
                $this->Area->id = $id;

                if ($this->Area->save($this->Area->data['Area'])) {
                    foreach ($areatext as $data) {
                        $text['Areatext']['id'] = $data['Areatext']['id'];
                        $text['Areatext']['area'] = $this->data['Areatext']['area_' . $data['Areatext']['local']];

                        $this->Areatext->save($text, false, array('area'));
                    }
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

                    $this->redirect('/admin/area/edit/' . $id . '/?result=done');
                }
            }
        } else {
            $this->Area->data = $Area['Area'];
        }
    }

    function admin_delete($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $Area = $this->Area->find('first', array('conditions' => "`Area`.`id` = '$id'"));
        if (!is_array($Area)) {
            $this->redirect('/admin/area');
            die();
        }

        if ($this->Area->delete($id)) {
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

            $areatext = $this->Areatext->find('all', array('conditions' => "`Areatext`.`area_id` = '$id'"));

            foreach ($areatext as $data) {
                $this->Areatext->delete($data['Areatext']['id']);
            }
            $this->redirect('/admin/area/index');
        }
    }

    function admin_active($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }
        $cond = "`Area`.`id` = '$id'";
        $data = $this->Area->getArea($cond);
        $data['Area']['id'] = $data['Area']['id'];
        $data['Area']['active'] = $data['Area']['active'] * -1;
        if ($this->Area->save($data, false, array('active'))) {
            $this->redirect('/admin/area/index/');
        }
    }

    function beforeRender() {
        $this->Gui->DoGUIvar($this);
    }

}
