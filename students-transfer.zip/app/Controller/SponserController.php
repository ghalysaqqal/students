<?php

class SponserController extends AppController
{
    var $name = 'Sponser';
    var $uses = array('Sponser', 'Sponsertext', 'Lang' );
    var $components = array('Conf', 'Gui', 'Auth', 'Banners', 'Jqimgcrop', 'Upload', 'Resize', 'Acl');
    var $helpers = array('Layout', 'Pagination', 'Row', 'Url', 'Cropimage');

    var $Config = array();
    
    function index(){
        
        $cond = "`Sponser`.`active` = '1' AND `Sponsertext`.`local` = '".LANG."'";
        $fields = array('Sponser.id', 'title', 'Sponser.url', 'Sponser.thumb');
        $this->set('sponsers', $this->Sponsertext->getAll($cond, $fields));
        
        $this->Gui->headline(__('Clients', true));
        $this->Gui->pagetitle(__('Clients', true));
        $this->Gui->navigation(__('homepage', true), '/');
        $this->Gui->navigation(__('Clients', true));
    }

    function admin_index()
    {
        $this->Auth->AuthAdmin ($this, 'sponsers', 'read');

        $this->Gui->layout('admin');
        $this->Gui->headline(__('browse', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_clients', true), '/admin/sponser/');
        $this->Gui->navigation(__('browse', true));
        
        $this->set('sponsertexts', $this->Sponser->getAll()); 
        $this->set('Langs', $this->Lang->getLangs());

    }

    function admin_add()
    {
        $this->Auth->AuthAdmin ($this, 'sponsers', 'create');

        $this->Gui->layout('admin');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_clients', true), '/admin/sponser/');
        $this->Gui->navigation(__('add', true));
		$this->set('Langs', $Langs = $this->Lang->getLangs());

        if (!empty($this->data))
        {
            if ($this->Sponser->validates())
            {
                $sponser['id'] = null;
                $sponser['url'] = $this->data['Sponser']['url'];
                $sponser['postDate'] = date('Y-m-d H:i:s');
                $sponser['active'] = $this->data['Sponser']['active'];
                
                if ($this->data['Sponser']['thumb']['error'] == 0 && $this->data['Sponser']['thumb']['size'] > 0)
                {
                    // News
                    $path = WWW_ROOT . 'upload' . DS . 'sponser' . DS ;
                    $path_thum = $path . 'thum' . DS;
                    
                    $NewFileName = $this->Upload->newname($this->data['Sponser']['thumb']['name']);
                    // Main File
                    if ($this->Upload->upload($this->data['Sponser']['thumb'], $path, 'image', $NewFileName))
                    {
                        $sponser['thumb'] = $NewFileName;
                        
                        $MainFilePath = $path . $NewFileName;
                    }
                    else
                    {
                        $this->log(print ('Uploading Error in File'));
                    }
                }
               
                
                if ($this->Sponser->save($sponser))
                {
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            
					$sponser_id = $this->Sponser->getLastInsertID();
                    
                    foreach($Langs as $lang){
                        $text['Sponsertext']['id'] = NULL;
                        $text['Sponsertext']['sponser_id'] = $sponser_id;
                        $text['Sponsertext']['local'] = $lang['Lang']['id'];
                        $text['Sponsertext']['title'] = $this->data['Sponsertext']['title_'.$lang['Lang']['id']];
                        
                        $this->Sponsertext->save($text['Sponsertext']);
                    }
                    $this->redirect('/admin/sponser/index/?result=done');
                }
            }
            else
                $this->render();
        }
        else
            $this->render();
    }
    
    
    function admin_editthumb($id, $type = NULL){
        $this->Auth->AuthAdmin ($this, 'sponsers', 'update');
        
        $this->Gui->layout('editthumb');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_clients', true), '/admin/item/');
        $this->Gui->navigation(__('add', true));
        
        $id = intval($id);
        if($id == 0){
            $this->redirect('/admin/index');
            die();
        }
        
        
        $path = WWW_ROOT . 'upload' . DS . 'sponser' . DS;
        $path_thum = $path . 'thum' . DS;
        
        $cond = "`Sponser`.`id` = '$id'";
        $this->set('sponser', $sponser = $this->Sponser->getSponser($cond));
        $this->set('thumb', $sponser['Sponser']['thumb']);
        list($width, $height, $type, $attr) = getimagesize($path_thum.$sponser['Sponser']['thumb']);  

        $this->set('width', $width);
        $this->set('height', $height);  
        $this->set('path_thum', $path_thum);    
        
        if(!empty($this->data)){
            $this->Jqimgcrop->cropImage($this->Config['width_thum'], $this->data['x1'], $this->data['y1'], $this->data['x2'], $this->data['y2'], $this->data['w'], $this->data['h'], $this->data['imagePath'], $this->data['imagePath']);
            $this->redirect('/admin/sponser/index/?result=done');
        }
    }



    function admin_edit($id)
    {
        $this->Auth->AuthAdmin ($this, 'sponsers', 'update');

        $id = intval($id);
        $cond = "`Sponser`.`id` = '$id'";
        $Sponser = $this->Sponser->getSponser($cond);
        if (!is_array($Sponser))
        {
            $this->redirect('/admin/sponser');
            die();
        }
        $this->set('sponser', $Sponser);
        
		$this->set('sponsertext', $sponsertext = $this->Sponsertext->find('all', array('conditions' => "`Sponsertext`.`sponser_id` = '".$Sponser['Sponser']['id']."'"))) ;
        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_clients', true), '/admin/sponser/');

        if (!empty($this->data))
        {
            $this->Sponser->set($this->data);
            
            if ($this->Sponser->validates())
            {
                $this->Sponser->id = $id;
                
                if ($this->data['Sponser']['thumb']['error'] == 0 && $this->data['Sponser']['thumb']['size'] > 0)
                {
                    // News
                    $path = WWW_ROOT . 'upload' . DS . 'sponser' . DS ;
                    $path_thum = $path . 'thum' . DS;
                    
                    $NewFileName = $this->Upload->newname($this->data['Sponser']['thumb']['name']);
                    // Main File
                    if ($this->Upload->upload($this->data['Sponser']['thumb'], $path, 'image', $NewFileName))
                    {
                        @unlink($path.$Sponser['Sponser']['thumb']);
                        @unlink($path_thum.$Sponser['Sponser']['thumb']);
                        
                        $this->Sponser->data['Sponser']['thumb'] = $NewFileName;
                        
                        $MainFilePath = $path . $NewFileName;
                    }
                    else
                    {
                        $this->log(print ('Uploading Error in File'));
                    }
                }
                else
                {
                    $this->Sponser->data['Sponser']['thumb'] = $Sponser['Sponser']['thumb'];
                }
            

                if ($this->Sponser->save($this->Sponser->data['Sponser']))
                {
					foreach($sponsertext as $data){
                        $text['Sponsertext']['id'] = $data['Sponsertext']['id'];
                        $text['Sponsertext']['title'] = $this->data['Sponsertext']['title_'.$data['Sponsertext']['local']];
                        
                        $this->Sponsertext->save($text, false,  array('title'));
                    } 
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            
                    $this->redirect('/admin/sponser/edit/'.$id.'/?result=done');
                }
            }
            
        }
        else{
			$this->Sponser->data = $Sponser['Sponser'];
		}
    }

    function admin_delete($id)
    {
        $this->Auth->AuthAdmin ($this, 'sponsers', 'delete');

        $id = intval($id);
        $Sponser = $this->Sponser->find('first', array('conditions' => "`Sponser`.`id` = '$id'"));
        if (!is_array($Sponser))
        {
            $this->redirect('/admin/sponser');
            die();
        }

        if ($this->Sponser->delete($id))
        {
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            
            $path = WWW_ROOT . 'upload' . DS . 'sponser' . DS; 
            $path_thum = $path . 'thum' . DS ; 
            
            @unlink($path . $Sponser['Sponser']['thumb']);
            @unlink($path_thum . $Sponser['Sponser']['thumb']);
            
			$sponsertext = $this->Sponsertext->find('all', array('conditions' => "`Sponsertext`.`sponser_id` = '$id'"));
            
            foreach($sponsertext as $data){
                $this->Sponsertext->delete($data['Sponsertext']['id']);
            }
            $this->redirect('/admin/sponser/index');
        }
    }
    
    function admin_deletesponser($id)
    {
        $this->Auth->AuthAdmin ($this, 'sponsers', 'delete');
        $this->Gui->layout('blank');
        $id = intval($id);
        $Sponser = $this->Sponser->find('first', array('conditions' => "`Sponser`.`id` = '$id'"));
        if ($this->Sponser->delete($id))
        {
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            
            $path = WWW_ROOT . 'upload' . DS . 'sponser' . DS; 
            $path_thum = $path . 'thum' . DS ; 
            
            @unlink($path . $Sponser['Sponser']['thumb']);
            @unlink($path_thum . $Sponser['Sponser']['thumb']);
            
			$sponsertext = $this->Sponsertext->find('all', array('conditions' => "`Sponsertext`.`sponser_id` = '$id'"));
            
            foreach($sponsertext as $data){
                $this->Sponsertext->delete($data['Sponsertext']['id']);
            }
        }
    }
    
    function admin_active($id){
        $this->Auth->AuthAdmin ($this, 'sponsers', 'update');
        
        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }
        $cond = "`Sponser`.`id` = '$id'";
        $data = $this->Sponser->getSponser($cond);
        $data['Sponser']['id']     = $data['Sponser']['id'];
        $data['Sponser']['active'] = $data['Sponser']['active'] * -1;
        if ($this->Sponser->save($data, false, array('active'))) {
            $this->redirect('/admin/sponser/index/');
        }
    }

    function beforeRender()
    {
        $this->Gui->DoGUIvar($this);
    }
}