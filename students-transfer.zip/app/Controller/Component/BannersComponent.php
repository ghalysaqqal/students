<?php

class BannersComponent extends Component {

    var $method = '';
    var $name = 'Banners';
    var $Banners = array();

    // assigns values of referencing controller
    function startup(Controller $controller) {
        $this->name = $controller->name;

        $this->loadDB($controller);

        $this->loadHelper($controller);

        $this->GetZoneBanner($controller);
    }

    // Load DB Model
    private function loadDB(&$controller) {
        // Load Zone Model
        if (!isset($controller->Adszone)) {
            App::import('Model', 'Adszone');
            $controller->Adszone = new Adszone();
        }

        // Load Banner Model
        if (!isset($controller->Adsbanner)) {
            App::import('Model', 'Adsbanner');
            $controller->Adsbanner = new Adsbanner();
        }
    }

    private function loadHelper(&$controller) {
        $controller->helpers[] = 'Banner';
    }

    // Get Zone Banners
    public function GetZoneBanner(&$controller) {
        $this->Banners = Cache::read('Banner');
        if ($this->Banners == false) {
            // Get All Zone Active
            $Zones = $controller->Adszone->find('all', array('conditions' => "`Adszone`.`zoneActive` = '1'", 'order' => "`Adszone`.`adsZID` ASC", 'fields' => array('adsZID', 'zoneName', 'isMultiAds', 'zoneBreak', 'isRand')));
            foreach ($Zones as $Zone) {
                $this->Banners[$Zone['Adszone']['zoneName']] = array();
                $this->Banners[$Zone['Adszone']['zoneName']]['Zone'] = $Zone['Adszone'];
                $this->Banners[$Zone['Adszone']['zoneName']]['Banner'] = array();
                $Cond = "`Adsbanner`.`adsZID` = '" . $Zone['Adszone']['adsZID'] . "' AND `Adsbanner`.`bannerActive` > '0'";
                $Fields = array('bannerType', 'bannerFilename', 'width', 'height', 'url', 'alt');
                $Zone['Adszone']['isRand'] > 0 ? $Ord = "rand()" : $Ord = "`Adsbanner`.`weight` ASC";
                // Check if this Zone have Multi Banner
                if ($Zone['Adszone']['isMultiAds'] > 0) {
                    $Banner = $controller->Adsbanner->find('all', array(
                        'conditions' => $Cond,
                        'fields' => $Fields,
                        'order' => $Ord,
                    ));
                    $this->Banners[$Zone['Adszone']['zoneName']]['Banner'] = $Banner;
                } else {
                    $Banner = $controller->Adsbanner->find('first', array(
                        'conditions' => $Cond,
                        'order' => $Ord,
                        'fields' => $Fields,
                    ));
                    $this->Banners[$Zone['Adszone']['zoneName']]['Banner'] = $Banner;
                }
                unset($Banner);
            }
            Cache::write('Banner', $this->Banners);
        }
        //print_r ($this->Banners);
        $controller->set('BANNERS', $this->Banners);
    }

}

?>