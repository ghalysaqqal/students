<?php
class AuthComponent extends Component
{
    var $method = '';
    var $name = 'Auth';

    var $IsLogging = false;
    var $IsAuth = false;
    var $IsPremium = false;
    var $User = array();
    var $Admin = array();

    function startup(Controller $controller)
    {
        $this->name = $controller->name;

        if (!isset($controller->Admin))
        {
            App::uses('Admin', 'Model');
            $controller->Admin = new Admin();
        }
        /*
        if (!isset($controller->User))
        {
            App::import('Model', 'User');
            $controller->User = new User();
        }
        */
        
    }
    
    // Clients Function
    function AuthUser(&$controller, $Aco = NULL, $Level = NULL){
        if ($controller->Session->check('Auth_User'))
        {
            $SessionClients = $controller->Session->read('Auth_User');

            $DataClients = $controller->User->find('first', array('conditions' => "`User`.`email` = '" . $SessionClients['email'] . "'", ));
            // Admin NOT Found
            if (!is_array($DataClients))
            {
                $this->GoToClientsLoginPage($controller);
            }

            // Password NOT Match
            if ($SessionClients['password'] != $DataClients['User']['password'])
            {
                $this->GoToClientsLoginPage($controller);
            }

            // Admin Inactive
            if ($DataClients['User']['active'] <= 0)
            {
                $this->GoToClientsLoginPage($controller);
            }
            
            if (!empty($Aco)) {
				if (empty($Level)) {
					if (!$controller->Acl->check(array('model' => 'User', 'foreign_key' => $DataClients['User']['id']), $Aco, '*')) {
						$this->GoToClientsNoPermissionPage ($controller);
					}
				}else{
					if (!$controller->Acl->check(array('model' => 'User', 'foreign_key' => $DataClients['User']['id']), $Aco, $Level)) {
						$this->GoToClientsNoPermissionPage ($controller);
					}
				}
			}

            $this->User = $DataClients['User'];
                        
            // Write Cockies File
            @setcookie('AuTH_User', true, time()+600, '/');
        }
        else
        {
            $this->GoToClientsLoginPage($controller);
        }
    }


    // Admin Function
    function AuthAdmin(&$controller, $Aco = NULL, $Level = NULL)
    {
        if ($controller->Session->check('Auth'))
        {
            $SessionAdmin = $controller->Session->read('Auth');

            $DataAdmin = $controller->Admin->find('first', array('conditions' => "`Admin`.`username` = '" . $SessionAdmin['username'] . "'", ));
            // Admin NOT Found
            if (!is_array($DataAdmin))
            {
                $this->GoToAdminLoginPage($controller);
            }

            // Password NOT Match
            if ($SessionAdmin['password'] != $DataAdmin['Admin']['password'])
            {
                $this->GoToAdminLoginPage($controller);
            }

            // Admin Inactive
            if ($DataAdmin['Admin']['AdminActive'] <= 0)
            {
                $this->GoToAdminLoginPage($controller);
            }

            if (!empty($Aco)) {
				if (empty($Level)) {
					if (!$controller->Acl->check(array('model' => 'Admin', 'foreign_key' => $DataAdmin['Admin']['adminID']), $Aco, '*')) {
						$this->GoToAdminNoPermissionPage ($controller);
					}
				}else{
					if (!$controller->Acl->check(array('model' => 'Admin', 'foreign_key' => $DataAdmin['Admin']['adminID']), $Aco, $Level)) {
						$this->GoToAdminNoPermissionPage ($controller);
					}
				}
			}

            $this->Admin = $DataAdmin['Admin'];
            $controller->Gui->layout('admin');

            // Write Cockies File
            @setcookie('AuTH', true, time()+600, '/');

        }
        else
        {
            $this->GoToAdminLoginPage($controller);
        }
    }

    function GoToClientsLoginPage(&$controller)
    {
        $controller->redirect('/login');
        die();
    }

    function GoToAdminLoginPage(&$controller)
    {
        App::import('Model', 'Confdb'); $_config = new Confdb();
        $controller->redirect('/'.$_config->getValue('admin-panel-url'));
        die();
    }

    function GoToAdminNoPermissionPage(&$controller){
		$controller->redirect ('/admin/privilege/nopermission');
		die ();
   	}
    
    function GoToClientsNoPermissionPage(&$controller){
		$controller->redirect ('/');
		die ();
   	}
}