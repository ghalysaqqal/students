<?php
class GuiComponent extends Component
{
    var $method = '';
    var $name = 'Gui';

    var $GUI = array('headline' => '',
					 'pagetitle' => '',
					 'keywords' => '',
					 'description' => '',
					 'navigation' => array(),
					 'layout' => 'default',
					 'menu' => array(),
					 'activemenu' => '0',
					 'pathmenu' => array()
					 );

    // assigns values of referencing controller
    public function startup(Controller $controller)
    {
        $this->name = $controller->name;
    }

    public function headline($txt = null)
    {
        $this->GUI['headline'] = $txt;
    }

    public function pagetitle($txt = null)
    {
        $this->GUI['pagetitle'] = $txt;
    }

    public function keywords($txt = null)
    {
        $this->GUI['keywords'] = $txt;
    }

    public function description($txt = null)
    {
        $this->GUI['description'] = $txt;
    }

    public function layout($txt = 'default')
    {
        $this->GUI['layout'] = $txt;
    }

    public function navigation($name, $url = null)
    {
        $this->GUI['navigation'][] = array('name' => $name, 'url' => $url);
    }

    public function DoGUIvar(&$controller)
    {
        // Layout
        $controller->layout = LANG . DS . $this->GUI['layout'];

        // Pagetitle
        if (empty($this->GUI['pagetitle']) && isset($controller->Config['pagetitle'])){
            $this->GUI['pagetitle'] = $controller->Config['pagetitle'];
        } elseif (!empty($controller->Config['pagetitle'])){
            $this->GUI['pagetitle'] = $controller->Config['pagetitle'];
        } elseif (!empty($this->GUI['pagetitle'])){
            $this->GUI['pagetitle'] = $this->GUI['pagetitle'];
        }
        else{
            $this->GUI['pagetitle'] = '';
        }
        $controller->set('GUI', $this->GUI);
    }
    
    function niceUrl($text, $AddHtmlEnd = TRUE){
		$text = trim ($text);
		#$text = preg_replace('{(.)\1+}','$1',$text);
		$text = ereg_replace(' ', '-', $text);
		$text = ereg_replace('أ|إ|آ', 'ا', $text);
		$text = ereg_replace('ـ', '', $text);
		$text = ereg_replace('ّ', '', $text);
		$text = ereg_replace('َ', '', $text);
		$text = ereg_replace('ً', '', $text);
		$text = ereg_replace('ُ', '', $text);
		$text = ereg_replace('ٌ', '', $text);
		$text = ereg_replace('ِ', '', $text);
		$text = ereg_replace('ٍ', '', $text);
		$text = ereg_replace('~', '', $text);
		$text = ereg_replace('ْ', '', $text);
		$text = ereg_replace('`|\!|\@|\#|\^|\&|\(|\)|\|', '', $text);
		$text = ereg_replace('{|}|\[|\]', '_', $text);
		$text = ereg_replace('\+|\*|\/|\=|\%|\$|×', '', $text);
		$text = ereg_replace(',|\.|\'|;|\?|\<|\>|"|:', '', $text);
		$text = ereg_replace('^_', '', $text);
		$text = ereg_replace('_$', '', $text);
        $text = ereg_replace('…', '', $text);
        
        
		if ($AddHtmlEnd) {
			$text .= '.html';
		}
		return $text;
	}
}

?>