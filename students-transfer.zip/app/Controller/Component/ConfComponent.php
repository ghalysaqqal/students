<?php
class ConfComponent extends Component
{
    var $method = '';
    var $name = 'Conf';
    var $Config;
    var $Language;
    
    var $pages;
    var $banners;
    var $contactus;
    var $slider;
    var $poll;
    var $maillist;
    var $sponsers;
    var $media;
    var $comments;
    var $links;
    var $nodes;
    var $menus;
    var $privilege;
    var $pos;
    var $faq;


    // assigns values of referencing controller
    function startup(Controller $controller){
        $this->name = $controller->name;
        $this->GetConfig($controller); 
        $this->GetLanguage($controller);
        $this->InitLanguage($controller);        
        
        $this->loadData($controller); 
        $this->loadData_admin($controller);
    }

    // Load Config Model
    private function loadConfigModel(&$controller)
    {
        if (!isset($controller->ConfdbModel))
        {
            App::uses('Confdb', 'Model');
            $controller->Confdb = new Confdb();
        }
    }
    
    private function loadLanguageModel(&$controller)
    {
        if (!isset($controller->LangModel))
        {
            App::uses('Lang', 'Model');
            $controller->Lang = new Lang();
        }
    }
    
    
    private function loadPagetextModel(&$controller)
    {
        if (!isset($controller->PageText))
        {
            App::uses('Pagetext', 'Model');
            $controller->Pagetext = new Pagetext();
        }
    }
    
    private function loadCategorytypeModel(&$controller)
    {
        if (!isset($controller->Categorytype))
        {
            App::uses('Categorytype', 'Model');
            $controller->Categorytype = new Categorytype();
        }
    }
  
    private function loadRequestModel(&$controller)
    {
        if (!isset($controller->Request))
        {
            App::uses('Request', 'Model');
            $controller->Request = new Request();
        }
    }
    
    private function loadComplaintModel(&$controller)
    {
        if (!isset($controller->Complaint))
        {
            App::uses('Complaint', 'Model');
            $controller->Complaint = new Complaint();
        }
    }
    
    private function loadProblemModel(&$controller)
    {
        if (!isset($controller->Problem))
        {
            App::uses('Problem', 'Model');
            $controller->Problem = new Problem();
        }
    }

    
    private function loadData(&$controller)
    {
        
    }
    
    private function loadData_admin(&$controller){
        $this->loadRequestModel($controller);
        $controller->set('request_count', $controller->Request->find('count', array('conditions' => "`Request`.`isRead` = '-1'")));
        
        $this->loadComplaintModel($controller);
        $controller->set('complaint_count', $controller->Complaint->find('count', array('conditions' => "`Complaint`.`isRead` = '-1'")));
        
        $this->loadProblemModel($controller);
        $controller->set('problems_count', $controller->Problem->find('count', array('conditions' => "`Problem`.`isRead` = '-1'")));

        $this->loadCategorytypeModel($controller);
        $controller->set('types', $controller->Categorytype->getAll());
        
        $this->loadLanguageModel($controller);
        $controller->set('_langs', $controller->Lang->getLangs());
        
        ###
        $fields = array('Confdb.key', 'Confdb.value');
        
        //check if display pages
        $this->pages = Cache::read('pages');
        if($this->pages == false){
            $cond = "`Confdb`.`key` = 'pages'";
            $this->pages = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('pages', $this->pages);
        }
        $controller->set('_pages', $this->pages);
        
        //check if display banners
        $this->banners = Cache::read('banners');
        if($this->banners == false){
            $cond = "`Confdb`.`key` = 'banners'";
            $this->banners = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('banners', $this->banners);
        }
        $controller->set('_banners', $this->banners);
        
        //check if display contactus
        $this->contactus = Cache::read('contactus');
        if($this->contactus == false){
            $cond = "`Confdb`.`key` = 'contactus'";
            $this->contactus = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('contactus', $this->contactus);
        }
        $controller->set('_contactus', $this->contactus);
        
        //check if display slider
        $this->slider = Cache::read('slider');
        if($this->slider == false){
            $cond = "`Confdb`.`key` = 'slider'";
            $this->slider = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('slider', $this->slider);
        }
        $controller->set('_slider', $this->slider);
        
        //check if display poll
        $this->poll = Cache::read('poll');
        if($this->poll == false){
            $cond = "`Confdb`.`key` = 'poll'";
            $this->poll = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('poll', $this->poll);
        }
        $controller->set('_poll', $this->poll);
        
        //check if display maillist
        $this->maillist = Cache::read('maillist');
        if($this->maillist == false){
            $cond = "`Confdb`.`key` = 'maillist'";
            $this->maillist = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('maillist', $this->maillist);
        }
        $controller->set('_maillist', $this->maillist);
        
        //check if display sponsers
        $this->sponsers = Cache::read('sponsers');
        if($this->sponsers == false){
            $cond = "`Confdb`.`key` = 'sponsers'";
            $this->sponsers = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('sponsers', $this->sponsers);
        }
        $controller->set('_sponsers', $this->sponsers);
        
        //check if display media
        $this->media = Cache::read('media');
        if($this->media == false){
            $cond = "`Confdb`.`key` = 'media'";
            $this->media = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('media', $this->media);
        }
        $controller->set('_media', $this->media);
        
        //check if display comments
        $this->comments = Cache::read('comments');
        if($this->comments == false){
            $cond = "`Confdb`.`key` = 'comments'";
            $this->comments = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('comments', $this->comments);
        }
        $controller->set('_comments', $this->comments);
        
        //check if display links
        $this->links = Cache::read('links');
        if($this->links == false){
            $cond = "`Confdb`.`key` = 'links'";
            $this->links = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('links', $this->links);
        }
        $controller->set('_links', $this->links);
        
        //check if display nodes
        $this->nodes = Cache::read('nodes');
        if($this->nodes == false){
            $cond = "`Confdb`.`key` = 'nodes'";
            $this->nodes = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('nodes', $this->nodes);
        }
        $controller->set('_nodes', $this->nodes);
        
        //check if display menus
        $this->menus = Cache::read('menus');
        if($this->menus == false){
            $cond = "`Confdb`.`key` = 'menus'";
            $this->menus = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('menus', $this->menus);
        }
        $controller->set('_menus', $this->menus);
        
        //check if display pos
        $this->pos = Cache::read('pos');
        if($this->pos == false){
            $cond = "`Confdb`.`key` = 'pos'";
            $this->pos = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('pos', $this->pos);
        }
        $controller->set('_pos', $this->pos);
        
        //check if display pos
        $this->faq = Cache::read('faq');
        if($this->faq == false){
            $cond = "`Confdb`.`key` = 'faq'";
            $this->faq = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('faq', $this->faq);
        }
        $controller->set('_faq', $this->faq);
        
        //check if display privilege
        $this->privilege = Cache::read('privilege');
        if($this->privilege == false){
            $cond = "`Confdb`.`key` = 'privilege'";
            $this->privilege = $controller->Confdb->find('list', array('conditions' => $cond, 'fields' => $fields));
            Cache::write('privilege', $this->privilege);
        }
        $controller->set('_privilege', $this->privilege);

    }
    
    

  
    private function GetConfig(&$controller)
    {
        $this->loadConfigModel($controller);

        $this->Config = Cache::read('Config');
        if ($this->Config == false)
        {
            $Cond = "`Confdb`.`lang` IS NULL";
            $this->Config = $controller->Confdb->find('list', array('conditions' => $Cond,
                													'fields' => array('Confdb.key', 'Confdb.value'), ));

            $this->Config['Languages'] = $this->Language;
            Cache::write('Config', $this->Config);
        }
        $controller->Config = $this->Config;
        $controller->set('Config', $this->Config);
    }

    private function GetLanguage(&$controller)
    {
        $this->loadLanguageModel($controller);

        $this->Language = Cache::read('Language');
        if ($this->Language == false)
        {
            // All Language Variables
            $this->Language = $controller->Lang->find('list', array('fields' => array('Lang.id',
                                                                                      'Lang.language'), ));

            Cache::write('Language', $this->Language);
        }
        $controller->set('_Language', $this->Language);
    }

    private function InitLanguage(&$controller)
    {
        if (isset($_GET['lang']))
        {
            if ($this->CheckLanguageIfFound($_GET['lang']))
            {
                $controller->Session->write('LANG', $_GET['lang']);
                $this->ActiveLang($controller, $_GET['lang']);
            }
            else
            {
                $controller->Session->write('LANG', $this->DefaultLang());
                $this->ActiveLang($controller, $this->DefaultLang());
            }
        }
        else
        {
            //Check Session
            if ($controller->Session->check('LANG'))
            {
                $lang = $controller->Session->read('LANG');
                if ($this->CheckLanguageIfFound($lang))
                {
                    $this->ActiveLang($controller, $lang);
                }
                else
                {
                    $this->ActiveLang($controller, $this->DefaultLang());
                }
            }
            else
            {
                $this->ActiveLang($controller, $this->DefaultLang());
            }
        }
    }

    // Language Define Or NOT
    private function CheckLanguageIfFound($lang)
    {
        if (array_key_exists($lang, $this->Language))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    private function DefaultLang()
    {
        return 'ara';
    }

    private function ActiveLang(&$controller, $lang)
    {
        // Is languages Uploaded
        if (!array_key_exists($lang, $this->Language))
        {
            die($controller->cakeError('error404'));
        }

        // Define Public Variable
        define('LANG', $lang);

        // Internationalization                        
        App::uses('L10n', 'I18n');
        $controller->L10n = new L10n();    
        $controller->L10n->get($lang);

        return true;
    }
}