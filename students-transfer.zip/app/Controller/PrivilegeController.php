<?php
class PrivilegeController extends AppController {
	var $name = 'Privilege';
	var $uses = array('Admin', 'Acos', 'ArosAcos');
	var $components = array('Conf', 'Gui', 'Auth', 'Acl');
	var $helpers = array('Layout', 'Row', 'Url', 'Pagination');

	var $Config = array();
    
    function admin_index(){
		$this->Auth->AuthAdmin ($this, 'privilege', 'read');

		$this->Gui->layout('admin');
		$this->Gui->headline(__('browse', true));
		$this->Gui->navigation(__('admincp_index', true), '/admin/index');
		$this->Gui->navigation(__('admincp_manage_privilege', true), '/admin/privilege/');
		$this->Gui->navigation(__('browse', true));

		$Admins = $this->Admin->find('all', array('conditions' => "`Admin`.`private` = '-1'"));
		$this->set('Admins', $Admins);
	}

	function admin_add(){
		$this->Auth->AuthAdmin ($this, 'privilege', 'create');

		$this->Gui->layout('admin');
		$this->Gui->headline(__('add', true));
		$this->Gui->navigation(__('admincp_index', true), '/admin/index');
		$this->Gui->navigation(__('admincp_manage_privilege', true), '/admin/privilege/');
		$this->Gui->navigation(__('add', true));

		if (!empty($this->data)) {
			$errormessage = array();

			if (empty($this->data['Admin']['username']) or !preg_match(PATTERN_USERNAME, $this->data['Admin']['username'])) {
				$this->Admin->invalidate('username');
				$errormessage[] = __('adminnamesyntaxerror', true);
			}

			$Count = 1;
			$Count = $this->Admin->find('count', array('conditions' => "`Admin`.`username` = '".$this->data['Admin']['username']."'"));
			//check if adminname exists
			if ($Count > 0) {
				$this->Admin->invalidate('username');
				$errormessage[] = __('adminnameexsits', true);
			}

			if (empty($this->data['Admin']['password'])) {
				$this->Admin->invalidate('password');
				$errormessage[] = __('passwordempty', true);
			}

			if (sizeof($errormessage) > 0) {
				$this->set('errormessage', $errormessage);
				$this->render();
			}else{
				$newadmin['Admin']['adminID'] = NULL;
                $newadmin['Admin']['username'] = $this->data['Admin']['username'];
				$newadmin['Admin']['password'] = md5(Configure::read('Security.salt1') . md5($this->data['Admin']['password']) . Configure::read('Security.salt2'));
				$newadmin['Admin']['AdminActive'] = intval($this->data['Admin']['AdminActive']);

				if ($this->Admin->save($newadmin)) {
					$userID = $this->Admin->getLastInsertId();

					$aro =& $this->Acl->Aro;

					$admin = array(
									'alias' => $this->data['Admin']['username'],
									'parent_id' => NULL,
									'model' => 'Admin',
									'foreign_key' => $userID,
								  );

					$aro->create();
					$aro->save($admin);
					
					$this->redirect('/admin/privilege/index?result=done');
				}
			}
		}
	}

	function admin_edit($adminID){
		$this->Auth->AuthAdmin ($this, 'privilege', 'update');

		$Admin = $this->Admin->find('first', array('conditions' => "`Admin`.`adminID` = '$adminID'"));
		$this->set('Admin', $Admin);

		$this->Gui->layout('admin');
		$this->Gui->headline(__('edit', true));
		$this->Gui->navigation(__('admincp_index', true), '/admin/index');
		$this->Gui->navigation(__('admincp_manage_privilege', true), '/admin/privilege/');
		$this->Gui->navigation($Admin['Admin']['username']);
		$this->Gui->navigation(__('edit', true));
		
		if (!empty($this->data))
		{
		    $this->Admin->set($this->data);
		    if ($this->Admin->validates())
		    {
			$admin['Admin']['adminID'] = $adminID;
            if(empty($this->data['Admin']['password'])){
                $admin['Admin']['password'] = $Admin['Admin']['adminID'];
            }else{
                $admin['Admin']['password'] = md5(Configure::read('Security.salt1') . md5($this->data['Admin']['password']) . Configure::read('Security.salt2'));    
            }
			
	
			if ($this->Admin->save($admin, false, array('username', 'password')))
			{                   
                $this->redirect('/admin/privilege/edit/'.$adminID.'?result=done');
			}
		    }
		    else
			     $this->render();
		}
		else{
			$this->Admin->data = $this->Admin;
		}

	}

	function admin_delete($adminID){
		$this->Auth->AuthAdmin ($this, 'privilege', 'delete');

		if ($this->Admin->delete($adminID)) {
			 $this->redirect('/admin/privilege/index/');
		}
	}

	function admin_permission($adminID){
		$this->Auth->AuthAdmin ($this, 'privilege', 'update');

		$adminID = intval ($adminID);
		if ($adminID == 0) {
			die ('User NOT found');
		}

		$Admin = $this->Admin->find('first', array('conditions' => "`Admin`.`adminID` = '$adminID'"));
		if (!is_array($Admin)) {
			die ('User NOT found');
		}
		$this->set ('Admin', $Admin);

		$Conts = $this->Acos->find ('list', array ('conditions' => "`Acos`.`parent_id` IS NULL", 'fields' => array('id', 'alias')));
		$Permissions = array();
		$Aro = array('model' => 'Admin', 'foreign_key' => $adminID);
		foreach($Conts as $k => $Cont){
			$Permissions[$Cont] = array ();
			$Permissions[$Cont]['create'] = FALSE;
			$Permissions[$Cont]['read'] = FALSE;
			$Permissions[$Cont]['update'] = FALSE;
			$Permissions[$Cont]['delete'] = FALSE;
			if ($this->Acl->check($Aro, $Cont, 'create')) {
				$Permissions[$Cont]['create'] = TRUE;
			}else{
				$Permissions[$Cont]['create'] = FALSE;
			}
			if ($this->Acl->check($Aro, $Cont, 'read')) {
				$Permissions[$Cont]['read'] = TRUE;
			}else{
				$Permissions[$Cont]['read'] = FALSE;
			}
			if ($this->Acl->check($Aro, $Cont, 'update')) {
				$Permissions[$Cont]['update'] = TRUE;
			}else{
				$Permissions[$Cont]['update'] = FALSE;
			}
			if ($this->Acl->check($Aro, $Cont, 'delete')) {
				$Permissions[$Cont]['delete'] = TRUE;
			}else{
				$Permissions[$Cont]['delete'] = FALSE;
			}
		}

		if (!empty($this->data)) {
			foreach($Conts as $k => $Cont){
				if ($this->data[$Cont]['read'] == 1) {
					$this->Acl->allow($Aro, $Cont, 'read');
					$Permissions[$Cont]['read'] = TRUE;
				}else{
					$this->Acl->deny($Aro, $Cont, 'read');
					$Permissions[$Cont]['read'] = FALSE;
				}

				if ($this->data[$Cont]['create'] == 1) {
					$this->Acl->allow($Aro, $Cont, 'create');
					$Permissions[$Cont]['create'] = TRUE;
				}else{
					$this->Acl->deny($Aro, $Cont, 'create');
					$Permissions[$Cont]['create'] = FALSE;
				}

				if ($this->data[$Cont]['update'] == 1) {
					$this->Acl->allow($Aro, $Cont, 'update');
					$Permissions[$Cont]['update'] = TRUE;
				}else{
					$this->Acl->deny($Aro, $Cont, 'update');
					$Permissions[$Cont]['update'] = FALSE;
				}

				if ($this->data[$Cont]['delete'] == 1) {
					$this->Acl->allow($Aro, $Cont, 'delete');
					$Permissions[$Cont]['delete'] = TRUE;
				}else{
					$this->Acl->deny($Aro, $Cont, 'delete');
					$Permissions[$Cont]['delete'] = FALSE;
				}
			}

			$this->redirect($_SERVER['HTTP_REFERER'].'?r=savedone');
		}

		$this->set ('Conts', $Conts);
		$this->set ('Permissions', $Permissions);

		$this->Gui->layout('admin');
        $this->Gui->headline(__('permission', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_privilege', true), '/admin/privilege/');
        $this->Gui->navigation($Admin['Admin']['username']);
        $this->Gui->navigation(__('permission', true));
	}

	

	function admin_nopermission() {
		$this->Auth->AuthAdmin ($this);

		$this->Gui->layout('admin');
        $this->Gui->headline(__('nopermission', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_privilege', true), '/admin/privilege/');
        $this->Gui->navigation(__('nopermission', true));
	}
    
    
    function admin_active($id){
        $this->Auth->AuthAdmin ($this, 'privilege', 'update');
        
        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }
        $cond = "`Admin`.`adminID` = '$id'";
        $data = $this->Admin->getAdmin($cond);
        $data['Admin']['adminID']     = $data['Admin']['adminID'];
        $data['Admin']['AdminActive'] = $data['Admin']['AdminActive'] * -1;
        if ($this->Admin->save($data, false, array('AdminActive'))) {
            $this->redirect('/admin/privilege/index/');
        }
    }


	function beforeRender(){
		$this->Gui->DoGUIvar ($this);
	}

}