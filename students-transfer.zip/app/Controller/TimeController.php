<?php

App::uses('AppController', 'Controller');

class TimeController extends AppController {

    var $name = 'Time';
    var $uses = array('Time', 'Bustime', 'Studenttime', 'Schedule');
    var $components = array('Conf', 'Gui', 'Auth',);
    var $helpers = array('Layout', 'Pagination', 'Row', 'Url',);
    var $Config = array();

    function admin_index() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('browse', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Time Management', true), '/admin/time/');
        $this->Gui->navigation(__('browse', true));

        $this->set('times', $this->Time->getAll());
    }

    function admin_add() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Time Management', true), '/admin/time/');
        $this->Gui->navigation(__('add', true));
        
        if (!empty($this->data)) {
            if ($this->Time->validates()) {
                $time['Time']['id'] = null;

                if ($this->Time->save(array_merge($this->data['Time'], $time['Time']))) {
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
                    $this->redirect('/admin/time/index/?result=done');
                }
            }
        }
    }

    function admin_edit($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $cond = "`Time`.`id` = '$id'";
        $Time = $this->Time->getTime($cond);
        if (!is_array($Time)) {
            $this->redirect('/admin/time');
            die();
        }
        $this->set('time', $Time);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Time Management', true), '/admin/time/');

        if (!empty($this->data)) {
            $this->Time->set($this->data);

            if ($this->Time->validates()) {
                $this->Time->id = $id;

                if ($this->Time->save($this->Time->data['Time'])) {
                    //update bus times
                    $this->Bustime->updateTimes($id, $this->data['Time']['time']);                    
                    
                    //update student times
                    if($Time['Time']['type']=='GOING')
                        $this->Studenttime->updateGoingTimes($id, $this->data['Time']['time']);
                    else
                        $this->Studenttime->updateReturnTimes($id, $this->data['Time']['time']);
                    
                    //update schedule times
                    $this->Schedule->updateTimes($id, $this->data['Time']['time']);     
                    die();
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

                    $this->redirect('/admin/time/');
                }
            }
        } else {
            $this->Time->data = $Time['Time'];
        }
    }

    function admin_delete($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $Time = $this->Time->find('first', array('conditions' => "`Time`.`id` = '$id'"));
        if (!is_array($Time)) {
            $this->redirect('/admin/time');
            die();
        }

        if ($this->Time->delete($id)) {
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            $this->redirect('/admin/time/index');
        }
    }


    function beforeRender() {
        $this->Gui->DoGUIvar($this);
    }

}
