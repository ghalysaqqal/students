<?php

class MenuController extends AppController
{
    var $name = 'Menu';
    var $uses = array('Menu', 'Menutext', 'Lang', 'Itemtext', 'Nodetext', 'Pagetext', 'Albumtext');
    var $components = array('Conf', 'Gui', 'Auth', 'Banners', 'Acl');
    var $helpers = array('Layout', 'Row', 'Url');

    var $Config = array();

    function admin_index($parentID = null)
    {
        $this->Auth->AuthAdmin ($this, 'menu', 'read');

        if (!isset($parentID) || empty($parentID)){
            $cond = "`Menu`.`parentID` IS NULL";
            $this->set('grandParentID', 0);
        }else{
            $cond = "`Menu`.`parentID` = '$parentID'";
            
            $cond_menu = "`Menu`.`id` = '" . $parentID . "'";
            $menu = $this->Menu->getMenu($cond_menu);
            $this->set('grandParentID', $menu['Menu']['parentID']);
        }

        $this->set('parentID', intval($parentID));
        
        $this->set('menutexts', $this->Menu->getAll($cond)); 
        $this->set('Langs', $this->Lang->getLangs()); 

        $this->Gui->layout('admin');
        $this->Gui->headline(__('admincp_manage_menu', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_menu', true));
    }


    function admin_add($parentID = null){
        
        $this->Auth->AuthAdmin ($this, 'menu', 'create');
        
        $this->set('Langs', $Langs = $this->Lang->getLangs());
        
        $this->set('grandParentID', intval($parentID));
        
        //items
        $cond="`Itemtext`.`local` = '".LANG."' AND `Item`.`active` = '1'";
        $fields=array('name', 'Item.id');
        $this->set('items', $this->Itemtext->getAll($cond,$fields));
        
        if($this->Config['nodes']==1){
            //nodes
            $cond="`Nodetext`.`local` = '".LANG."' AND `Node`.`active` = '1'";
            $fields=array('title', 'Node.id');
            $this->set('nodes', $this->Nodetext->getAll($cond,$fields));
        }
        
        if($this->Config['pages']==1){
            //pages
            $cond="`Pagetext`.`local` = '".LANG."' AND `Page`.`active` = '1'";
            $fields=array('title', 'Page.url');
            $this->set('pages', $this->Pagetext->getAll($cond,$fields));
        }
        
        if($this->Config['media']==1){
            //albums
            $cond="`Albumtext`.`local` = '".LANG."' AND `Album`.`active` = '1'";
            $fields=array('name', 'Album.id');
            $this->set('albums', $this->Albumtext->getAlbums($cond,$fields));
        }
        
        
            
        if (!empty($this->data)) {
            $this->Menu->set($this->data);
            
            $menu['parentID'] = intval($parentID);
            
            if ($this->Menu->validates()) {
                
                if ($menu['parentID'] == 0){
                  $menu['parentID'] = NULL;
                }else{
                  $menu['parentID'] = intval ($parentID);
                }
                $menu['ord'] = intval(@$this->data['Menu']['ord']);
                $menu['newTab'] = intval(@$this->data['Menu']['newTab']);
                $menu['hasChildren'] = intval(@$this->data['Menu']['hasChildren']);
                
                if($this->data['Menu']['path']=='OTHER'){
                    $menu['Menu']['path'] = $this->data['Menu']['path_other'];
                }

                if ($this->Menu->save($menu)) {
                    $menu_id = $this->Menu->getLastInsertID ();

                    foreach($Langs as $lang){
                        $text['Menutext']['id'] = NULL;
                        $text['Menutext']['menu_id'] = $menu_id;
                        $text['Menutext']['local'] = $lang['Lang']['id'];
                        $text['Menutext']['title'] = $this->data['Menutext']['title_'.$lang['Lang']['id']];
                        
                        $this->Menutext->save($text);
                    }
                    
                    $this->redirect('/admin/menu/index/'.$parentID.'?result=done');
                }

            }
        }

        $this->Gui->layout('admin');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_menu', true), '/admin/menu/index');
        $this->Gui->navigation(__('add', true));
    }


    function admin_edit($id)
    {
        $this->Auth->AuthAdmin ($this, 'menu', 'update');

        $id = intval($id);
        $cond = "`Menu`.`id` = '$id'";
        $menu = $this->Menu->getMenu($cond);
        if (!is_array($menu))
        {
            $this->redirect('/admin/menu');
            die();
        }
        $this->set('menu', $menu);
        $this->set('menutext', $menutext = $this->Menutext->find('all', array('conditions' => "`Menutext`.`menu_id` = '".$menu['Menu']['id']."'"))) ;
        
        $this->set('grandParentID', intval($menu['Menu']['parentID']));
        
        //items
        $cond="`Itemtext`.`local` = '".LANG."' AND `Item`.`active` = '1'";
        $fields=array('name', 'Item.id');
        $this->set('items', $this->Itemtext->getAll($cond,$fields));
        
        if($this->Config['nodes']==1){
            //nodes
            $cond="`Nodetext`.`local` = '".LANG."' AND `Node`.`active` = '1'";
            $fields=array('title', 'Node.id');
            $this->set('nodes', $this->Nodetext->getAll($cond,$fields));
        }
        
        if($this->Config['pages']==1){
            //pages
            $cond="`Pagetext`.`local` = '".LANG."' AND `Page`.`active` = '1'";
            $fields=array('title', 'Page.url');
            $this->set('pages', $this->Pagetext->getAll($cond,$fields));
        }
        
        if($this->Config['media']==1){
            //albums
            $cond="`Albumtext`.`local` = '".LANG."' AND `Album`.`active` = '1'";
            $fields=array('name', 'Album.id');
            $this->set('albums', $this->Albumtext->getAlbums($cond,$fields));
        }
        
        if (!empty($this->data))
        {
            $this->Menu->set($this->data);
            if ($this->Menu->validates())
            {
                $menu['Menu']['id']= $id;
                $menu['Menu']['newTab'] = intval(@$this->data['Menu']['newTab']);
                $menu['Menu']['hasChildren'] = intval(@$this->data['Menu']['hasChildren']);
                
                if($this->data['Menu']['path']=='OTHER'){
                    $menu['Menu']['path'] = $this->data['Menu']['path_other'];
                }else
                    $menu['Menu']['path'] = $this->data['Menu']['path'];

                if ($this->Menu->save(array_merge($this->data['Menu'], $menu['Menu'])))
                {
                    foreach($menutext as $data){
                        $text['Menutext']['id'] = $data['Menutext']['id'];
                        $text['Menutext']['title'] = $this->data['Menutext']['title_'.$data['Menutext']['local']];
                        
                        $this->Menutext->save($text['Menutext'], false, array('title'));
                    } 
                
                    $this->redirect('/admin/menu/index/'.$menu['Menu']['parentID'].'/?result=done');
                }
            }
            else
                $this->render();
        }
        else{
			$this->Menu->data = $menu['Menu'];
		}

        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_menu', true), '/admin/menu/index');
        $this->Gui->navigation(__('edit', true));
    }

    function admin_delete($id)
    {
        $this->Auth->AuthAdmin ($this, 'menu', 'delete');

        $id = intval($id);
        $cond = "`Menu`.`id` = '$id'";
        $menu = $this->Menu->getMenu($cond);
        if (!is_array($menu))
        {
            $this->redirect('/admin/menu');
            die();
        }
        
        $this->Menu->removeFromTree($id, false);

        if($this->Menu->delete($id)){
            
            foreach($menu['Menutext'] as $data){
                $this->Menutext->delete($data['id']);
            }
            
            $this->redirect('/admin/menu/index/' . $menu['Menu']['parentID'] . '?time=' . time());
        }
    }
    
    function admin_deletemenu($id)
    {
        $this->Auth->AuthAdmin ($this, 'menu', 'delete');

        $id = intval($id);
        $cond = "`Menu`.`id` = '$id'";
        $menu = $this->Menu->getMenu($cond);
        $this->Menu->removeFromTree($id, false);

        if($this->Menu->delete($id)){
            foreach($menu['Menutext'] as $data){
                $this->Menutext->delete($data['id']);
            }
        }
    }
    
    function admin_active($id){
        $this->Auth->AuthAdmin ($this, 'menu', 'update');
        
        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }
        $cond = "`Menu`.`id` = '$id'";
        $data = $this->Menu->getMenu($cond);
        $data['Menu']['id']     = $data['Menu']['id'];
        $data['Menu']['active'] = $data['Menu']['active'] * -1;
        if ($this->Menu->save($data, false, array('active'))) {
            $this->redirect('/admin/menu/index/');
        }
    }


    /*  *********** CAUTION *********** */
    /* Please Remove This Function when Finish */
    /*  *********** CAUTION *********** */
    function admin_reorder()
    {
        print_r($this->Menu->recover());
        print_r($this->Menu->verify());
        die();
    }
    /*  *********** CAUTION *********** */
    /* Please Remove This Function when Finish */
    /*  *********** CAUTION *********** */

    function beforeFilter()
    {

    }

    function beforeRender()
    {
        $this->Gui->DoGUIvar($this);
    }
}

?>