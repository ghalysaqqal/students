<?php
App::uses('AppController', 'Controller');

class IndexController extends AppController {

    public $name = 'Index';
    public $uses = array('Confdb', 'Country', 'Slidertext', 'Itemtext', 'Category', 'Icon', 'Item', 'Page', 'Node',
                         'Bus', 'Servicerate', 'Schedule');
    var $components = array('Conf', 'Gui', 'Auth', 'Email',);
    var $helpers = array('Layout', 'Url', 'Row', 'Text');
    var $Config = array();

    function index() {
        $this->redirect('/student/add');
        $this->Gui->layout('index');
        //slider
        $cond_slider = "`Slidertext`.`local` = '" . LANG . "' AND `Slider`.`active` = '1'";
        $fields_s = array('Slidertext.title', 'Slidertext.desc', 'Slider.filename');
        $this->set('slider', $this->Slidertext->getAll($cond_slider, $this->Config['slider_items'], $fields_s));
    }

    function icons(){
        $this->set('icons', $this->Icon->getIcons());
    }

    function admin_fileupload(){
        $this->Auth->AuthAdmin($this);
    }

    public function admin_index() {
        $this->Auth->AuthAdmin($this);
        if(!empty($this->Config['dashboard_url']))
            $this->redirect($this->Config['dashboard_url']);

        $this->set('buses', $this->Bus->getAll());

        $service_full_rate=  $this->Confdb->getValue('service-full-rate');
        $service_rate=  $this->Servicerate->getRateSum();
        $this->set('sr', round((($service_rate*10)/$service_full_rate)*2), 1);

        $cond="(`Schedule`.`done` = '1' OR `Schedule`.`late` = '1') AND `Schedule`.`finished` = '1'";
        $this->set('full_delivery', $this->Schedule->getCount($cond));

        $fields=array('COUNT(area_id) as area_count' , 'area_id');
        $order="area_count DESC";
        $this->set('area', $this->Bus->getBusGroupByArea(null, $fields, $order));

        $this->Gui->pagetitle(__('dashboard', true));
        $this->Gui->headline(__('dashboard', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
    }

    function beforeRender() {
        $this->Gui->DoGUIvar($this);
    }

    function admin_selectsettings(){
        $this->Auth->AuthAdmin($this);

        $this->Gui->pagetitle(__('Select Settings', true) );
        $this->Gui->headline(__('Select Settings', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Select Settings', true));
    }
    function admin_settings() {
        $this->Auth->AuthAdmin($this);

        /*
        if(isset($this->data['Confdb']['setting']) && in_array(strtoupper($this->data['Confdb']['setting']), array('GENERAL', 'SN', 'CONTENT', 'EMAIL', 'META-TAG', 'MAP')))
            $setting_type = $this->data['Confdb']['setting'];
        elseif(isset($_GET['setting']) && !empty($_GET['setting']) && in_array(strtoupper($_GET['setting']), array('GENERAL', 'SN', 'CONTENT', 'EMAIL', 'META-TAG', 'MAP')))
             $setting_type = strtoupper($_GET['setting']);
        else
            $setting_type = 'GENERAL';
        */

        $general = $this->Confdb->find('all', array('conditions' => "`Confdb`.`controller` = 'Settings' AND `Confdb`.`setting` LIKE 'GENERAL' AND `Confdb`.`key` != 'default_lang'", 'order' => "`Confdb`.`ord` ASC"));
        $sn = $this->Confdb->find('all', array('conditions' => "`Confdb`.`controller` = 'Settings' AND `Confdb`.`setting` LIKE 'SN' AND `Confdb`.`key` != 'default_lang'", 'order' => "`Confdb`.`ord` ASC"));
        $content = $this->Confdb->find('all', array('conditions' => "`Confdb`.`controller` = 'Settings' AND `Confdb`.`setting` LIKE 'CONTENT' AND `Confdb`.`key` != 'default_lang'", 'order' => "`Confdb`.`ord` ASC"));
        $meta_tag = $this->Confdb->find('all', array('conditions' => "`Confdb`.`controller` = 'Settings' AND `Confdb`.`setting` LIKE 'META-TAG' AND `Confdb`.`key` != 'default_lang'", 'order' => "`Confdb`.`ord` ASC"));
        $email = $this->Confdb->find('all', array('conditions' => "`Confdb`.`controller` = 'Settings' AND `Confdb`.`setting` LIKE 'EMAIL' AND `Confdb`.`key` != 'default_lang'", 'order' => "`Confdb`.`ord` ASC"));

        $this->set('general', $general);
        $this->set('sn', $sn);
        $this->set('content', $content);
        $this->set('meta_tag', $meta_tag);
        $this->set('email', $email);

        $this->set('langs', $Langs = $this->Lang->getList());

        $this->set('map', $this->Confdb->find('first', array('conditions' => "`Confdb`.`controller` = 'Map'",)));
        #$this->set('lang', $this->Confdb->find('first', array('conditions' => "`Confdb`.`key` = 'default_lang'",)));

        if (!empty($this->data)) {

            foreach ($general as $key => $data) {
                $this->Confdb->query("UPDATE config SET `value` = '" . addslashes($this->data['Confdb'][$data['Confdb']['key']]) .
                                     "' WHERE `key` = '" . $data['Confdb']['key'] . "'");
            }

            foreach ($sn as $key => $data) {
                $this->Confdb->query("UPDATE config SET `value` = '" . addslashes($this->data['Confdb'][$data['Confdb']['key']]) .
                                     "' WHERE `key` = '" . $data['Confdb']['key'] . "'");
            }

            foreach ($content as $key => $data) {
                $this->Confdb->query("UPDATE config SET `value` = '" . addslashes($this->data['Confdb'][$data['Confdb']['key']]).
                                     "' WHERE `key` = '" . $data['Confdb']['key'] . "'");
            }

            foreach ($meta_tag as $key => $data) {
                $this->Confdb->query("UPDATE config SET `value` = '" . addslashes($this->data['Confdb'][$data['Confdb']['key']]) .
                                     "' WHERE `key` = '" . $data['Confdb']['key'] . "'");
            }

            foreach ($email as $key => $data) {
                $this->Confdb->query("UPDATE config SET `value` = '" . addslashes($this->data['Confdb'][$data['Confdb']['key']]) .
                                     "' WHERE `key` = '" . $data['Confdb']['key'] . "'");
            }

            if(!empty($this->data['Confdb']['admin_email'])){
                $this->Admin->changeEmailAdmin('admin', $this->data['Confdb']['admin_email']);
            }

            if(!empty($this->data['Confdb']['map'])){
                //update map center
                $newmapvalue = $this->Confdb->getmap($this->data['Confdb']['map']);
                $this->Confdb->query("UPDATE `config` SET `value` = '$newmapvalue' WHERE `config`.`key` = 'map'");
            }

            #$this->Confdb->query("UPDATE `config` SET `value` = '".$this->data['Confdb']['lang']."' WHERE `config`.`key` = 'default_lang'");

            Cache::delete('config');
            $this->redirect('/admin/index/settings?result=done');
        }

        $this->Gui->pagetitle(__('Settings', true) );
        $this->Gui->headline(__('Settings', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Settings', true));
    }

    function admin_admin() {
        $this->Auth->AuthAdmin($this);
        $this->set('drwp', $this->Country->find('first', array('conditions' => "`Country`.`active` = '" . $this->country_id . "'", 'fields' => array('id'))));
        $settings = $this->Confdb->find('all', array('conditions' => "`Confdb`.`controller` = 'Admin'",
            'order' => "`Confdb`.`ord` ASC"
        ));
        $this->set('settings', $settings);

        if (!empty($this->data)) {
            foreach ($settings as $key => $data) {
                $this->Confdb->query("UPDATE config SET `value` = '" . $this->data['Confdb'][$data['Confdb']['key']] . "' WHERE `key` = '" . $data['Confdb']['key'] . "'");
            }

            Cache::delete('config');

            Cache::delete('pages');
            Cache::delete('banners');
            Cache::delete('contactus');
            Cache::delete('slider');
            Cache::delete('poll');
            Cache::delete('maillist');
            Cache::delete('sponsers');
            Cache::delete('media');
            Cache::delete('comments');
            Cache::delete('links');
            Cache::delete('nodes');
            Cache::delete('menus');
            Cache::delete('pos');
            Cache::delete('faq');
            Cache::delete('privilege');

            $this->redirect('/admin/index/admin?result=done');
        }
    }

    function admin_updatetype() {
        $this->Auth->AuthAdmin($this);
        $this->set('drwp', $this->Country->find('first', array('conditions' => "`Country`.`active` = '" . $this->country_id . "'", 'fields' => array('id'))));
        $settings = $this->Confdb->find('all', array('order' => "`Confdb`.`controller` ASC"));
        $this->set('settings', $settings);

        $types_config = array('Settings' => __('Settings', true),
                       'Public' => __('Public', true),
                       'Admin' => __('Admin', true),
                       'Smtp' => __('Smtp', true),
                       'Map' => __('Map', true));

        $this->set('types_config', $types_config);

        if (!empty($this->data)) {

            foreach ($settings as $key => $data) {
                $this->Confdb->query("UPDATE config SET `controller` = '" . $this->data['Confdb'][$data['Confdb']['key']] . "' WHERE `key` = '" . $data['Confdb']['key'] . "'");
            }

            Cache::delete('config');
            $this->redirect('/admin/index/updatetype?result=done');
        }

        $this->Gui->pagetitle(__('Settings', true));
        $this->Gui->headline(__('Settings', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Settings', true));
    }

    var $country_id = 7;

    /**
     * Dumps the MySQL database that this controller's model is attached to.
     * This action will serve the sql file as a download so that the user can save the backup to their local computer.
     *
     * @param string $tables Comma separated list of tables you want to download, or '*' if you want to download them all.
     */
    function database_mysql_dump($tables = '*') {

        $return = '';

        $modelName = $this->modelClass;

        $dataSource = $this->{$modelName}->getDataSource();
        $databaseName = $dataSource->getSchemaName();


        // Do a short header
        $return .= '-- Database: `' . $databaseName . '`' . "\n";
        $return .= '-- Generation time: ' . date('D jS M Y H:i:s') . "\n\n\n";


        if ($tables == '*') {
            $tables = array();
            $result = $this->{$modelName}->query('SHOW TABLES');
            foreach ($result as $resultKey => $resultValue) {
                $tables[] = current($resultValue['TABLE_NAMES']);
            }
        } else {
            $tables = is_array($tables) ? $tables : explode(',', $tables);
        }


        // Run through all the tables
        foreach ($tables as $table) {
            $tableData = $this->{$modelName}->query('SELECT * FROM ' . $table);

            $return .= 'DROP TABLE IF EXISTS ' . $table . ';';
            $createTableResult = $this->{$modelName}->query('SHOW CREATE TABLE ' . $table);
            $createTableEntry = current(current($createTableResult));
            $return .= "\n\n" . $createTableEntry['Create Table'] . ";\n\n";

            // Output the table data
            foreach ($tableData as $tableDataIndex => $tableDataDetails) {

                $return .= 'INSERT INTO ' . $table . ' VALUES(';

                foreach ($tableDataDetails[$table] as $dataKey => $dataValue) {

                    if (is_null($dataValue)) {
                        $escapedDataValue = 'NULL';
                    } else {
                        // Convert the encoding
                        $escapedDataValue = $dataValue;

                        // Escape any apostrophes using the datasource of the model.
                        $escapedDataValue = $this->{$modelName}->getDataSource()->value($escapedDataValue);
                    }

                    $tableDataDetails[$table][$dataKey] = $escapedDataValue;
                }
                $return .= implode(',', $tableDataDetails[$table]);

                $return .= ");\n";
            }

            $return .= "\n\n\n";
        }

        // Set the default file name
        $fileName = $databaseName . '-backup-' . date('Y-m-d_H-i-s') . '.sql';

        // Serve the file as a download
        $this->autoRender = false;
        $this->response->type('Content-Type: text/x-sql');
        $this->response->download($fileName);
        $this->response->body($return);
    }

    function deleteAll(){
        $id=intval($_POST['id']);
        $type=$_POST['type'];
        if(!empty($id)&!empty($type)){
            $this->redirect('/admin/'.$type.'/delete'.$type.'/'.$id);
            die();
        }
    }

    function delete_thumb(){
        $this->Gui->layout('blank');
        $id=intval($_POST['id']);
        $type=$_POST['type'];
        $table=$_POST['table'];
        $filename=$_POST['filename'];
        if(!empty($id)&!empty($type)){
            $table_name = ucfirst($table);
            $this->$table_name->query("UPDATE `$table` SET `thumb` = NULL WHERE `$table`.`id` = $id");

            $path = WWW_ROOT . 'upload' . DS . $type . DS;
            $path_thum = $path . 'thum' . DS;
            $path_small = $path . 'small' . DS;

            @unlink($path . $filename);
            @unlink($path_thum . $filename);
            @unlink($path_small . $filename);

        }
    }

}
