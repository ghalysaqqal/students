<?php

class SitemapController extends AppController {

    var $name = 'Sitemap';
    var $uses = array('Item', 'Page', 'Node');
    var $components = array('Conf', 'Gui',);
    var $helpers = array('Url');
    var $Config = array();
    var $layout = 'rss';

    function buildSitemap() {

        App::import('Vendor', 'google_sitemap');
        $url = $this->Config['url'];
        $Obj = & new google_sitemap();

        // Home Page
        $site_map_item = & new google_sitemap_item($url, NULL, 'daily', '1.0');
        $Obj->add_item($site_map_item);

        //items
        $items = $this->Item->find('all', array('conditions' => "`Item`.`active` = '1'",
            'fields' => array('id'),
            'order' => "`Item`.`id` DESC",
            'limit' => 50000,
            'page' => 1
        ));

        foreach ($items as $item) {
            $u = sprintf('%s/view/%s', $url, $item['Item']['id']);
            $site_map_item = & new google_sitemap_item($u, NULL, 'weekly', '0.8');
            $Obj->add_item($site_map_item);
        }

        //nodes
        $nodes = $this->Node->find('all', array('conditions' => "`Node`.`active` = '1'",
            'fields' => array('id'),
            'order' => "`Node`.`id` DESC",
            'limit' => 50000,
            'page' => 1
        ));

        foreach ($nodes as $node) {
            $u = sprintf('%s/node-%s', $url, $node['Node']['id']);
            $site_map_item = & new google_sitemap_item($u, NULL, 'weekly', '0.8');
            $Obj->add_item($site_map_item);
        }

        //pages
        $pages = $this->Page->find('all', array('conditions' => "`Page`.`active` = '1'",
            'fields' => array('url'),
            'order' => "`Page`.`id` DESC",
            'limit' => 100,
            'page' => 1
        ));

        foreach ($pages as $item) {
            $u = sprintf('%s/page/%s', $url, $item['Page']['url']);
            $site_map_item = & new google_sitemap_item($u, NULL, 'weekly', '0.8');
            $Obj->add_item($site_map_item);
        }

        header("Content-type: application/xml; charset=\"" . $Obj->charset . "\"", true);
        header('Pragma: no-cache');

        print $Obj->build();
        die();
    }

}
