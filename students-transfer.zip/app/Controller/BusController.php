<?php
App::uses('AppController', 'Controller');

class BusController extends AppController {

    var $name = 'Bus';
    var $uses = array('Bus', 'Areatext', 'Time', 'Schedule', 'Buscoordinates', 'Statistics', 'Problem', 'Busrate',
                      'Student', 'Bustime', 'Emailmsg', 'Studenttime');
    var $components = array('Conf', 'Gui', 'Auth', 'Sms', 'Email');
    var $helpers = array('Layout', 'Pagination', 'Row', 'Url',);
    var $Config = array();

    function admin_index() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('browse', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Bus Management', true), '/admin/bus/');
        $this->Gui->navigation(__('browse', true));

        $this->set('buses', $this->Bus->getAll());
    }

    function admin_view($id) {
        $this->Auth->AuthAdmin($this);

        $this->Gui->headline(__('Bus Management', true));
        $this->Gui->navigation(__('Dashboard', true), '/admin/index');
        $this->Gui->navigation(__('Bus Management', true), '/admin/bus/index');
        $this->Gui->navigation(__('Details View', true));

        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }

        $cond = "`Bus`.`id` = '$id'";
        $this->set('bus', $this->Bus->getBus($cond));
    }

    function admin_schedule($bus_id) {
        $this->Auth->AuthAdmin($this);

        $bus_id = intval($bus_id);
        if ($bus_id <= 0) {
            $this->redirect('/admin/bus');
            die();
        }

        $this->Gui->layout('admin');
        $this->Gui->headline(__('schedule', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Bus Management', true), '/admin/bus/');
        $this->Gui->navigation(__('schedule', true));

        if (!isset($_GET['date']) || empty($_GET['date'])) {
            $this->redirect('/admin/bus');
            die();
        }

        $condArray = array();
        if (!empty($_GET['date'])) {
            $date = date('Y-m-d', strtotime($_GET['date']));
            $condArray[] = "`Schedule`.`date` = '$date'";
        }
        $condArray[] = "`Schedule`.`bus_id` = '$bus_id'";

        $cond = implode(' AND ', $condArray);
        $this->set('schedule', $this->Schedule->getAll($cond));
    }

    function admin_add() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Bus Management', true), '/admin/bus/');
        $this->Gui->navigation(__('add', true));

        App::import('Vendor', 'generatekey');
        $this->set('password', generatekey(8));

        $cond = "`Areatext`.`local` = '" . LANG . "'";
        $this->set('areas', $this->Areatext->getList($cond));

        #$this->set('goings', $this->Time->getList('GOING'));
        #$this->set('returns', $this->Time->getList('RETURN'));

        if (!empty($this->data)) {
            if ($this->Bus->validates()) {
                $bus['Bus']['id'] = null;
                $bus['Bus']['postDate'] = date('Y-m-d H:i:s');
                $bus['Bus']['name']= trim($this->data['Bus']['name']);
                $bus['Bus']['mob'] = trim($this->data['Bus']['mob']);
                $bus['Bus']['postDate'] = date('Y-m-d H:i:s');
                $bus['Bus']['active'] = intval($this->data['Bus']['active']);
                $bus['Bus']['username'] = trim($this->data['Bus']['username']);
                $bus['Bus']['password_no_encrapt'] = trim($this->data['Bus']['password']);
                $bus['Bus']['password'] = md5(Configure::read('Security.salt1') . md5($this->data['Bus']['password']) . Configure::read('Security.salt2'));

                if ($this->Bus->save(array_merge($this->data['Bus'], $bus['Bus']))) {
                    //set latest update
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

                    $bc['Buscoordinates']['id'] = null;
                    $bc['Buscoordinates']['bus_id'] = $this->Bus->getLastInsertID();
                    App::import('Vendor', 'pos');
                    $bc['Buscoordinates']['lat'] = strbefore($this->Config['map_center'], ',');
                    $bc['Buscoordinates']['lng'] = strafter($this->Config['map_center'], ',');
                    $this->Buscoordinates->save($bc);
                    
                    $this->Email->from = sprintf('%s <%s>', $this->Config['from'], $this->Config['fromaddress']);
                    $this->Email->to = $this->data['Bus']['email'];
                    $this->Email->subject =  __('Bus account', true);
                    $this->Email->template = 'sentemail';
                    $this->Email->sendAs = 'html';
                    //get email msg
                    $msg = $this->Emailmsg->getMsg('ara', 'BUS_ACCOUNT');

                    $messge = $msg['Emailmsg']['content'];

                    $messge = str_replace('$NAME', $bus['Bus']['name'], $messge);
                    $messge = str_replace('$USERNAME', $bus['Bus']['username'], $messge);
                    $messge = str_replace('$PASSWORD', $bus['Bus']['password_no_encrapt'], $messge);

                    $this->set('msg', $messge);
                    $this->Email->send();
                    
                    //checking number
                    $mob = trim($bus['Bus']['mob']);
                    $mob = ltrim($mob, '0');
                    $mob = ltrim($mob, '+966');
                    $mob = ltrim($mob, '966');
                    $mob = $this->Config['mob_prefix'].$mob;

                    if(preg_match(PATTERN_SAUDI_MOBILE, $mob) > 0){
                        //send sms to bus 
                        $this->Sms->sendSMS($this->Config['mobile'], $this->Config['password'], $mob, $this->Config['sender'], $this->Config['bus_username'].' : '.$bus['Bus']['username'] .'\n'. $this->Config['bus_password'].' : '.$bus['Bus']['password_no_encrapt'], $this->Config['timeSend'], $this->Config['dateSend'], '0', $this->Config['applicationType']);
                   }
                    
                    //statistics
                    $this->Statistics->updatevalue('buses');
                    $this->redirect('/admin/bus/index/?result=done');
                }
            }
        }
    }

    function admin_edit($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $cond = "`Bus`.`id` = '$id'";
        $Bus = $this->Bus->getBus($cond);
        if (!is_array($Bus)) {
            $this->redirect('/admin/bus');
            die();
        }
        $this->set('bus', $Bus);

        $cond = "`Areatext`.`local` = '" . LANG . "'";
        $this->set('areas', $this->Areatext->getList($cond));

        #$this->set('goings', $this->Time->getList('GOING'));
        #$this->set('returns', $this->Time->getList('RETURN'));

        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Bus Management', true), '/admin/bus/');

        if (!empty($this->data)) {
            #$this->Bus->set($this->data);

            #if ($this->Bus->validates()) {
                $bb['Bus']['id'] = $id;
                if (!empty($this->data['Bus']['password'])) {
                    $bb['Bus']['password'] = md5(Configure::read('Security.salt1') . md5($this->data['Bus']['password']) . Configure::read('Security.salt2'));
                }

                if ($this->Bus->save($bb['Bus'])) {
                    //set latest update
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

                    $this->redirect('/admin/bus/edit/' . $id . '/?result=done');
                }
            #}
        } else {
            $this->Bus->data = $Bus['Bus'];
        }
    }

    function admin_delete($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $Bus = $this->Bus->find('first', array('conditions' => "`Bus`.`id` = '$id'"));
        if (!is_array($Bus)) {
            $this->redirect('/admin/bus');
            die();
        }

        if ($this->Bus->delete($id)) {
            //set latest update
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            //statistics
            $this->Statistics->updatevalue('buses', 1, false);

            $this->Buscoordinates->deletebus($id);

            $this->redirect('/admin/bus/index');
        }
    }
    
    function admin_addstudents($id){
        $this->Auth->AuthAdmin($this);
        $id = intval($id);
        if (empty($id)) {
            $this->redirect('/admin/bus');
            die();
        }
        
        $cond = "`Student`.`bus_id` = '$id'";
        $fields = array('id', 'name', 'email', 'active');
        $this->set('students_bus', $this->Student->getAll($cond, $fields));
        
        $cond = "`Bus`.`id` = '$id'";
        $bus = $this->Bus->getBus($cond);
        $empty_chairs=$bus['Bus']['chairs'] - $bus['Bus']['booked_chairs'];
        $this->set('empty_chairs', $empty_chairs);
        if($empty_chairs>0){
            $cond = "`Student`.`bus_id` IS NULL AND `Student`.`area_id` = '".$bus['Bus']['area_id']."'";
            $this->set('students', $students= $this->Student->getStudents($cond, $fields, $empty_chairs, 1));
        }else
            $this->set('students',array());
        
        
        if(!empty($this->data)){
            //generate dates
            $start = strtotime(date('Y-m-d'));
            $end = strtotime($this->Config['end-semester']);

            foreach ($students as $data){
                $this->Student->updateBus($data['Student']['id'], $id);                
                $this->Bus->change_count_booked_count($id);
                $cond="`Studenttime`.`student_id`='".$data['Student']['id']."'";
                $fields=array('day','going_id','return_id','going','return');
                $times=$this->Studenttime->getTimes($cond,$fields);
                foreach ($times as $time){
                    $day = strtotime($time['Studenttime']['day'], $start);
                    $ss['Schedule']['id'] = null;
                    $ss['Schedule']['bus_id'] = $id;
                    $ss['Schedule']['student_id'] = $data['Student']['id'];
                    while ($day <= $end) {
                        $ss['Schedule']['day'] = $time['Studenttime']['day'];
                        $ss['Schedule']['date'] = date("Y-m-d", $day);
                        $ss['Schedule']['time_id'] = $time['Studenttime']['going_id'];
                        $ss['Schedule']['time'] = $time['Studenttime']['going'];
                        $ss['Schedule']['type'] = 'GOING';
                        $this->Schedule->save($ss);
                        $ss['Schedule']['time_id'] = $time['Studenttime']['return_id'];
                        $ss['Schedule']['time'] = $time['Studenttime']['return'];
                        $ss['Schedule']['type'] = 'RETURN';
                        $this->Schedule->save($ss);
                        $day = strtotime("+1 weeks", $day);
                    }
                }
            }
            
            $this->redirect('/admin/bus/addstudents?result=done');
        }
        
        $this->Gui->layout('admin');
        $this->Gui->headline(__('Add Students', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Bus Management', true), '/admin/bus/');
        $this->Gui->navigation(__('Add Students', true));
    }
    
    function admin_goingtimes($id){
        $this->Auth->AuthAdmin($this);
        $id = intval($id);
        if (empty($id)) {
            $this->redirect('/admin/bus');
            die();
        }
        $this->set('id', $id);
        $cond ="`Bustime`.`bus_id` = '$id' AND `Bustime`.`type` LIKE 'GOING'";
        $this->set('times', $this->Bustime->getAll($cond));
        
        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Bus Management', true), '/admin/bus/');
    }
    
    function admin_addgoingtime($id){
        $this->Auth->AuthAdmin($this);
        $id = intval($id);
        if (empty($id)) {
            $this->redirect('/admin/bus');
            die();
        }
        $this->set('id', $id);
        $this->set('goings', $this->Time->getList('GOING'));
        
        if(!empty($this->data)){
            $tt['Bustime']['id']=null;
            $tt['Bustime']['bus_id']=$id;
            $tt['Bustime']['time_id']=  intval($this->data['Time']['time_id']);
            $tt['Bustime']['time']=  $this->Time->getValueBykey($this->data['Time']['time_id'], 'time');
            $tt['Bustime']['type']='GOING';
            
            if($this->Bustime->save($tt)){
                $this->redirect('/admin/bus/goingtimes/'.$id.'?result=done');
            }
        }
        
        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Bus Management', true), '/admin/bus/');
    }
    
    public function admin_editgoingtime($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        if (($id)<=0) {
            $this->redirect('/admin/bus');
            die();
        }
        $this->set('id', $id);
        $cond="`Bustime`.`id` ='$id'";
        $this->set('time', $this->Bustime->getTime($cond));
        $this->set('goings', $this->Time->getList('GOING'));
        
        if(!empty($this->data)){
            $tt['Bustime']['id']=$id;
            $tt['Bustime']['time_id']=  intval($this->data['Time']['time_id']);
            $tt['Bustime']['time']=  $this->Time->getValueBykey($this->data['Time']['time_id'], 'time');
            
            if($this->Bustime->save($tt)){
                $this->redirect('/admin/bus/goingtimes/'.$id.'?result=done');
            }
        }
        
    }

    function admin_deletegoingtime($id, $bus_id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        if (($id)<=0) {
            $this->redirect('/admin/bus');
            die();
        }

        if ($this->Bustime->delete($id)) {
            $this->redirect('/admin/bus/goingtimes/'.$bus_id);
        }
    }
    
    /**/
    function admin_returntimes($id){
        $this->Auth->AuthAdmin($this);
        $id = intval($id);
        if (empty($id)) {
            $this->redirect('/admin/bus');
            die();
        }
        $this->set('id', $id);
        $cond ="`Bustime`.`bus_id` = '$id' AND `Bustime`.`type` LIKE 'RETURN'";
        $this->set('times', $this->Bustime->getAll($cond));
        
        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Bus Management', true), '/admin/bus/');
    }
    
    function admin_addreturntime($id){
        $this->Auth->AuthAdmin($this);
        $id = intval($id);
        if (empty($id)) {
            $this->redirect('/admin/bus');
            die();
        }
        $this->set('id', $id);
        $this->set('returns', $this->Time->getList('RETURN'));
        
        if(!empty($this->data)){
            $tt['Bustime']['id']=null;
            $tt['Bustime']['bus_id']=$id;
            $tt['Bustime']['time_id']=  intval($this->data['Time']['time_id']);
            $tt['Bustime']['time']=  $this->Time->getValueBykey($this->data['Time']['time_id'], 'time');
            $tt['Bustime']['type']='RETURN';
            
            if($this->Bustime->save($tt)){
                $this->redirect('/admin/bus/returntimes/'.$id.'?result=done');
            }
        }
        
        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Bus Management', true), '/admin/bus/');
    }
    
    public function admin_editreturntime($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        if (($id)<=0) {
            $this->redirect('/admin/bus');
            die();
        }
        $this->set('id', $id);
        $cond="`Bustime`.`id` ='$id'";
        $this->set('time', $this->Bustime->getTime($cond));
        $this->set('returns', $this->Time->getList('RETURN'));
        
        if(!empty($this->data)){
            $tt['Bustime']['id']=$id;
            $tt['Bustime']['time_id']=  intval($this->data['Time']['time_id']);
            $tt['Bustime']['time']=  $this->Time->getValueBykey($this->data['Time']['time_id'], 'time');
            
            if($this->Bustime->save($tt)){
                $this->redirect('/admin/bus/returntimes/'.$id.'?result=done');
            }
        }
        
    }

    function admin_deletereturntime($id, $bus_id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        if (($id)<=0) {
            $this->redirect('/admin/bus');
            die();
        }

        if ($this->Bustime->delete($id)) {
            $this->redirect('/admin/bus/returntimes/'. $bus_id);
        }
    }
    
    function admin_active($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }
        $cond = "`Bus`.`id` = '$id'";
        $data = $this->Bus->getBus($cond);
        $data['Bus']['id'] = $data['Bus']['id'];
        $data['Bus']['active'] = $data['Bus']['active'] * -1;
        if ($this->Bus->save($data, false, array('active'))) {
            $this->redirect('/admin/bus/index/');
        }
    }
    
    function admin_delivery(){
        $this->Auth->AuthAdmin($this);
        
        $this->set('buses', $this->Bus->getAll());
        
        $condArray = array();
        
        $condArray[] = "(`Schedule`.`done` = '1' OR `Schedule`.`late` = '1')";
        $condArray[] = "`Schedule`.`finished` = '1'";
        
        if(!empty($_GET['bus_id'])){
            $condArray[] = "`Schedule`.`bus_id` = '".  intval($_GET['bus_id'], $base)."'";
        }
        if(!empty($_GET['from'])){
            $condArray[] = "`Schedule`.`date` >= '".$_GET['from']."'";
        }
        if(!empty($_GET['to'])){
            $condArray[] = "`Schedule`.`date` <= '".$_GET['to']."'";
        }
                
        $cond= implode(' AND ', $condArray);
        $this->set('full_delivery_count', $this->Schedule->getCount($cond));
        
        $fields=array('student_id', 'bus_id', 'date', 'time', 'done', 'late', 'type', 'triptype', 'risetime');
        $this->set('full_delivery', $this->Schedule->getAll($cond, $fields));
    }

    function admin_areasused(){
         $this->Auth->AuthAdmin($this);
         
         $fields=array('COUNT(area_id) as area_count' , 'area_id');
        $order="area_count DESC";
        $this->set('areas', $this->Bus->getBusesGroupByArea(null, $fields, $order));
      
    }
    
    /* web services */

    function ws_login() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $username = (@$_POST['username']);
        $password = (@$_POST['password']);
        $reg_id = (@$_POST['reg_id']);
        if (empty($username) || empty($password) || empty($reg_id)) {
            $this->set('message', 'USERNAME_PASSWORD_REGID_ARE_REQUIRED');
            return;
        }

        $SomeOne = $this->Bus->find('first', array('conditions' => "`Bus`.`username` = '$username' AND `Bus`.`active` = '1'",));
        if (empty($SomeOne)) {
            $this->set('message', 'NO_ACCOUNT');
            return;
        } else {
            $Password = md5(Configure::read('Security.salt1') . md5($password) . Configure::read('Security.salt2'));

            if ($Password != $SomeOne['Bus']['password']) {
                $this->set('message', 'WRONG_PASSWORD');
                return;
            } else {
                $this->Bus->setRegId($SomeOne['Bus']['id'], $reg_id);
                $this->set('result', $SomeOne);
                return;
            }
        }
    }

    function find_closest_time($array, $time) {
        //$count = 0;
        foreach ($array as $value) {
            //$interval[$count] = abs(strtotime($date) - strtotime($day));
            $interval[] = abs(strtotime($time) - strtotime($value));
            //$count++;
        }
        asort($interval);
        $closest = key($interval);
        return $array[$closest];
    }
    
    function ws_rest_students_in_trip(){
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        
        $id = intval($_POST['bus_id']);
        if (($id) <=0) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        
        //checking trip type
        $cond = "`Bustime`.`bus_id` = '$id'";
        $fields = array('time_id', 'time');
        $bustimes = $this->Bustime->getAll($cond, $fields);
        $times=array();
        foreach ($bustimes as $data){
            $times[]=$data['Bustime']['time'];
        }
        $closest_time = $this->find_closest_time($times, date('H:i:s'));
        
        $current_date = date('Y-m-d');
        
        $condArray[]= "`Schedule`.`bus_id` = '$id'";
        $condArray[]= "`Schedule`.`date` = '$current_date'"; 
        $before_hour = date('H:i:s', strtotime('-1 hour', strtotime($closest_time)));
        $after_hour = date('H:i:s', strtotime('+1 hour', strtotime($closest_time)));
        $condArray[]= "`Schedule`.`time` >= '$before_hour' AND `Schedule`.`time` <= '$after_hour'";
        $cond =  implode(' AND ', $condArray);        
        $full_count = $this->Schedule->find('count', array('conditions' => $cond));
                  
        $condArray[]= "`Schedule`.`finished` = '1'";
        $cond =  implode(' AND ', $condArray);        
        $finished = $this->Schedule->find('count', array('conditions' => $cond));
        $this->set('result', $full_count-$finished);
    }

    function ws_bus_schedule_list() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');

        $id = $_POST['bus_id'];
        if (empty($id)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        
        $current_date = date('Y-m-d');

        //checking trip type
        $cond = "`Bustime`.`bus_id` = '$id'";
        $fields = array('time_id', 'time');
        $bustimes = $this->Bustime->getAll($cond, $fields);
        $times=array();
        foreach ($bustimes as $data){
            $times[]=$data['Bustime']['time'];
        }
        $closest_time = $this->find_closest_time($times, date('H:i:s'));
        
        $condArray = array();
        
        if(!empty($_POST['type']))
            $condArray[]= "`Schedule`.`type` LIKE '".$_POST['type']."'";
        
        if(!empty($_POST['finished'])){
            $condArray[]= "`Schedule`.`finished` = '".  intval($_POST['finished'])."'";
            if($_POST['finished']==1)
                $condArray[]= "(`Schedule`.`done` = '1' OR `Schedule`.`late` = '1')";
        }else
            $condArray[]= "`Schedule`.`finished` = '-1'";
                
        $condArray[]= "`Schedule`.`bus_id` = '$id'";
        
        $condArray[]= "`Schedule`.`date` = '$current_date'";   
        $before_hour = date('H:i:s', strtotime('-1 hour', strtotime($closest_time)));
        $after_hour = date('H:i:s', strtotime('+1 hour', strtotime($closest_time)));
        $condArray[]= "`Schedule`.`time` >= '$before_hour' AND `Schedule`.`time` <= '$after_hour'";
        
        $cond =  implode(' AND ', $condArray);
        $fields = array('id', 'student_id', 'date', 'time', 'type', 'triptype', 'done', 'late', 'dontcome', 'cancel', 'Student.name', 'finished');
        $order = "`Schedule`.`id` ASC";
        $markers = $this->Schedule->getAll($cond, $fields, $order);
        if (empty($markers)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }
        $cond_c = "`Buscoordinates`.`bus_id` ='$id'";
        $fields = array('lat', 'lng');
        $bus = $this->Buscoordinates->getBus($cond_c, $fields);
        $from = $bus['Buscoordinates']['lat'] . "," . $bus['Buscoordinates']['lng'];
        $points = array();
        foreach ($markers as $value) {
            $to = $value['Student']['lat'] . ',' . $value['Student']['lng'];

            $values = list($first, $second) = $this->calc_meters($from, $to);
            $id = $value['Schedule']['id'];
            $points[$id]['meters'] = "$values[0]";
            $points[$id]['km'] = "$values[1]";
            $points[$id]['Student'] = $to;
            $points[$id]['name'] = $value['Student']['name'];
            $points[$id]['student_id'] = $value['Schedule']['student_id'];
            $points[$id]['lat'] = $value['Student']['lat'];
            $points[$id]['lng'] = $value['Student']['lng'];
            $points[$id]['date'] = $value['Schedule']['date'];
            $points[$id]['time'] = $value['Schedule']['time'];
            $points[$id]['triptype'] = $value['Schedule']['triptype'];
            $points[$id]['type'] = $value['Schedule']['type'];
            $points[$id]['done'] = $value['Schedule']['done'];
            $points[$id]['late'] = $value['Schedule']['late'];
            $points[$id]['finished'] = $value['Schedule']['finished'];
            $points[$id]['dontcome'] = $value['Schedule']['dontcome'];
            $points[$id]['cancel'] = $value['Schedule']['cancel'];
        }
        asort($points);
        $this->set('result', $points);
        $this->set('full_count', $this->Schedule->find('count', array('conditions' => $cond)));
    }
    
    function ws_bus_schedule_list_going() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');

        $id = $_POST['bus_id'];
        if (empty($id)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        
        $current_date = date('Y-m-d');

        //checking trip type
        $cond = "`Bustime`.`bus_id` = '$id'";
        $fields = array('time_id', 'time');
        $bustimes = $this->Bustime->getAll($cond, $fields);
        $times=array();
        foreach ($bustimes as $data){
            $times[]=$data['Bustime']['time'];
        }
        $closest_time = $this->find_closest_time($times, date('H:i:s'));
        
        $condArray = array();
        $condArray[]= "`Schedule`.`finished` = '-1'";
        $condArray[]= "`Schedule`.`type` LIKE 'GOING'";
        $condArray[]= "`Schedule`.`bus_id` = '$id'";
        $condArray[]= "`Schedule`.`date` = '$current_date'";   
        $before_hour = date('H:i:s', strtotime('-1 hour', strtotime($closest_time)));
        $after_hour = date('H:i:s', strtotime('+1 hour', strtotime($closest_time)));
        $condArray[]= "`Schedule`.`time` >= '$before_hour' AND `Schedule`.`time` <= '$after_hour'";
        
        $cond =  implode(' AND ', $condArray);
        $fields = array('id', 'student_id', 'date', 'time', 'type', 'triptype', 'done', 'late', 'dontcome', 'cancel', 'Student.name', 'finished');
        $order = "`Schedule`.`id` ASC";
        $markers = $this->Schedule->getAll($cond, $fields, $order);
        if (empty($markers)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }
        $cond_c = "`Buscoordinates`.`bus_id` ='$id'";
        $fields = array('lat', 'lng');
        $bus = $this->Buscoordinates->getBus($cond_c, $fields);
        $from = $bus['Buscoordinates']['lat'] . "," . $bus['Buscoordinates']['lng'];
        $points = array();
        foreach ($markers as $value) {
            $to = $value['Student']['lat'] . ',' . $value['Student']['lng'];

            $values = list($first, $second) = $this->calc_meters($from, $to);
            $id = $value['Schedule']['id'];
            $points[$id]['meters'] = "$values[0]";
            $points[$id]['km'] = "$values[1]";
            $points[$id]['Student'] = $to;
            $points[$id]['name'] = $value['Student']['name'];
            $points[$id]['student_id'] = $value['Schedule']['student_id'];
            $points[$id]['lat'] = $value['Student']['lat'];
            $points[$id]['lng'] = $value['Student']['lng'];
            $points[$id]['date'] = $value['Schedule']['date'];
            $points[$id]['time'] = $value['Schedule']['time'];
            $points[$id]['triptype'] = $value['Schedule']['triptype'];
            $points[$id]['type'] = $value['Schedule']['type'];
            $points[$id]['done'] = $value['Schedule']['done'];
            $points[$id]['late'] = $value['Schedule']['late'];
            $points[$id]['finished'] = $value['Schedule']['finished'];
            $points[$id]['dontcome'] = $value['Schedule']['dontcome'];
            $points[$id]['cancel'] = $value['Schedule']['cancel'];
        }
        asort($points);
        $this->set('result', $points);
        $this->set('full_count', $this->Schedule->find('count', array('conditions' => $cond)));
    }
    
    function ws_bus_schedule_list_return() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');

        $id = $_POST['bus_id'];
        if (empty($id)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        
        $current_date = date('Y-m-d');

        //checking trip type
        $cond = "`Bustime`.`bus_id` = '$id'";
        $fields = array('time_id', 'time');
        $bustimes = $this->Bustime->getAll($cond, $fields);
        $times=array();
        foreach ($bustimes as $data){
            $times[]=$data['Bustime']['time'];
        }
        $closest_time = $this->find_closest_time($times, date('H:i:s'));
        
        $condArray = array();
        $condArray[]= "`Schedule`.`finished` = '-1'";
        $condArray[]= "`Schedule`.`type` LIKE 'RETURN'";
        $condArray[]= "`Schedule`.`bus_id` = '$id'";
        $condArray[]= "`Schedule`.`date` = '$current_date'";   
        $before_hour = date('H:i:s', strtotime('-1 hour', strtotime($closest_time)));
        $after_hour = date('H:i:s', strtotime('+1 hour', strtotime($closest_time)));
        $condArray[]= "`Schedule`.`time` >= '$before_hour' AND `Schedule`.`time` <= '$after_hour'";
        
        $cond =  implode(' AND ', $condArray);
        $fields = array('id', 'student_id', 'date', 'time', 'type', 'triptype', 'done', 'late', 'dontcome', 'cancel', 'Student.name', 'finished');
        $order = "`Schedule`.`id` ASC";
        $markers = $this->Schedule->getAll($cond, $fields, $order);
        if (empty($markers)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }
        $cond_c = "`Buscoordinates`.`bus_id` ='$id'";
        $fields = array('lat', 'lng');
        $bus = $this->Buscoordinates->getBus($cond_c, $fields);
        $from = $bus['Buscoordinates']['lat'] . "," . $bus['Buscoordinates']['lng'];
        $points = array();
        foreach ($markers as $value) {
            $to = $value['Student']['lat'] . ',' . $value['Student']['lng'];

            $values = list($first, $second) = $this->calc_meters($from, $to);
            $id = $value['Schedule']['id'];
            $points[$id]['meters'] = "$values[0]";
            $points[$id]['km'] = "$values[1]";
            $points[$id]['Student'] = $to;
            $points[$id]['name'] = $value['Student']['name'];
            $points[$id]['student_id'] = $value['Schedule']['student_id'];
            $points[$id]['lat'] = $value['Student']['lat'];
            $points[$id]['lng'] = $value['Student']['lng'];
            $points[$id]['date'] = $value['Schedule']['date'];
            $points[$id]['time'] = $value['Schedule']['time'];
            $points[$id]['triptype'] = $value['Schedule']['triptype'];
            $points[$id]['type'] = $value['Schedule']['type'];
            $points[$id]['done'] = $value['Schedule']['done'];
            $points[$id]['late'] = $value['Schedule']['late'];
            $points[$id]['finished'] = $value['Schedule']['finished'];
            $points[$id]['dontcome'] = $value['Schedule']['dontcome'];
            $points[$id]['cancel'] = $value['Schedule']['cancel'];
        }
        asort($points);
        $this->set('result', $points);
        $this->set('full_count', $this->Schedule->find('count', array('conditions' => $cond)));
    }
    
    function ws_bus_schedule_list_finished() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');

        $id = $_POST['bus_id'];
        if (empty($id)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        
        $current_date = date('Y-m-d');

        //checking trip type
        $cond = "`Bustime`.`bus_id` = '$id'";
        $fields = array('time_id', 'time');
        $bustimes = $this->Bustime->getAll($cond, $fields);
        $times=array();
        foreach ($bustimes as $data){
            $times[]=$data['Bustime']['time'];
        }
        $closest_time = $this->find_closest_time($times, date('H:i:s'));
        
        $condArray = array();
        $condArray[]= "`Schedule`.`finished` = '1'";
        $condArray[]= "`Schedule`.`bus_id` = '$id'";
        $condArray[]= "`Schedule`.`date` = '$current_date'";   
        $before_hour = date('H:i:s', strtotime('-1 hour', strtotime($closest_time)));
        $after_hour = date('H:i:s', strtotime('+1 hour', strtotime($closest_time)));
        $condArray[]= "`Schedule`.`time` >= '$before_hour' AND `Schedule`.`time` <= '$after_hour'";
        
        $cond =  implode(' AND ', $condArray);
        $fields = array('id', 'student_id', 'date', 'time', 'type', 'triptype', 'done', 'late', 'dontcome', 'cancel', 'Student.name', 'finished');
        $order = "`Schedule`.`id` ASC";
        $markers = $this->Schedule->getAll($cond, $fields, $order);
        if (empty($markers)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }
        $cond_c = "`Buscoordinates`.`bus_id` ='$id'";
        $fields = array('lat', 'lng');
        $bus = $this->Buscoordinates->getBus($cond_c, $fields);
        $from = $bus['Buscoordinates']['lat'] . "," . $bus['Buscoordinates']['lng'];
        $points = array();
        foreach ($markers as $value) {
            $to = $value['Student']['lat'] . ',' . $value['Student']['lng'];

            $values = list($first, $second) = $this->calc_meters($from, $to);
            $id = $value['Schedule']['id'];
            $points[$id]['meters'] = "$values[0]";
            $points[$id]['km'] = "$values[1]";
            $points[$id]['Student'] = $to;
            $points[$id]['name'] = $value['Student']['name'];
            $points[$id]['student_id'] = $value['Schedule']['student_id'];
            $points[$id]['lat'] = $value['Student']['lat'];
            $points[$id]['lng'] = $value['Student']['lng'];
            $points[$id]['date'] = $value['Schedule']['date'];
            $points[$id]['time'] = $value['Schedule']['time'];
            $points[$id]['triptype'] = $value['Schedule']['triptype'];
            $points[$id]['type'] = $value['Schedule']['type'];
            $points[$id]['done'] = $value['Schedule']['done'];
            $points[$id]['late'] = $value['Schedule']['late'];
            $points[$id]['finished'] = $value['Schedule']['finished'];
            $points[$id]['dontcome'] = $value['Schedule']['dontcome'];
            $points[$id]['cancel'] = $value['Schedule']['cancel'];
        }
        asort($points);
        $this->set('result', $points);
        $this->set('full_count', $this->Schedule->find('count', array('conditions' => $cond)));
    }

    function ws_bus_schedule_map() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');

        $id = $_POST['bus_id'];
        if (empty($id)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $current_date = date('Y-m-d');
        
        //checking trip type
        $cond = "`Bustime`.`bus_id` = '$id'";
        $fields = array('time_id', 'time');
        $bustimes = $this->Bustime->getAll($cond, $fields);
        $times=array();
        foreach ($bustimes as $data){
            $times[]=$data['Bustime']['time'];
        }
        $closest_time = $this->find_closest_time($times, date('H:i:s'));
        
        $condArray = array();
        
        if(!empty($_POST['type']))
            $condArray[]= "`Schedule`.`type` LIKE '".$_POST['type']."'";
        
        if(!empty($_POST['finished']))
            $condArray[]= "`Schedule`.`finished` = '".  intval($_POST['finished'])."'";
        else
            $condArray[]= "`Schedule`.`finished` = '-1'";
                
        $condArray[]= "`Schedule`.`bus_id` = '$id'";
        $condArray[]= "`Schedule`.`date` = '$current_date'";   
        $before_hour = date('H:i:s', strtotime('-1 hour', strtotime($closest_time)));
        $after_hour = date('H:i:s', strtotime('+1 hour', strtotime($closest_time)));
        $condArray[]= "`Schedule`.`time` >= '$before_hour' AND `Schedule`.`time` <= '$after_hour'";
        
        $cond =  implode(' AND ', $condArray);
        $fields = array('id', 'student_id', 'date', 'time', 'type', 'triptype', 'done', 'late', 'dontcome', 'cancel', 'Student.lat', 'Student.lng', 'finished');
        $order = "`Schedule`.`id` ASC";
        $markers = $this->Schedule->getAll($cond, $fields, $order); //print_r($markers);
        if (empty($markers)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }
        $cond_c = "`Buscoordinates`.`bus_id` ='$id'";
        $fields = array('lat', 'lng');
        $bus = $this->Buscoordinates->getBus($cond_c, $fields);
        $from = $bus['Buscoordinates']['lat'] . "," . $bus['Buscoordinates']['lng'];
        $points = array();
        foreach ($markers as $value) {
            $to = $value['Student']['lat'] . ',' . $value['Student']['lng'];

            $values = list($first, $second) = $this->calc_meters($from, $to);
            $id = $value['Schedule']['id'];
            $points[$id]['meters'] = "$values[0]";
            $points[$id]['km'] = "$values[1]";
            $points[$id]['Student'] = $to;
            $points[$id]['name'] = $value['Student']['name'];
            $points[$id]['student_id'] = $value['Schedule']['student_id'];
            $points[$id]['lat'] = $value['Student']['lat'];
            $points[$id]['lng'] = $value['Student']['lng'];
            $points[$id]['date'] = $value['Schedule']['date'];
            $points[$id]['time'] = $value['Schedule']['time'];
            $points[$id]['triptype'] = $value['Schedule']['triptype'];
            $points[$id]['type'] = $value['Schedule']['type'];
            $points[$id]['done'] = $value['Schedule']['done'];
            $points[$id]['late'] = $value['Schedule']['late'];
            $points[$id]['finished'] = $value['Schedule']['finished'];
            $points[$id]['dontcome'] = $value['Schedule']['dontcome'];
            $points[$id]['cancel'] = $value['Schedule']['cancel'];
        }
        asort($points);
        $this->set('result', $points);
        $this->set('full_count', $this->Schedule->find('count', array('conditions' => $cond)));
    }

    function calc_meters($from, $to) {

        $from = urlencode($from);
        $to = urlencode($to);
        $data = file_get_contents("http://maps.googleapis.com/maps/api/distancematrix/json?origins=$from&destinations=$to&mode=driving&language=en-EN");
        $data = json_decode($data);

        $distance = 0;
        $km = 0;

        foreach ($data->rows[0]->elements as $road) {
            $distance += $road->distance->value;
            $km += $road->distance->text;
        }
        //return list of both meters and KM
        return array($distance, $km);
    }

    function ws_update_bus_coordinates() {
        $this->Gui->layout('webservice');
        $id = intval($_POST['bus_id']);
        $lat = ($_POST['lat']);
        $lng = ($_POST['lng']);
        if ($id <= 0 || empty($lat) || empty($lng)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }

        $this->Buscoordinates->update_coordinates($id, $lat, $lng);
        $this->set('message', 'UPDATED');
        return;
    }

    function ws_send_problem() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $id = intval(@$_POST['bus_id']);
        $lat = (@$_POST['lat']);
        $lng = (@$_POST['lng']);
        $problem_type = (@$_POST['problem_type']);
        if ($id <= 0 || empty($lat) || empty($lng) || empty($problem_type)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $pp['Problem']['id'] = null;
        $pp['Problem']['bus_id'] = $id;
        $pp['Problem']['type'] = $problem_type;
        $pp['Problem']['lat'] = $lat;
        $pp['Problem']['lng'] = $lng;
        $pp['Problem']['postDate'] = date('Y-m-d H:i:s');
        if ($this->Problem->save($pp)) {
            $this->set('message', 'PRPOBLEM_SENT');
            return;
        }
    }

    function ws_rate_bus() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $bus_id = intval($_POST['bus_id']);
        $student_id = intval($_POST['student_id']);
        $rate_value = intval($_POST['rate_value']);
        if ($bus_id <= 0 || $rate_value <= 0 || $student_id <= 0) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        //check if bus exist
        $cond="`Bus`.`id` ='$bus_id'";
        $bus=$this->Bus->getCount($cond);
        if(empty($bus)){
            $this->set('message', 'BUS_NOT_FOUND');
            return;
        }
        //check if student exist
        $cond="`Student`.`id` ='$student_id'";
        $student=$this->Student->getCount($cond);
        if(empty($student)){
            $this->set('message', 'STUDENT_NOT_FOUND');
            return;
        }
        if($rate_value<=0||$rate_value>$this->Config['bus-rate']){
            $this->set('message', 'RATE_VALUE_MUST_BE_BETWEEN_1_AND_'.$this->Config['bus-rate']);
            return;
        }
        $rate_before = $this->Busrate->check($student_id, $bus_id);
        if ($rate_before) {
            $this->Busrate->updaterate($student_id, $bus_id, $rate_value);
            $this->set('message', 'RATE_DONE');
            return;
        } else {
            $rate['Busrate']['id'] = null;
            $rate['Busrate']['bus_id'] = $bus_id;
            $rate['Busrate']['student_id'] = $student_id;
            $rate['Busrate']['rate'] = $rate_value;
            if ($this->Busrate->save($rate)) {
                $this->Bus->updatefullrate($bus_id);
                $this->set('message', 'RATE_DONE');
                return;
            }
        }
    }
    
    function ws_current_rate_bus() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $bus_id = intval($_POST['bus_id']);
        $student_id = intval($_POST['student_id']);
        if ($bus_id <= 0 || $student_id <= 0) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        //check if bus exist
        $cond="`Bus`.`id` ='$bus_id'";
        $bus=$this->Bus->getCount($cond);
        if(empty($bus)){
            $this->set('message', 'BUS_NOT_FOUND');
            return;
        }
        //check if student exist
        $cond="`Student`.`id` ='$student_id'";
        $student=$this->Student->getCount($cond);
        if(empty($student)){
            $this->set('message', 'STUDENT_NOT_FOUND');
            return;
        }
        
        $cond="`Busrate`.`bus_id` = '$bus_id' AND `Busrate`.`student_id` = '$student_id'";
        $fields=array('rate');
        $result = $this->Busrate->getRate($cond, $fields);
        $rate = intval($result['Busrate']['rate']);
        if( $rate== 0)
            $rate = 1;
        $this->set('result', $rate);
    }
    
    function ws_goingtimes(){
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $bus_id = intval(@$_POST['bus_id']);
        if ($bus_id <= 0) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $cond ="`Bustime`.`bus_id` = '$bus_id' AND `Bustime`.`type` LIKE 'GOING'";
        $this->set('result', $this->Bustime->getAll($cond));
    }
    
    function ws_returntimes(){
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $bus_id = intval(@$_POST['bus_id']);
        if ($bus_id <= 0) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $cond ="`Bustime`.`bus_id` = '$bus_id' AND `Bustime`.`type` LIKE 'RETURN'";
        $this->set('result', $this->Bustime->getAll($cond));
    }
    
    function beforeRender() {
        $this->Gui->DoGUIvar($this);
    }

}
