<?php
class AdminController extends AppController  {
	var $name = 'Admin';
	var $uses = array('Admin', 'Emailmsg');
	var $components = array('Conf', 'Gui', 'Auth', 'Banners', 'Acl', 'Banners', 'Email');
	var $helpers = array('Layout');
	var $Config;

	function admin_profile(){
		$this->Auth->AuthAdmin ($this, 'profile', 'update');
		$Admin = $this->Auth->Admin;

		// GUI
		$this->Gui->headline (__('Change password', true));
		$this->Gui->pagetitle (__('Change password', true));
		$this->Gui->navigation (__('admincp_index', true), '/');
		$this->Gui->navigation (__('Change password', true));
        
		if(isset($this->data['Admin'])){
			$errormessage = array();

			// Check Old Password
			$OldMd5Password = md5(Configure::read('Security.salt1') . md5($this->data['Admin']['oldPassword']) . Configure::read('Security.salt2'));
			if ($OldMd5Password != $Admin['password']){
				$this->Admin->invalidate ('oldPassword');
				$errormessage[] = __('Error in current password', true);
			}

			if (empty($this->data['Admin']['newPassword'])) {
				$this->Admin->invalidate ('newPassword');
				$errormessage[] = __('New passwords not matches', true);
			}

			// Check NEW password Same with Confirm
			if ($this->data['Admin']['newPassword'] != $this->data['Admin']['confirmPassword']) {
				$this->Admin->invalidate ('confirmPassword');
				$errormessage[] = __('New passwords not matches', true);
			}

			if(sizeof($errormessage) > 0){
				$this->set('errormessage', $errormessage);
				$this->render();
			}else{
				$NewMd5Password = md5(Configure::read('Security.salt1') . md5($this->data['Admin']['newPassword']) . Configure::read('Security.salt2'));

				$Admin['password'] = $NewMd5Password;
				if ($this->Admin->save($Admin, FALSE, array ('password'))) {
					$this->Session->delete ('Admin');
					@session_destroy();
					$this->redirect ('/'.$this->Config['admin-panel-url']);
				}
			}
		}
	}
    
    function resetpasswordadmin() {
        $email = $this->params['email'];
        $randActivation = $this->params['code'];
        // GUI
        $this->Gui->layout('login');
        $this->Gui->headline(__('Reset Admin Password', true));
        $this->Gui->pagetitle(__('Reset Admin Password', true));
        $this->Gui->navigation(__('homepage', true), '/');
        $this->Gui->navigation(__('Reset Admin Password', true));
        if ($randActivation == NULL || $email == NULL) {
            $this->redirect('/'.$this->Config['admin-panel-url']);
            die();
        }
        $CheckRandActivation = $this->Admin->find('first', array('conditions' => "`Admin`.`activeEmailKey` = '$randActivation'",
            'fields' => array('adminID', 'password', 'email', 'activeEmailKey'),
        ));
        if ($CheckRandActivation['Admin']['activeEmailKey'] != $randActivation || $CheckRandActivation['Admin']['email'] != $email) {
            $this->redirect('/'.$this->Config['admin-panel-url']);
            die();
        }
        if ($CheckRandActivation['Admin']['activeEmailKey'] == $randActivation and $CheckRandActivation['Admin']['email'] == $email) {
            if (!empty($this->data)) {
                $errormessage = array();
                // Check NEW password Same with Confirm
                if ($this->data['Admin']['newPassword'] != $this->data['Admin']['confirmPassword']) {
                    $this->Admin->invalidate('confirmPassword');
                    $errormessage[] = __('No match in passwords fields', true);
                }
                if (empty($this->data['Admin']['newPassword'])) {
                    $this->Admin->invalidate('newPassword');
                    $errormessage[] = __('No match in passwords fields', true);
                }
                if (sizeof($errormessage) > 0) {
                    $this->set('errormessage', $errormessage);
                    $this->render();
                } else {
                    $NewMd5Password = md5(Configure::read('Security.salt1') . md5($this->data['Admin']['newPassword']) . Configure::read('Security.salt2'));
                    $CheckRandActivation['Admin']['adminID'] = $CheckRandActivation['Admin']['adminID'];
                    $CheckRandActivation['Admin']['password'] = $NewMd5Password;
                    $CheckRandActivation['Admin']['activeEmailKey'] = NULL;
                    if ($this->Admin->save($CheckRandActivation, FALSE, array('password', 'activeEmailKey'))) {
                        $this->redirect('/'.$this->Config['admin-panel-url'].'?resetpassworddone');
                    }
                }
            }
        }
    }

    
    /* ajax function */
    function forgotpasswordadmin() {
        $this->Gui->layout('blank');        
        $email = trim($_POST['email']);        
        if (!empty($email)) {
            if (preg_match(PATTERN_EMAIL, $email) > 0){
                $admin = $this->Admin->find('first', array('conditions' => "`Admin`.`email` = '$email'"));
                if (empty($admin)) {
                    $this->set('msgtype', 'error');
                    $this->set('msg',__('You have entered a wrong email', true));
                }else{
                    App::import('Vendor', 'generatekey');
                    $RandActivation = generatekey(32); //get random  Activation
                    $admin['Admin']['activeEmailKey'] = $RandActivation; //new password atfer encryption it, and will save it in DB
                    if ($this->Admin->save($admin, false, array('activeEmailKey'))) {//save new password and real ip
                        $this->Email->from = sprintf('%s <%s>', $this->Config['from'], $this->Config['fromaddress']);
                        $this->Email->to = $admin['Admin']['email'];
                        $this->Email->subject = __('Reset Admin Password', true);
                        $this->Email->template = 'sentemail';
                        $this->Email->sendAs = 'html';
                        //get email msg
                        $msg = $this->Emailmsg->getMsg(LANG, 'FORGOTPASSWORDADMIN');
                        $messge = $msg['Emailmsg']['content'];
                        $messge = str_replace('$WEBSITEURL', $this->Config['url'], $messge);
                        $messge = str_replace('$EMAIL', $admin['Admin']['email'], $messge);
                        $messge = str_replace('$RANDACTIVATION', $admin['Admin']['activeEmailKey'], $messge);
                        $this->set('msg', $messge);
                        if ($this->Email->send()) {
                            $this->Admin->save($admin, false, array('activeEmailKey'));
                            $this->set('msgtype', 'ok');
                            $this->set('msg',__('We have sent an email please follow the instruction to reset your password', true));
                        }
                    }
                }
            }else{
                $this->set('msgtype', 'error');
                $this->set('msg',__('Email invalid', true));
            }
        }else{
            $this->set('msg', __('Please fill in email', true));
            $this->set('msgtype', 'error');
        }
    }
    /* ajax function */

	function beforeRender(){
		$this->Gui->DoGUIvar($this);
	}
}