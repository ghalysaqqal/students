<?php
class EmailmsgController extends AppController
{
    var $name = 'Emailmsg';
    var $uses = array('Emailmsg', );
    var $components = array('Conf', 'Gui', 'Auth', 'Email', 'Acl');
    var $helpers = array('Layout', 'Pagination', 'Row', 'Url', 'Editor');

    var $Config = array();

    function admin_index()
    {
        $this->Auth->AuthAdmin ($this, 'email_settings', 'read');

        $this->set('msgs', $this->Emailmsg->getMsgs());

        $this->Gui->headline(__('Messaging Settings', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Messaging Settings', true), '/admin/emailmsg/');
    }

    function admin_edit($id)
    {
        $this->Auth->AuthAdmin ($this, 'email_settings', 'update');

        $Emailmsg = $this->Emailmsg->find('first', array('conditions' => "`Emailmsg`.`id` = '$id'"));
        if (!is_array($Emailmsg))
        {
            $this->redirect('/admin/emailmsg/index');
            die();
        }
        $this->set('Emailmsg', $Emailmsg);

        if (!empty($this->data))
        {
            $this->Emailmsg->data['id'] = $id;
            $this->Emailmsg->data['content'] = $this->data['Emailmsg']['content'];

            if ($this->Emailmsg->save($this->Emailmsg->data))
            {
                $this->redirect('/admin/emailmsg/edit/'.$id.'/?result=done');
            }
        }
        else
        {
            $this->Emailmsg->data = $Emailmsg;
        }

        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Messaging Settings', true), '/admin/emailmsg/index');
        $this->Gui->navigation(__('edit', true));
    }
    
    function admin_test($id){
        $this->Auth->AuthAdmin ($this, 'email_settings', 'read');
        
        $Emailmsg = $this->Emailmsg->find('first', array('conditions' => "`Emailmsg`.`id` = '$id'"));
        if (!is_array($Emailmsg))
        {
            $this->redirect('/admin/emailmsg/index');
            die();
        }
        $this->set('Emailmsg', $Emailmsg);
        
        $this->Email->from = sprintf('%s <%s>', $this->Config['from'], $this->Config['fromaddress']);
        $this->Email->to = $this->Config['email_monitor'];
        $this->Email->subject = 'Subject Test';
        $this->Email->template = 'sentemail';
        $this->Email->sendAs = 'html';
        $this->set('msg', $Emailmsg['Emailmsg']['content']);
        
        
        
        if ($this->Email->send())
        {
            $this->redirect('/admin/emailmsg?result=sentdone');
        }
    }

    function beforeRender(){
        $this->Gui->DoGUIvar($this);
    }
}