<?php

App::uses('AppController', 'Controller');

class RssController extends AppController {

    var $name = 'Rss';
    var $uses = array('Itemtext', 'Nodetext');
    var $components = array('Conf');
    var $helpers = array('Layout', 'Url', 'Row', 'Text');
    var $Config = array();
    var $layout = 'rss';

    function index() {

        //items
        $cond = "`Itemtext`.`local` = '" . LANG . "' AND `Item`.`active` = '1'";
        $fields = array('Itemtext.name', 'Itemtext.desc', 'Item.thumb', 'Item.id', 'Item.postDate');
        $this->set('items', $this->Itemtext->getItems($cond, $fields, 1, 200));

        //nodes
        $cond = "`Nodetext`.`local` = '" . LANG . "' AND `Node`.`active` = '1'";
        $fields = array('title', 'desc', 'Node.thumb', 'Node.id', 'Node.postdate', 'slug');
        $this->set('nodes', $this->Nodetext->getNodes($cond, $fields, 1, 200));

        $Channel['channelName'] = $this->Config['name_' . LANG];
        $Channel['channelLink'] = $this->Config['url'];
        $Channel['channelDesc'] = $this->Config['name_' . LANG];
        $Channel['channelDate'] = date('r');
        $this->set('Channel', $Channel);
    }

}
