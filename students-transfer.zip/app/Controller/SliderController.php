<?php
class SliderController extends AppController
{
    var $name = 'Slider';
    var $uses = array('Slider', 'Slidertext', 'Lang');
    var $components = array('Conf', 'Gui', 'Auth', 'Banners', 'Jqimgcrop', 'Upload', 'Resize', 'Acl');
    var $helpers = array('Layout', 'Pagination', 'Row', 'Editor', 'Url', 'Cropimage');

    var $Config = array();

    function admin_index()
    {
        $this->Auth->AuthAdmin ($this, 'slider', 'read');

        $this->Gui->layout('admin');
        $this->Gui->headline(__('browse', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_slider', true), '/admin/slider/');
        $this->Gui->navigation(__('browse', true));
        
        $this->set('slidertexts', $this->Slider->getAll()); 
        $this->set('Langs', $this->Lang->getLangs());  
    }

    function admin_add()
    {
        $this->Auth->AuthAdmin ($this, 'slider', 'create');

        $this->Gui->layout('admin');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_slider', true), '/admin/slider/');
        $this->Gui->navigation(__('add', true));
        
        $this->set('Langs', $Langs = $this->Lang->getLangs());

        if (!empty($this->data))
        {
            if ($this->Slider->validates())
            {
                $slider['id'] = null;
                $slider['url'] = $this->data['Slider']['url'];
                
                if ($this->data['Slider']['filename']['error'] == 0 && $this->data['Slider']['filename']['size'] > 0)
                {
                   
                    $path = WWW_ROOT . 'upload' . DS . 'slider' . DS ;
                    $path_thum = $path . 'thum' . DS;
                    
                    $NewFileName = $this->Upload->newname($this->data['Slider']['filename']['name']);
                    // Main File
                    if ($this->Upload->upload($this->data['Slider']['filename'], $path, 'image', $NewFileName))
                    {
                        $slider['filename'] = $NewFileName;
                        
                        $MainFilePath = $path . $NewFileName;
                        $ThumFilePath = $path_thum . $NewFileName;
                        $this->Resize->resize($MainFilePath, $ThumFilePath, $this->Config['slider_width_crop']);
                    }
                    else
                    {
                        $this->log(print ('Uploading Error in File'));
                    }
                }
               
                
                if ($this->Slider->save($slider))
                {
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            
                    $slider_id = $this->Slider->getLastInsertID();
                    
                    foreach($Langs as $lang){
                        $text['Slidertext']['id'] = NULL;
                        $text['Slidertext']['slider_id'] = $slider_id;
                        $text['Slidertext']['local'] = $lang['Lang']['id'];
                        $text['Slidertext']['title'] = $this->data['Slidertext']['title_'.$lang['Lang']['id']];
                        $text['Slidertext']['desc'] = @$this->data['Slidertext']['desc_'.$lang['Lang']['id']];
                        
                        $this->Slidertext->save($text['Slidertext']);
                    }
                    
                    $this->redirect('/admin/slider/editthumb/'.$slider_id);
                }
            }
            else
                $this->render();
        }
        else
            $this->render();
    }
    
    function admin_editthumb($id, $type = NULL){
        $this->Auth->AuthAdmin ($this, 'slider', 'update');
        
        $this->Gui->layout('editthumb');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_item', true), '/admin/item/');
        $this->Gui->navigation(__('add', true));
        
        $id = intval($id);
        if($id == 0){
            $this->redirect('/admin/index');
            die();
        }
        
        $path = WWW_ROOT . 'upload' . DS . 'slider' . DS;
        $path_thum = $path . 'thum' . DS;
        
        $cond = "`Slider`.`id` = '$id'";
        $this->set('slider', $slider = $this->Slider->getSlider($cond));
        $this->set('thumb', $slider['Slider']['filename']);
        list($width, $height, $type, $attr) = getimagesize($path_thum.$slider['Slider']['filename']);  

        $this->set('width', $width);
        $this->set('height', $height);  
        $this->set('path_thum', $path_thum);    
        
        if(!empty($this->data)){
            $this->Jqimgcrop->cropImage($this->Config['slider_width'], $this->data['x1'], $this->data['y1'], $this->data['x2'], $this->data['y2'], $this->data['w'], $this->data['h'], $this->data['imagePath'], $this->data['imagePath']);
            $this->redirect('/admin/slider/index/?result=done');
        }
    }



    function admin_edit($id)
    {
        $this->Auth->AuthAdmin ($this, 'slider', 'update');

        $id = intval($id);
        $cond = "`Slider`.`id` = '$id'";
        $Slider = $this->Slider->getSlider($cond);
        if (!is_array($Slider))
        {
            $this->redirect('/admin/slider');
            die();
        }
        $this->set('slider', $Slider);
        
        $this->set('slidertext', $slidertext = $this->Slidertext->find('all', array('conditions' => "`Slidertext`.`slider_id` = '".$Slider['Slider']['id']."'"))) ;
        
        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_slider', true), '/admin/slider/');

        if (!empty($this->data))
        {
            $this->Slider->set($this->data);
            if ($this->Slider->validates())
            {
                $this->Slider->data['Slider']['id'] = $id;
                $this->Slider->data['Slider']['url'] = $this->data['Slider']['url'];
                
                if ($this->data['Slider']['filename']['error'] == 0 && $this->data['Slider']['filename']['size'] > 0)
                {
                    // News
                    $path = WWW_ROOT . 'upload' . DS . 'slider' . DS ;
                    $path_thum = $path . 'thum' . DS;
                    
                    $NewFileName = $this->Upload->newname($this->data['Slider']['filename']['name']);
                    // Main File
                    if ($this->Upload->upload($this->data['Slider']['filename'], $path, 'image', $NewFileName))
                    {
                        @unlink($path.$Slider['Slider']['filename']);
                        @unlink($path_thum.$Slider['Slider']['filename']);
                        
                        $this->Slider->data['Slider']['filename'] = $NewFileName;
                        
                        $MainFilePath = $path . $NewFileName;
                        $ThumFilePath = $path_thum . $NewFileName;
                        $this->Resize->resize($MainFilePath, $ThumFilePath, $this->Config['slider_width_crop']);
                    
                        $redirectionUrl = '/admin/slider/editthumb/'.$id.'?result=done';
                    }
                    else
                    {
                        $this->log(print ('Uploading Error in File'));
                    }
                }
                else
                {
                    $this->Slider->data['Slider']['filename'] = $Slider['Slider']['filename'];
                    $redirectionUrl = '/admin/slider/edit/'.$id.'/?result=done';
                }
            

                if ($this->Slider->save($this->Slider->data, false, array('filename', 'ord', 'active', 'url', 'thumb')))
                {
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            
                    foreach($slidertext as $data){
                        $text['Slidertext']['id'] = $data['Slidertext']['id'];
                        $text['Slidertext']['title'] = $this->data['Slidertext']['title_'.$data['Slidertext']['local']];
                        $text['Slidertext']['desc'] = @$this->data['Slidertext']['desc_'.$data['Slidertext']['local']];
                        
                        $this->Slidertext->save($text['Slidertext'], array('title', 'desc'));
                    } 
                    
                    $this->redirect($redirectionUrl);
                }
            }
            
        }
        else{
			$this->Slider->data = $Slider['Slider'];
		}
    }

    function admin_delete($id)
    {
        $this->Auth->AuthAdmin ($this, 'slider', 'delete');

        $id = intval($id);
        $Slider = $this->Slider->find('first', array('conditions' => "`Slider`.`id` = '$id'"));
        if (!is_array($Slider))
        {
            $this->redirect('/admin/slider');
            die();
        }

        if ($this->Slider->delete($id))
        {
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            
            $path = WWW_ROOT . 'upload' . DS . 'slider' . DS; 
            $path_thum = $path . 'thum' . DS ; 
            
            @unlink($path . $Slider['Slider']['filename']);
            @unlink($path_thum . $Slider['Slider']['filename']);
            
            $slidertext = $this->Slidertext->find('all', array('conditions' => "`Slidertext`.`slider_id` = '$id'"));
            
            foreach($slidertext as $data){
                $this->Slidertext->delete($data['Slidertext']['id']);
            }
            
            $this->redirect('/admin/slider/index');
        }
    }
    
    function admin_deleteslider($id)
    {
        $this->Auth->AuthAdmin ($this, 'slider', 'delete');
        $this->Gui->layout('blank');

        $id = intval($id);
        $Slider = $this->Slider->find('first', array('conditions' => "`Slider`.`id` = '$id'"));

        if ($this->Slider->delete($id))
        {
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            
            $path = WWW_ROOT . 'upload' . DS . 'slider' . DS; 
            $path_thum = $path . 'thum' . DS ; 
            
            @unlink($path . $Slider['Slider']['filename']);
            @unlink($path_thum . $Slider['Slider']['filename']);
            
            $slidertext = $this->Slidertext->find('all', array('conditions' => "`Slidertext`.`slider_id` = '$id'"));
            
            foreach($slidertext as $data){
                $this->Slidertext->delete($data['Slidertext']['id']);
            }
        }
    }
    
    function admin_active($id){
        $this->Auth->AuthAdmin ($this, 'slider', 'update');
        
        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }
        $cond = "`Slider`.`id` = '$id'";
        $user = $this->Slider->getSlider($cond);
        $user['Slider']['id']     = $user['Slider']['id'];
        $user['Slider']['active'] = $user['Slider']['active'] * -1;
        if ($this->Slider->save($user, false, array('active'))) {
            $this->redirect('/admin/slider/index/');
        }
    }

    function beforeRender()
    {
        $this->Gui->DoGUIvar($this);
    }
}