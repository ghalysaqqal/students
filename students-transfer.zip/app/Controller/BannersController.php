<?php
class BannersController extends AppController {
	var $name = 'Banners';
	var $uses = array ('Adszone', 'Adsbanner');
	var $components = array ('Conf', 'Gui', 'Banners', 'Auth', 'Upload', 'Acl');
	var $helpers = array ('Layout', 'Row');

	var $Config = array ();
    
    function admin_index(){
        $this->Auth->AuthAdmin ($this, 'banners', 'read');

        $Zones = $this->Adszone->find ('all', array ('order' => '`Adszone`.`zoneName` ASC'));
        $this->set ('Zones', $Zones);

        $this->Gui->headline (__('admincp_zones', true));
        $this->Gui->pagetitle (__('admincp_zones', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
		$this->Gui->navigation(__('admincp_manage_banners', true), '/admin/banners/');
		$this->Gui->navigation(__('admincp_zones', true));
    }


    function admin_add (){
        $this->Auth->AuthAdmin ($this, 'banners', 'create');

        $Zones = $this->Adszone->find ('list', array (
                                                    'conditions' => "`Adszone`.`zoneActive` = '1'",
                                                    'order' => "`Adszone`.`zoneDesc` ASC",
                                                    'fields' => array ('adsZID', 'zoneDesc')
													 ));
        $this->set ('Zones', $Zones);

        if(!empty($this->data)){
              $this->Adsbanner->set($this->data);

              // File Validate
              if ($this->data['Adsbanner']['Filename']['error'] != 0 ){
                    $this->Adsbanner->invalidate('Filename', __('filenotfound', true));
              }

              // Validate Passed
              if (!$this->Adsbanner->invalidFields()){
                // Start Uploadind Banner
                $path = WWW_ROOT . 'upload' . DS . 'banners' . DS;
                
                $NewFileName = $this->Upload->newname($this->Adsbanner->data['Adsbanner']['Filename']['name']);
                
                if ($this->Upload->upload ($this->Adsbanner->data['Adsbanner']['Filename'], $path, $this->data['Adsbanner']['bannerType'], $NewFileName)) {
                  $this->Adsbanner->data['Adsbanner']['bannerFilename'] = $NewFileName;
                }else{
                  die ('Uploading Error, Call Administrator');
                }

                $this->Adsbanner->data['Adsbanner']['adsBID'] = NULL;

                if($this->Adsbanner->save($this->Adsbanner->data)){
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            
                    Cache::delete('Banner');
                    $this->redirect('/admin/banners/add/?result=done');
                }else{
                    Cache::delete('Banner');
                    $this->set ('error', __('savefiald', true));
                }
            }
        }
        
        $this->Gui->headline (__('add', true));
        $this->Gui->pagetitle (__('add', true));        
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');  
        $this->Gui->navigation(__('admincp_manage_banners', true), '/admin/banners/');
        $this->Gui->navigation(__('add', true));
    }


    function admin_edit ($adsBID){
        $this->Auth->AuthAdmin ($this, 'banners', 'update');

        $adsBID = intval($adsBID);
        $adsBID == 0 ? die () : 1==1;

        $Zones = $this->Adszone->find ('list', array (
                                                    'conditions' => "`Adszone`.`zoneActive` = '1'",
                                                    'order' => "`Adszone`.`zoneDesc` ASC",
                                                    'fields' => array ('adsZID', 'zoneDesc')));
        $this->set ('Zones', $Zones);

        $Banner = $this->Adsbanner->find ('first', array('conditions' => "`Adsbanner`.`adsBID` = '$adsBID'"));
        if(!is_array($Banner)){
            $this->redirect('/admin/banners/browse');
            die ();
        }
        $this->set('Banner', $Banner);

        $this->Gui->headline ($Banner['Adsbanner']['bannerName']);
        $this->Gui->pagetitle ($Banner['Adsbanner']['bannerName']);

        if(!empty($this->data)){
              $this->Adsbanner->data['Adsbanner']['adsBID'] = $adsBID;
              $this->Adsbanner->set($this->data);

              // Validate Passed
              if (!$this->Adsbanner->invalidFields()){
                // Replace File
                if($this->data['Adsbanner']['Filename']['error'] == 0){
                    
                    $path = WWW_ROOT . 'upload' . DS . 'banners' . DS;
                    //remove old file
                    @unlink($path . $Banner['Adsbanner']['bannerFilename']);
                    // Start Uploadind Banner
                    $NewFileName = $this->Upload->newname($this->data['Adsbanner']['Filename']['name']);
                    if ($this->Upload->upload ($this->data['Adsbanner']['Filename'], $path, $this->data['Adsbanner']['bannerType'], $NewFileName)) {
                      $this->Adsbanner->data['Adsbanner']['bannerFilename'] = $NewFileName;
                    }else{
                      die ('Uploading Error, Call Administrator');
                    }
                }

                if($this->Adsbanner->save($this->Adsbanner->data)){
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
                    Cache::delete('Banner');
                    $this->redirect('/admin/banners/edit/'.$adsBID.'?result=done');
                }else{
                    Cache::delete('Banner');
                    $this->set ('error', __('savefiald', true));
                }
              }
        }else{
            $this->Adsbanner->data = $Banner['Adsbanner'];
        }
        
        $this->Gui->headline (__('Edit Banner', true));
        $this->Gui->pagetitle (__('Edit Banner', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
		$this->Gui->navigation(__('admincp_manage_banners', true), '/admin/banners/');
		$this->Gui->navigation(__('Edit Banner', true));
    }

    function admin_delete($adsBID){
        $this->Auth->AuthAdmin ($this, 'banners', 'delete');

        $adsBID = intval($adsBID);
        $adsBID == 0 ? die () : 1==1;

        $Banner = $this->Adsbanner->find ('first', array('conditions' => "`Adsbanner`.`adsBID` = '$adsBID'"));
        if(!is_array($Banner)){
            $this->redirect('/admin/banners/browse');
            die ();
        }

        $filename = APP . WEBROOT_DIR . DS . 'upload' . DS . $Banner['Adsbanner']['bannerFilename'];
        if(file_exists($filename)){
            unlink($filename);
        }

        if ($this->Adsbanner->delete($adsBID)){
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            
            Cache::delete('Banner');
            $this->redirect ('/admin/banners/');
        }
    }
    
    function admin_browsezone($adsZID){
        $this->Auth->AuthAdmin ($this, 'banners', 'read');

        $adsZID = intval($adsZID);
        $adsZID == 0 ? die () : 1==1;

        $Zone = $this->Adszone->find ('first', array ('conditions' => "`Adszone`.`adsZID` = '$adsZID'"));
        if(!is_array($Zone)){
            $this->redirect('/admin/banners/browse');
            die ();
        }
        $this->set ('Zone', $Zone);

        $Banners = $this->Adsbanner->find ('all', array('conditions' => "`Adsbanner`.`adsZID` = '$adsZID'", 'order' => "`Adsbanner`.`bannerActive` DESC, `Adsbanner`.`weight` ASC"));
        $this->set ('Banners', $Banners);

        $this->Gui->headline ($Zone['Adszone']['zoneName']);
        $this->Gui->pagetitle ($Zone['Adszone']['zoneName']);
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_banners', true), '/admin/banners/');
        $this->Gui->navigation(__('admincp_zones', true), '/admin/banners/browse');
        $this->Gui->navigation($Zone['Adszone']['zoneName']);
    }


    function admin_zoneinformation ($adsZID){
        $this->Auth->AuthAdmin ($this, 'banners', 'read');

        $adsZID = intval ($adsZID);
        $adsZID == 0 ? die () : 1 == 1;

        $Zone = $this->Adszone->find ('first', array ('conditions' => "`Adszone`.`adsZID` = '$adsZID'", 'fields' => array('zoneDesc')));

        if(!is_array($Zone)){
            die ();
        }

        print $Zone['Adszone']['zoneDesc'];

        die ();
    }

    function admin_active($id){
        $this->Auth->AuthAdmin ($this, 'banners', 'update');
        
        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }
        $cond = "`Adsbanner`.`adsBID` = '$id'";
        $user = $this->Adsbanner->getBanner($cond);
        $user['Adsbanner']['adsBID'] = $user['Adsbanner']['adsBID'];
        $user['Adsbanner']['bannerActive'] = $user['Adsbanner']['bannerActive'] * -1;
        if ($this->Adsbanner->save($user, false, array('bannerActive'))) {
            Cache::delete('Banner');
            $this->redirect('/admin/banners/browsezone/'.$user['Adsbanner']['adsZID']);
        }
    }

	function beforeRender(){
		$this->Gui->DoGUIvar ($this);
	}
}