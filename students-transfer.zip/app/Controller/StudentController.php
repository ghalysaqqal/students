<?php

App::uses('AppController', 'Controller');

class StudentController extends AppController {

    var $name = 'Student';
    var $uses = array('Student', 'Areatext', 'Emailmsg', 'Bus', 'Schedule', 'Studenttime', 'Statistics', 'Complaint',
        'Buscoordinates', 'Time', 'Servicerate', 'Confdb', 'Bustime', 'Student2', 'Collagetext');
    var $components = array('Conf', 'Gui', 'Auth', 'Email', 'Sms');
    var $helpers = array('Layout', 'Pagination', 'Row', 'Url', 'Text', 'Editor');
    var $Config = array();
    
    function sendsms(){
       
        
        $student['Student']['email_confirm_key'] = date('Y-m-d H:i:s');
        $mob = '905397222544';
        
        $result = $this->Sms->sendSMS($this->Config['mobile'], $this->Config['password'], $mob, 'StudentsBus', 'كود التفعيل الخاص بحسابك : '.$student['Student']['email_confirm_key'] , $this->Config['timeSend'], $this->Config['dateSend'], '0', $this->Config['applicationType']);
        print_r($result);
        die();
    }
   
    function checkinfo() {
        $this->Gui->layout('webservice');
        $number = intval(@$_POST['number']);
        $arr = array();
        if (!empty($number) || $number > 0) {
            $cond = "`Student2`.`student_number` = '$number'";
            $student = $this->Student2->getStudent($cond);
            if (!empty($student)) {
                $arr = array(
                    'name' => $student['Student2']['name'],
                    'mob' => $student['Student2']['mob']
                );
            } else {
                $arr = array(
                    'name' => 'لايوجد معلومات',
                    'mob' => 'لايوجد معلومات',
                );
            }
        }
        echo json_encode($arr);
    }

    public function add() {
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_students', true), '/admin/student/');
        $this->Gui->navigation(__('add', true));

        App::import('Vendor', 'generatekey');
        $this->set('password', generatekey(8));

        $cond = "`Areatext`.`local` = '" . LANG . "'";
        $this->set('areas', $this->Areatext->getList($cond));

        $cond = "`Collagetext`.`local` = '" . LANG . "'";
        $this->set('collages', $this->Collagetext->getList($cond));

        $cond = "`chairs` > `booked_chairs`";
        $this->set('buses', $this->Bus->getList($cond));

        $cond = "`Time`.`type` LIKE 'GOING'";
        $this->set('going', $this->Time->getAll($cond));

        $cond = "`Time`.`type` LIKE 'RETURN'";
        $this->set('return', $this->Time->getAll($cond));

        if (!empty($this->data)) {
            $recaptcha = $this->data['g-recaptcha-response'];

            $google_url = "https://www.google.com/recaptcha/api/siteverify";
            $secret = $this->Config['google_secret_key'];
            $ip = $_SERVER['REMOTE_ADDR'];
            $url = $google_url . "?secret=" . $secret . "&response=" . $recaptcha . "&remoteip=" . $ip;
            App::import('Vendor', 'curl');
            $res = getCurlData($url);
            $res = json_decode($res, true);

            $errormessage = array();

            if (empty($res['success'])) {
                #$errormessage[] = __('Please Check reCAPTCHA', true);
            }

            $number = intval($this->data['Student']['student_number']);
            $cond = "`Student2`.`student_number` = '$number'";
            $student = $this->Student2->getStudent($cond);

            if (empty($student)) {
                $errormessage[] = __('No match in the database', true);
            }

            if ($student['Student2']['done'] == 1) {
                $errormessage[] = __('The information has been registered before', true);
            }

            if (count(@$this->data['Studentday']) < 1) {
                $errormessage[] = __('Please Check at least 1 day', true);
            }

            if (sizeof($errormessage) > 0) {
                $this->set('errormessage', $errormessage);
                $this->render();
            } else {
                if ($this->Student->validates()) {
                    $pp['Student']['id'] = null;
                    //$pp['Student']['dob'] = date('Y-m-d', strtotime($this->data['Student']['dob']));
                    $pp['Student']['postDate'] = date('Y-m-d H:i:s');
                    $pp['Student']['username'] = $this->data['Student']['student_number'];
                    $pp['Student']['password'] = md5(Configure::read('Security.salt1') . md5('1111') . Configure::read('Security.salt2'));
                    $pp['Student']['pswd'] = '1111';

                    App::import('Vendor', 'generatekey');
                    $pp['Student']['email_confirm_key'] = generatekey(4, 123456789);
                    $pp['Student']['mob_confirm_key'] = generatekey(4, 123456789);

                    if ($this->data['Student']['place_study'] == 'OTHER')
                        $pp['Student']['place_study'] = $this->data['Student']['other_study'];
                    else
                        $pp['Student']['place_study'] = $this->data['Student']['place_study'];

                    $result = $this->Student->query("SHOW TABLE STATUS LIKE 'student'");
                    $lastid = $result[0]['TABLES']['Auto_increment'];
                    $qrData = file_get_contents('https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=' . $lastid);
                    $pp['Student']['qr'] = $lastid . '.png';
                    $file = new File(WWW_ROOT . 'upload' . DS . 'images' . DS . $pp['Student']['qr'], true);
                    $file->write($qrData);

                    if ($this->Student->save(array_merge($this->data['Student'], $pp['Student']))) {
                        $id = $this->Student->getLastInsertID();

                        $this->Student2->markAsDone(trim(intval($student['Student2']['student_number'])));

                        //increase bus chairs
                        //$this->Bus->change_count_booked_count($this->data['Student']['bus_id']);

                        if (@$this->data['Studentday']['sunday'] == 'on') {
                            $st['Studenttime']['id'] = null;
                            $st['Studenttime']['student_id'] = $id;
                            $st['Studenttime']['day'] = 'sunday';
                            $st['Studenttime']['going_id'] = $this->data['Studentgoing']['sunday'];
                            $st['Studenttime']['return_id'] = $this->data['Studentreturn']['sunday'];
                            $st['Studenttime']['going'] = $this->Time->getValueByKey($this->data['Studentgoing']['sunday'], 'time');
                            $st['Studenttime']['return'] = $this->Time->getValueByKey($this->data['Studentreturn']['sunday'], 'time');
                            $this->Studenttime->save($st);
                        }

                        if (@$this->data['Studentday']['monday'] == 'on') {
                            $st['Studenttime']['id'] = null;
                            $st['Studenttime']['student_id'] = $id;
                            $st['Studenttime']['day'] = 'monday';
                            $st['Studenttime']['going_id'] = $this->data['Studentgoing']['monday'];
                            $st['Studenttime']['return_id'] = $this->data['Studentreturn']['monday'];
                            $st['Studenttime']['going'] = $this->Time->getValueByKey($this->data['Studentgoing']['monday'], 'time');
                            $st['Studenttime']['return'] = $this->Time->getValueByKey($this->data['Studentreturn']['monday'], 'time');
                            $this->Studenttime->save($st);
                        }

                        if (@$this->data['Studentday']['tuesday'] == 'on') {
                            $st['Studenttime']['id'] = null;
                            $st['Studenttime']['student_id'] = $id;
                            $st['Studenttime']['day'] = 'tuesday';
                            $st['Studenttime']['going_id'] = $this->data['Studentgoing']['tuesday'];
                            $st['Studenttime']['return_id'] = $this->data['Studentreturn']['tuesday'];
                            $st['Studenttime']['going'] = $this->Time->getValueByKey($this->data['Studentgoing']['tuesday'], 'time');
                            $st['Studenttime']['return'] = $this->Time->getValueByKey($this->data['Studentreturn']['tuesday'], 'time');
                            $this->Studenttime->save($st);
                        }

                        if (@$this->data['Studentday']['wednesday'] == 'on') {
                            $st['Studenttime']['id'] = null;
                            $st['Studenttime']['student_id'] = $id;
                            $st['Studenttime']['day'] = 'wednesday';
                            $st['Studenttime']['going_id'] = $this->data['Studentgoing']['wednesday'];
                            $st['Studenttime']['return_id'] = $this->data['Studentreturn']['wednesday'];
                            $st['Studenttime']['going'] = $this->Time->getValueByKey($this->data['Studentgoing']['wednesday'], 'time');
                            $st['Studenttime']['return'] = $this->Time->getValueByKey($this->data['Studentreturn']['wednesday'], 'time');
                            $this->Studenttime->save($st);
                        }

                        if (@$this->data['Studentday']['thursday'] == 'on') {
                            $st['Studenttime']['id'] = null;
                            $st['Studenttime']['student_id'] = $id;
                            $st['Studenttime']['day'] = 'thursday';
                            $st['Studenttime']['going_id'] = $this->data['Studentgoing']['thursday'];
                            $st['Studenttime']['return_id'] = $this->data['Studentreturn']['thursday'];
                            $st['Studenttime']['going'] = $this->Time->getValueByKey($this->data['Studentgoing']['thursday'], 'time');
                            $st['Studenttime']['return'] = $this->Time->getValueByKey($this->data['Studentreturn']['thursday'], 'time');
                            $this->Studenttime->save($st);
                        }

                        //statistics
                        $this->Statistics->updatevalue('students');

                        $this->redirect('/student/add/?result=done');
                    }
                }
            }
        }
    }

    function test() {
        /*
          $start = $this->Config['start-semester'];
          $end = $this->Config['end-semester'];

          while($start <= $end) {
          echo $start. "\n";

          }

          die(); */
        $start = strtotime("today");
        $end = strtotime("2016-11-05");

        $friday = strtotime("friday", $start);
        $monday = strtotime("monday", $start);
        while ($friday <= $end) {
            echo "fri=", date("Y-m-d", $friday), "\n";
            echo "mon=", date("Y-m-d", $monday), "\n";
            $friday = strtotime("+1 weeks", $friday);
            $monday = strtotime("+1 weeks", $monday);
        }
    }

    function qr() {

        $result = $this->Student->query("SHOW TABLE STATUS LIKE 'student'");
        print_r($result[0]['TABLES']['Auto_increment']);

        die();

        $qrData = file_get_contents('https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=1');
        $file = new File(WWW_ROOT . 'upload' . DS . '1111.png', true);
        $file->write($qrData);
        /*

          //App::import('Vendor', 'curl');
          $file = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=1' ;
          $result = file_get_contents($file);


          // İçeriğe yeni bir kişi ekleyelim
          $result .= "/upload/";
          // İçeriği dosyaya yazalım
          file_put_contents($file, $result);
          print_r($result);

          die(); */
    }

    function admin_index() {
        $this->Auth->AuthAdmin($this);

        $cond = null;
        $fields = array('id', 'name', 'email', 'bus_id', 'active');
        $this->set('students', $this->Student->getAll($cond, $fields));

        $this->Gui->headline(__('browse', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Students Management', true), '/admin/student/');
        $this->Gui->navigation(__('browse', true));
    }

    public function admin_add() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_students', true), '/admin/student/');
        $this->Gui->navigation(__('add', true));

        App::import('Vendor', 'generatekey');
        $this->set('password', generatekey(8));

        $cond = "`Areatext`.`local` = '" . LANG . "'";
        $this->set('areas', $this->Areatext->getList($cond));

        $cond = "`chairs` > `booked_chairs`";
        $this->set('buses', $this->Bus->getList($cond));

        $cond = "`Collagetext`.`local` = '" . LANG . "'";
        $this->set('collages', $this->Collagetext->getList($cond));

        if (!empty($this->data)) {
            if ($this->Student->validates()) {
                $pp['Student']['id'] = null;
                //$pp['Student']['dob'] = date('Y-m-d', strtotime($this->data['Student']['dob']));
                $pp['Student']['postDate'] = date('Y-m-d H:i:s');
                $pp['Student']['password'] = md5(Configure::read('Security.salt1') . md5($this->data['Student']['password']) . Configure::read('Security.salt2'));
                $pp['Student']['pswd'] = $this->data['Student']['password'];

                App::import('Vendor', 'generatekey');
                $pp['Student']['email_confirm_key'] = generatekey(4, 123456789);
                $pp['Student']['mob_confirm_key'] = generatekey(4, 123456789);

                $result = $this->Student->query("SHOW TABLE STATUS LIKE 'student'");
                $lastid = $result[0]['TABLES']['Auto_increment'];
                $qrData = file_get_contents('https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=' . $lastid);
                $pp['Student']['qr'] = $lastid . '.png';
                $file = new File(WWW_ROOT . 'upload' . DS . 'images' . DS . $pp['Student']['qr'], true);
                $file->write($qrData);

                if ($this->data['Student']['place_study'] == 'OTHER')
                    $pp['Student']['place_study'] = $this->data['Student']['other_study'];
                else
                    $pp['Student']['place_study'] = $this->data['Student']['place_study'];

                if ($this->Student->save(array_merge($this->data['Student'], $pp['Student']))) {
                    $student_id = $this->Student->getLastInsertID();

                    //increase bus chairs
                    $this->Bus->change_count_booked_count($this->data['Student']['bus_id']);

                    //statistics
                    $this->Statistics->updatevalue('students');

                    //generate dates
                    $start = strtotime(date('Y-m-d'));
                    $end = strtotime($this->Config['end-semester']);

                    $days = array('saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday');

                    for ($i = 0; $i < count($days); $i++) {
                        $currentday = @$this->data['Student']['day'][$days[$i]];

                        if ($currentday == 'on') {
                            $st['Studenttime']['id'] = null;
                            $st['Studenttime']['student_id'] = $student_id;
                            $st['Studenttime']['day'] = $days[$i];
                            $st['Studenttime']['going'] = $this->data['Student']['going'];
                            $st['Studenttime']['return'] = $this->data['Student']['return'];
                            $this->Studenttime->save($st);

                            $day = strtotime($days[$i], $start);
                            $ss['Schedule']['id'] = null;
                            $ss['Schedule']['bus_id'] = $this->data['Student']['bus_id'];
                            $ss['Schedule']['student_id'] = $student_id;
                            while ($day <= $end) {
                                $ss['Schedule']['date'] = date("Y-m-d", $day);

                                $ss['Schedule']['time'] = $this->data['Student']['going'];
                                $ss['Schedule']['type'] = 'GOING';
                                $this->Schedule->save($ss);

                                $ss['Schedule']['time'] = $this->data['Student']['return'];
                                $ss['Schedule']['type'] = 'RETURN';

                                $this->Schedule->save($ss);

                                $day = strtotime("+1 weeks", $day);
                            }
                        }
                    }
                    $this->redirect('/admin/student/addtimestostudent/' . $student_id);
                }
            }
        }
    }

    function admin_addtimestostudent($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $cond = "`Student`.`id` = '$id'";
        $student = $this->Student->getStudent($cond);
        if (!is_array($student)) {
            $this->redirect('/admin/student/index/');
            die();
        }
        $this->set('student', $student);
        $days = array('saturday' => __('saturday'),
            'sunday' => __('sunday'),
            'monday' => __('monday'),
            'tuesday' => __('tuesday'),
            'wednesday' => __('wednesday'),
            'thursday' => __('thursday'), 'friday' => __('friday'));
        $this->set('days', $days);

        $cond = "`Bustime`.`type` LIKE 'GOING' AND `Bustime`.`bus_id` = '" . $student['Student']['bus_id'] . "'";
        $this->set('goings', $this->Bustime->getAll($cond));

        $cond = "`Bustime`.`type` LIKE 'RETURN' AND `Bustime`.`bus_id` = '" . $student['Student']['bus_id'] . "'";
        $this->set('returns', $this->Bustime->getAll($cond));

        if (!empty($this->data)) {

            $st['Studenttime']['id'] = null;
            $st['Studenttime']['student_id'] = $id;
            $st['Studenttime']['day'] = strtolower($this->data['Student']['day']);
            $st['Studenttime']['going_id'] = $this->data['Student']['going'];
            $st['Studenttime']['return_id'] = $this->data['Student']['return'];
            $st['Studenttime']['going'] = $this->Time->getValueByKey($this->data['Student']['going'], 'time');
            $st['Studenttime']['return'] = $this->Time->getValueByKey($this->data['Student']['return'], 'time');
            $this->Studenttime->save($st);

            //generate dates
            $start = strtotime(date('Y-m-d'));
            $end = strtotime($this->Config['end-semester']);

            $day = strtotime($st['Studenttime']['day'], $start);
            $ss['Schedule']['id'] = null;
            $ss['Schedule']['bus_id'] = $student['Student']['bus_id'];
            $ss['Schedule']['day'] = $st['Studenttime']['day'];
            $ss['Schedule']['student_id'] = $id;
            $day = strtotime($st['Studenttime']['day'], $start);

            while ($day <= $end) {
                $ss['Schedule']['date'] = date("Y-m-d", $day);

                $ss['Schedule']['time_id'] = $this->data['Student']['going'];
                $ss['Schedule']['time'] = $st['Studenttime']['going'];
                $ss['Schedule']['type'] = 'GOING';
                $this->Schedule->save($ss);

                $ss['Schedule']['time_id'] = $this->data['Student']['return'];
                $ss['Schedule']['time'] = $st['Studenttime']['return'];
                $ss['Schedule']['type'] = 'RETURN';

                $this->Schedule->save($ss);

                $day = strtotime("+1 weeks", $day);
            }

            $this->redirect('/admin/student/addtimestostudent/' . $id);
        }
    }

    function admin_deletetime($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        if (($id) <= 0) {
            $this->redirect('/admin/student/index/');
            die();
        }

        $cond = "`Studenttime`.`id` = '$id'";
        $fields = array('day', 'student_id');
        $day = $this->Studenttime->getTime($cond, $fields);

        if ($this->Studenttime->delete($id)) {
            //empty dates
            $this->Schedule->emptyDatesByDay($day['Studenttime']['student_id'], date('Y-m-d'), $day['Studenttime']['day']);

            $this->redirect('/admin/student/addtimestostudent/' . $day['Studenttime']['student_id']);
        }
    }

    public function admin_edit($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $cond = "`Student`.`id` = '$id'";
        $student = $this->Student->getStudent($cond);
        if (!is_array($student)) {
            $this->redirect('/admin/student/index/');
            die();
        }
        $this->set('student', $student);

        $cond = "`Collagetext`.`local` = '" . LANG . "'";
        $this->set('collages', $this->Collagetext->getList($cond));

        $cond = "`Areatext`.`local` = '" . LANG . "'";
        $this->set('areas', $this->Areatext->getList($cond));

        //$cond = "`chairs` > `booked_chairs`";
        $cond = null;
        $this->set('buses', $this->Bus->getList($cond));

        $_days = array();
        for ($i = 0; $i < count($student['Studenttime']); $i++) {
            array_push($_days, $student['Studenttime'][$i]['day']);
        }
        $this->set('days', $_days);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Student Managment', true), '/admin/student/index/');

        if (!empty($this->data)) {
            $this->Student->set($this->data);

            if ($this->Student->validates()) {
                $pp['Student']['id'] = $id;

                if (!empty($this->data['Student']['password'])) {
                    $pp['Student']['password'] = md5(Configure::read('Security.salt1') . md5($this->data['Student']['password']) . Configure::read('Security.salt2'));
                    $pp['Student']['pswd'] = $this->data['Student']['password'];
                }

                if ($this->data['Student']['place_study'] == 'OTHER')
                    $pp['Student']['place_study'] = $this->data['Student']['other_study'];
                else
                    $pp['Student']['place_study'] = $this->data['Student']['place_study'];

                if ($this->Student->save(array_merge($this->data['Student'], $pp['Student']))) {
                    //empty dates
                    //$this->Schedule->emptyDates($id, date('Y-m-d'));
                    
                    $this->Schedule->changeBus($id, $this->data['Student']['bus_id']);

                    //empty times
                    $this->Studenttime->emptyTimes($id);

                    //increase bus chairs
                    $this->Bus->change_count_booked_count($student['Student']['bus_id'], 1, false);
                    $this->Bus->change_count_booked_count($this->data['Student']['bus_id']);
                    /*
                      //generate dates
                      $start = strtotime($this->Config['start-semester']);
                      $end = strtotime($this->Config['end-semester']);

                      $days = array('saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday');

                      for ($i = 0; $i < count($days); $i++) {
                      $currentday = @$this->data['Student']['day'][$days[$i]];

                      if ($currentday == 'on') {
                      $st['Studenttime']['id'] = null;
                      $st['Studenttime']['student_id'] = $id;
                      $st['Studenttime']['day'] = $days[$i];
                      $st['Studenttime']['going'] = $this->data['Student']['going'];
                      $st['Studenttime']['return'] = $this->data['Student']['return'];
                      $this->Studenttime->save($st);

                      $day = strtotime($days[$i], $start);
                      $ss['Schedule']['id'] = null;
                      $ss['Schedule']['bus_id'] = $this->data['Student']['bus_id'];
                      $ss['Schedule']['student_id'] = $id;
                      while ($day <= $end) {
                      $ss['Schedule']['date'] = date("Y-m-d", $day);

                      $ss['Schedule']['time'] = $this->data['Student']['going'];
                      $ss['Schedule']['type'] = 'GOING';
                      $this->Schedule->save($ss);

                      $ss['Schedule']['time'] = $this->data['Student']['return'];
                      $ss['Schedule']['type'] = 'RETURN';

                      $this->Schedule->save($ss);

                      $day = strtotime("+1 weeks", $day);
                      }
                      }
                      }
                     */
                    $this->redirect('/admin/student/index/?result=done');
                }
            } else
                $this->render();
        }
        else {
            $this->Student->data = $this->Student;
        }
    }

    function admin_times($student_id) {
        $this->Auth->AuthAdmin($this);

        $student_id = intval($student_id);
        if ($student_id <= 0) {
            $this->redirect('/admin/index');
            die();
        }

        $this->Gui->layout('admin');
        $this->Gui->headline(__('browse', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_item', true));
        $this->Gui->navigation(__('browse', true));

        $this->set('type', $type);

        $cond = "`Studentitem`.`student_id` = '$student_id' AND `Studentitem`.`type` LIKE '$type'";
        $this->set('times', $this->Studenttimes->getAll($cond, '*'));
    }

    function admin_details($id) {
        $this->Auth->AuthAdmin($this);

        $this->Gui->headline(__('Students Management', true));
        $this->Gui->navigation(__('Dashboard', true), '/admin/index');
        $this->Gui->navigation(__('Students Management', true), '/admin/student/index');
        $this->Gui->navigation(__('Details View', true));

        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }

        $cond = "`Student`.`id` = '$id'";
        $this->set('student', $this->Student->getStudent($cond));
    }

    function printinfo($id) {
        $this->Auth->AuthAdmin($this);
        $this->Gui->layout('print');

        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }

        $cond = "`Student`.`id` = '$id'";
        $this->set('student', $this->Student->getStudent($cond));
    }

    function admin_delete($id) {
        $this->Auth->AuthAdmin($this);
        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }
        $cond = "`Student`.`id` = '$id'";
        $student = $this->Student->getStudent($cond);
        if (empty($student)) {
            $this->redirect('/admin/index');
            die();
        }

        if ($this->Student->delete($id)) {
            //statistics
            $this->Statistics->updatevalue('students', 1, false);

            //empty dates
            $this->Schedule->emptyDates($id, date('Y-m-d'));

            $this->redirect('/admin/student/index/' . $type);
        }
    }

    function admin_coursestudents($id) {
        $this->Auth->AuthAdmin($this);
        $id = intval($id);
        if ($id <= 0) {
            $this->redirect('/');
            die();
        }

        $cond = "`Studentitem`.`item_id` = '$id' AND `Studentitem`.`type` = 'S'";
        $fields = array('student_id');
        $students = $this->Studentitem->getAll($cond, $fields);

        $condArray = array();
        foreach ($students as $data) {
            $condArray[] = "`Student`.`id` = '" . $data['Studentitem']['student_id'] . "'";
        }

        if (!empty($condArray)) {
            $cond = implode(' OR ', $condArray);
            $fields = array('id', 'fullname', 'kind');
            $this->set('students', $this->Student->getAll($cond, $fields));
        } else {
            $this->set('students', array());
        }

        $this->Gui->headline(__('Students in Course', true));
        $this->Gui->pagetitle(__('Students in Course', true));
        $this->Gui->navigation(__('homepage', true), '/');
        $this->Gui->navigation(__('Students in Course', true));
    }

    function getbusinfo() {
        $this->Gui->layout('blank');
        $id = intval($_POST['bus_id']);
        $cond = "`Bus`.`id`='$id'";
        $fields = array('id', 'going_id', 'return_id');
        $this->set('bus', $this->Bus->getBus($cond, $fields));
    }

    function admin_schedule($student_id) {
        $this->Auth->AuthAdmin($this);

        $student_id = intval($student_id);
        if ($student_id <= 0) {
            $this->redirect('/admin/student');
            die();
        }

        $this->Gui->layout('admin');
        $this->Gui->headline(__('schedule', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Students Management', true), '/admin/bus/');
        $this->Gui->navigation(__('schedule', true));

        if (!isset($_GET['date']) || empty($_GET['date'])) {
            $this->redirect('/admin/student');
            die();
        }

        $condArray = array();
        if (!empty($_GET['date'])) {
            $date = date('Y-m-d', strtotime($_GET['date']));
            $condArray[] = "`Schedule`.`date` = '$date'";
        }
        $condArray[] = "`Schedule`.`student_id` = '$student_id'";

        $cond = implode(' AND ', $condArray);
        $this->set('schedule', $this->Schedule->getAll($cond));
    }

    /* web services */

    function ws_login() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $username = (@$_POST['username']);
        $password = (@$_POST['password']);
        $reg_id = (@$_POST['reg_id']);
        $type = trim(@$_POST['type']);
        if (empty($username) || empty($password)) {
            $this->set('message', 'USERNAME_PASSWORD_REGID_ARE_REQUIRED');
            return;
        }

        if (empty($type))
            $type = 'IPHONE';
        $SomeOne = $this->Student->find('first', array('conditions' => "(`Student`.`username` = '$username' OR `Student`.`student_number` = '$username') AND `Student`.`active` = '1'",));
        if (!is_array($SomeOne)) {
            $this->set('message', 'NO_ACCOUNT');
            return;
        } else {
            $Password = md5(Configure::read('Security.salt1') . md5($password) . Configure::read('Security.salt2'));
            if ($Password != $SomeOne['Student']['password']) {
                $this->set('message', 'WRONG_PASSWORD');
                return;
            } else {
                if ($type == 'ANDROID') {
                    $this->Student->setRegId($SomeOne['Student']['id'], $reg_id);
                } else {
                    if (!empty($reg_id))
                        $this->Student->setRegId($SomeOne['Student']['id'], $reg_id);
                }

                $this->set('result', $SomeOne);
                return;
            }
        }
    }

    function ws_send_confirm() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $email = @$_POST['email'];
        $mob = @$_POST['mob'];
        $emr_mob = @$_POST['emr_mob'];
        $lat = @$_POST['lat'];
        $lng = @$_POST['lng'];
        $id = intval(@$_POST['student_id']);

        if (empty($email) || empty($mob) || empty($emr_mob) || empty($lat) || empty($lng) || empty($id)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }

        $student = $this->Student->find('first', array(
            'conditions' => "`Student`.`id` = '$id'",
        ));
        if (empty($student)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }
        //checking number
        $mob = trim($mob);
        $mob = ltrim($mob, '0');
        $mob = ltrim($mob, '+966');
        $mob = ltrim($mob, '966');
        $mob = $this->Config['mob_prefix'].$mob;
           
        if(preg_match(PATTERN_SAUDI_MOBILE, $mob) <= 0){
            $this->set('message', 'MOBILE_NUMBER_IS_INVALID');
            return;
        }
        $student['Student']['mob'] =  $mob;
        $student['Student']['emr_mob'] = $emr_mob;
        $student['Student']['email'] = $email;
        $student['Student']['lat'] = $lat;
        $student['Student']['lng'] = $lng;

        if ($this->Student->save($student)) {

            $this->Email->from = sprintf('%s <%s>', $this->Config['from'], $this->Config['fromaddress']);
            $this->Email->to = $email;
            $this->Email->subject = $student['Student']['email_confirm_key'] . ' - '.__('Confirm account', true);
            $this->Email->template = 'sentemail';
            $this->Email->sendAs = 'html';
            //get email msg
            $msg = $this->Emailmsg->getMsg('ara', 'CONFIRM_ACCOUNT');

            $messge = $msg['Emailmsg']['content'];

            $messge = str_replace('$NAME', $student['Student']['name'], $messge);
            $messge = str_replace('$CODE', $student['Student']['email_confirm_key'], $messge);

            $this->set('msg', $messge);
            
            if ($this->Email->send()) {
                //send sms
                //$this->Sms->sendSMS($this->Config['mobile'], $this->Config['password'], $mob, $this->Config['sender'], $this->Config['code_msg'].' : '.$student['Student']['email_confirm_key'] , $this->Config['timeSend'], $this->Config['dateSend'], '0', $this->Config['applicationType']);
                $this->set('message', 'SENT_DONE');
                return;
            } else {
                $this->set('message', 'ERRORIN_SENDIND');
                return;
            }
        }
    }

    function ws_confirm_account() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $id = $_POST['student_id'];
        $email_confirm_key = $_POST['email_confirm_key'];

        if (empty($id) || empty($email_confirm_key)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }

        $student = $this->Student->find('first', array(
            'conditions' => "`Student`.`id` = '$id' AND `Student`.`email_confirm_key` LIKE '$email_confirm_key'",
        ));
        if (empty($student)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }
        if ($student['Student']['email_confirm_key'] != $email_confirm_key) {
            die();
        } else {
            $student['Student']['email_confirm_key'] = NULL;
            $student['Student']['email_confirm'] = 1;

            if ($this->Student->save($student)) {
                $this->set('message', 'CONFIRMED');
                return;
            }
        }
    }

    function ws_next_trip() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $id = $_POST['student_id'];
        if (empty($id)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $current_date = date('Y-m-d');
        $current_time = date('H:i:s');
        $cond = "`Schedule`.`date` > '$current_date'  AND `Schedule`.`student_id`  = '$id'";
        $fields = array('id', 'bus_id', 'date', 'time', 'type', 'triptype');
        $result = $this->Schedule->getSchedule($cond, $fields);
        if (empty($result)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }
        $this->set('result', $result);
    }

    function ws_last_three_next_trips() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $id = $_POST['student_id'];
        if (empty($id)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $current_date = date('Y-m-d');
        $cond = "`Schedule`.`date` >= '$current_date' AND `Schedule`.`finished` = '-1' AND `Schedule`.`student_id` = '$id'";
        $fields = array('id', 'bus_id', 'date', 'time', 'type', 'triptype');
        $order = "`Schedule`.`date` ASC";
        $result = $this->Schedule->getSchedules($cond, $fields, 1, 6, $order);
        if (empty($result)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }
        $this->set('result', $result);
    }

    /* STUDENT */

    function ws_student_schedule() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');

        $id = intval(@$_POST['student_id']);
        if ($id <= 0) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $current_date = date('Y-m-d');
        $current_time = date('H:i:s');
        $cond = "`Schedule`.`student_id` = '$id' AND `Schedule`.`date` >= '$current_date' AND `Schedule`.`finished` = '-1'";
        $fields = array('id', 'bus_id', 'date', 'time', 'type', 'triptype', 'done', 'late', 'dontcome', 'cancel');
        $order = "`Schedule`.`id` ASC";
        $result = $this->Schedule->getAll($cond, $fields, $order);
        if (empty($result)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }
        $this->set('result', $result);
    }

    function ws_add_new_trip() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $student_id = intval($_POST['student_id']);
        $date = @$_POST['date'];
        $going_id = @$_POST['going_id'];
        $going = date('H:i:s', strtotime(@$_POST['going']));
        $return_id = @$_POST['return_id'];
        $return = date('H:i:s', strtotime(@$_POST['return']));
        
        if ($student_id <= 0 || empty($date) || empty($going_id) || empty($going) || empty($return_id) || empty($return)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $current_date = date('Y-m-d');
        if ($current_date >= $date) {
            $this->set('message', 'MUST_ADD_BEFORE_HOURS');
            return;
        }

        $cond = "`Student`.`id`='$student_id'";
        $fields = array('bus_id', 'name');
        $studnet = $this->Student->getStudent($cond, $fields);

        $cond = "`Bus`.`id` = '" . $studnet['Student']['bus_id'] . "'";
        $fields = array('going_id', 'return_id');
        $bus = $this->Bus->getBus($cond, $fields);

        $cond = "`Schedule`.`date` = '$date' AND `Schedule`.`student_id`='$student_id'";
        $sd = $this->Schedule->getCount($cond);
        if ($sd > 0) {
            $this->set('message', 'MUST_ADD_BEFORE_HOURS');
            return;
        }
        
        $selected_day =  strtolower(date('l', strtotime($date)));
        if($selected_day=='saturday'||$selected_day=='friday'){
            $this->set('message', 'CANT_ADD_TRIP_IN_HOLIDAY');
            return;
        }
        
        $tmp['Schedule']['id'] = null;
        $tmp['Schedule']['student_id'] = $student_id;
        $tmp['Schedule']['bus_id'] = $studnet['Student']['bus_id'];
        $tmp['Schedule']['date'] = date('Y-m-d', strtotime($date));
        $tmp['Schedule']['time_id'] = $going_id;
        $tmp['Schedule']['time'] = $going;
        $tmp['Schedule']['type'] = 'GOING';
        $tmp['Schedule']['triptype'] = 'TEMP';
        $tmp['Schedule']['day'] = strtolower(date('l', strtotime($date)));
        if ($this->Schedule->save($tmp)) {
            $schedule_id = $this->Schedule->getLastInsertID();
            $tmp['Schedule']['type'] = 'RETURN';
            $tmp['Schedule']['time_id'] = $return_id;
            $tmp['Schedule']['time'] = $return;
            $this->Schedule->save($tmp);
            if ($this->Config['push_noti'] == 1) {
                $ids = array();
                $ids[] = $tmp['Schedule']['bus_id'];
                //send notification to bus
                if (!empty($ids)) {
                    $this->Bus->send_push_notification($ids, $student_id, $studnet['Student']['name'], $tmp['Schedule']['date'], $tmp['Schedule']['time'], $tmp['Schedule']['type'], $this->Config['google_api_key_bus'], 'NEWTRIP');
                }
            }

            $this->set('message', 'ADDED_TEMP_TRIP_DONE');
            return;
        }
    }

    /* STUDENT */

    function ws_cancel_trip() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $id = intval($_POST['student_id']);
        $trip_id = intval($_POST['trip_id']);
        if ($id <= 0 || $trip_id <= 0) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $cond = "`Schedule`.`student_id` = '$id' AND `Schedule`.`id` = '$trip_id' AND `Schedule`.`cancel` != '1'";
        $fields = array('id', 'date', 'time', 'type', 'triptype', 'bus_id', 'student_id');
        $order = "`Schedule`.`id` ASC";
        $result = $this->Schedule->getSchedule($cond, $fields, $order);
        if (empty($result)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }
        $to_time = strtotime(($result['Schedule']['date'] . ' ' . $result['Schedule']['time']));
        $from_time = strtotime(date("Y-m-d H:i:s"));
        $result_time = round(abs($to_time - $from_time) / 60, 2);

        if ($result_time <= $this->Config['time_to_cancel']) {
            $this->set('message', 'CANT_CANCEL_NOW');
            return;
        }

        $result['Schedule']['id'] = $trip_id;
        $result['Schedule']['cancel'] = 1;
        if ($this->Schedule->save($result)) {
            $this->Schedule->changestatus($result['Schedule']['id'], 'finished', date('Y-m-d H:i:s'));

            //send push notification to bus
            if ($this->Config['push_noti'] == 1) {
                $ids = array();
                $ids[] = $result['Schedule']['bus_id'];
                //send notification to bus
                if (!empty($ids)) {
                    $this->Bus->send_push_notification($ids, $result['Schedule']['student_id'], $this->Student->getValueByKey($result['Schedule']['student_id'], 'name'), $result['Schedule']['date'], $result['Schedule']['time'], $result['Schedule']['type'], $this->Config['google_api_key_bus'], 'CANCELTRIP');
                }
            }

            $this->set('message', 'CANCELED');
            return;
        }
    }

    function find_closest_time($array, $time) {
        //$count = 0;
        foreach ($array as $value) {
            //$interval[$count] = abs(strtotime($date) - strtotime($day));
            $interval[] = abs(strtotime($time) - strtotime($value));
            //$count++;
        }

        asort($interval);
        $closest = key($interval);

        return $array[$closest];
    }

    function ws_mark_trip_as_done() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $id = intval($_POST['student_id']);
        //$bus_id = intval($_POST['bus_id']);
        $trip_id = intval($_POST['trip_id']);
        $type = 'done'; /* (done, late, dontcome) */
        if ($trip_id <= 0) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $types = array('done', 'late', 'dontcome');
        if (!in_array($type, $types)) {
            $this->set('message', 'TYPE_NOT_FOUND');
            return;
        }

        //checking trip type
        $day = strtolower(date('l'));
        $cond = "`Studenttime`.`student_id` = '$id' AND `Studenttime`.`day` LIKE '$day'";
        $fields = array('going', 'return');
        $times_s = $this->Studenttime->getTime($cond, $fields);
        if (empty($times_s)) {
            $this->set('message', 'STUDENT_TIMES_NOT_FOUND');
            return;
        }
        $times = array
            (
            '0' => $times_s['Studenttime']['going'],
            '1' => $times_s['Studenttime']['return']
        );

        $closest_time = $this->find_closest_time($times, date('H:i:s'));

        $current_date = date('Y-m-d');
        //$current_time = date('H:i:s');
        $before_hour = date('H:i:s', strtotime('-1 hour', strtotime($closest_time)));
        $after_hour = date('H:i:s', strtotime('+1 hour', strtotime($closest_time)));

        $cond = "`Schedule`.`student_id` =  '$id'  AND  `Schedule`.`date` =  '$current_date' AND `Schedule`.`time` >= '$before_hour' AND `Schedule`.`time` <= '$after_hour' AND `Schedule`.`finished` =  '-1'";
        $fields = array('id', 'date', 'time', 'type', 'triptype');
        $order = "`Schedule`.`id` ASC";
        $result = $this->Schedule->getSchedule($cond, $fields, $order);
        if (empty($result)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }

        $this->Schedule->changestatus($result['Schedule']['id'], $type, date('Y-m-d H:i:s'));
        $this->Schedule->changestatus($result['Schedule']['id'], 'finished', date('Y-m-d H:i:s'));
        $this->set('message', 'DONE');
        return;
    }

    function ws_mark_trip_as_late() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        //$id = intval($_POST['student_id']);
        $trip_id = intval($_POST['trip_id']);
        //$bus_id = intval($_POST['bus_id']);
        $type = 'late'; /* (done, late, dontcome) */
        if ($trip_id <= 0) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $types = array('done', 'late', 'dontcome');
        if (!in_array($type, $types)) {
            $this->set('message', 'TYPE_NOT_FOUND');
            return;
        }

        /*
          //checking trip type
          $day=  strtolower(date('l'));
          $cond = "`Studenttime`.`student_id` = '$id' AND `Studenttime`.`day` LIKE '$day'";
          $fields = array('going', 'return');
          $times_s = $this->Studenttime->getTime($cond, $fields);
          if (empty($times_s)) {
          $this->set('message', 'STUDENT_TIMES_NOT_FOUND');
          return;
          }
          $times = array
          (
          '0' => $times_s['Studenttime']['going'],
          '1' => $times_s['Studenttime']['return']
          );

          $closest_time = $this->find_closest_time($times, date('H:i:s'));

          $current_date = date('Y-m-d');
          //$current_time = date('H:i:s');
          $before_hour = date('H:i:s', strtotime('-1 hour', strtotime($closest_time)));
          $after_hour = date('H:i:s', strtotime('+1 hour', strtotime($closest_time)));
         */
        $current_date = date('Y-m-d');
        $cond = "`Schedule`.`id` =  '$trip_id' AND `Schedule`.`date` = '$current_date' AND `Schedule`.`late` = '-1'";
        $fields = array('id', 'date', 'time', 'type', 'triptype');
        $order = "`Schedule`.`id` ASC";
        $result = $this->Schedule->getSchedule($cond, $fields, $order);
        if (empty($result)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }

        $this->Schedule->changestatus($result['Schedule']['id'], $type, date('Y-m-d H:i:s'));
        $this->Schedule->changestatus($result['Schedule']['id'], 'finished', date('Y-m-d H:i:s'));
        $this->set('message', 'DONE');
        return;
    }

    function ws_mark_trip_as_dontcome() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        //$id = intval($_POST['student_id']);
        //$bus_id = intval($_POST['bus_id']);
        $trip_id = intval($_POST['trip_id']);
        $type = 'dontcome'; /* (done, late, dontcome) */
        if ($trip_id <= 0 || empty($type)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $types = array('done', 'late', 'dontcome');
        if (!in_array($type, $types)) {
            $this->set('message', 'TYPE_NOT_FOUND');
            return;
        }
        /*
          //checking trip type
          $cond = "`Bus`.`id` = '$bus_id'";
          $fields = array('going_id', 'return_id');
          $bus = $this->Bus->getBus($cond, $fields);
          if (empty($bus)) {
          $this->set('message', 'BUS_NOT_FOUND');
          return;
          }
          $times = array
          (
          '0' => $this->Time->getValueByKey($bus['Bus']['going_id'], 'time'),
          '1' => $this->Time->getValueByKey($bus['Bus']['return_id'], 'time')
          );

          $closest_time = $this->find_closest_time($times, date('H:i:s'));
         */
        $current_date = date('Y-m-d');
        //$current_time = date('H:i:s');
        $cond = "`Schedule`.`id` =  '$trip_id' AND `Schedule`.`finished` =  '-1' AND `Schedule`.`date` = '$current_date'";
        $fields = array('id', 'date', 'time', 'type', 'triptype');
        $order = "`Schedule`.`id` ASC";
        $result = $this->Schedule->getSchedule($cond, $fields, $order);
        if (empty($result)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }

        $this->Schedule->changestatus($result['Schedule']['id'], $type, date('Y-m-d H:i:s'));
        $this->Schedule->changestatus($result['Schedule']['id'], 'finished', date('Y-m-d H:i:s'));
        $this->set('message', 'DONE');
        return;
    }

    /* STUDENT - BUS | ( QR code ) */

    function ws_change_trip_value() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $id = intval($_POST['student_id']);
        $type = strtolower($_POST['type']); /* (done, late, dontcome) */
        if ($id <= 0 || empty($type)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $types = array('done', 'late', 'dontcome');
        if (!in_array($type, $types)) {
            $this->set('message', 'TYPE_NOT_FOUND');
            return;
        }
        $current_date = date('Y-m-d');
        //$current_time = date('H:i:s');
        $cond = "`Schedule`.`student_id` =  '$id' AND  `Schedule`.`$type` !=  '1' AND  `Schedule`.`date` >=  '$current_date' AND  `Schedule`.`finished` !=  '1'";
        $fields = array('id', 'date', 'time', 'type', 'triptype');
        $order = "`Schedule`.`id` ASC";
        $result = $this->Schedule->getSchedule($cond, $fields, $order);
        if (empty($result)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }

        $this->Schedule->changestatus($result['Schedule']['id'], $type, date('Y-m-d H:i:s'));
        $this->Schedule->changestatus($result['Schedule']['id'], 'finished', date('Y-m-d H:i:s'));
        $this->set('message', 'DONE');
        return;
    }

    function ws_send_complaint() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $id = intval(@$_POST['student_id']);
        $subject = trim(@$_POST['subject']);
        $content = trim(@$_POST['content']);
        if ($id <= 0 || empty($subject) || empty($content)) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $com['Complaint']['student_id'] = $id;
        $com['Complaint']['subject'] = $subject;
        $com['Complaint']['content'] = $content;
        $com['Complaint']['postDate'] = date('Y-m-d H:i:s');
        $com['Complaint']['isRead'] = -1;

        if ($this->Complaint->save($com)) {

            $this->Email->from = sprintf('%s <%s>', $this->Config['from'], $this->Config['fromaddress']);
            $this->Email->to = $this->Config['email_monitor'];
            $this->Email->subject = __('New Complaint', true);
            $this->Email->template = 'sentemail';
            $this->Email->sendAs = 'html';
            $msg = $this->Emailmsg->getMsg('ara', 'NEWCOMPLAINT');
            $messge = $msg['Emailmsg']['content'];
            $messge = str_replace('$NAME', $this->Student->getValueByKey($id, 'name'), $messge);
            $messge = str_replace('$SUBJECT', $subject, $messge);
            $messge = str_replace('$CONTENT', $content, $messge);
            $this->set('msg', $messge);
            $this->Email->send();

            $this->Email->to = $this->Student->getValueByKey($id, 'email');
            $this->Email->subject = __('New Complaint has been sent', true);
            $msg = $this->Emailmsg->getMsg('ara', 'NEWCOMPLAINTSTUDENT');
            $messge = $msg['Emailmsg']['content'];
            $messge = str_replace('$NAME', $this->Student->getValueByKey($id, 'email'), $messge);
            $messge = str_replace('$SUBJECT', $subject, $messge);
            $messge = str_replace('$CONTENT', $content, $messge);
            $this->set('msg', $messge);
            $this->Email->send();

            $this->set('message', 'DONE');
            return;
        } else {
            $this->set('message', 'ERROR_IN_SENDING');
            return;
        }
    }

    function ws_where_is_bus() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $id = intval(@$_POST['bus_id']);
        $trip_id = intval(@$_POST['trip_id']);
        if ($id <= 0 || $trip_id <= 0) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        $cond = "`Schedule`.`bus_id` = '$id' AND `Schedule`.`id` = '$trip_id' AND `Schedule`.`finished` = '-1'";
        $fields = array('id', 'date', 'time', 'type', 'triptype');
        $order = "`Schedule`.`id` ASC";
        $result = $this->Schedule->getSchedule($cond, $fields, $order);
        if (empty($result)) {
            $this->set('message', 'NO_DATA_FOUND');
            return;
        }
        $to_time = strtotime(($result['Schedule']['date'] . ' ' . $result['Schedule']['time']));
        $from_time = strtotime(date("Y-m-d H:i:s"));
        $result_time = round(abs($to_time - $from_time) / 60, 2);

        if ($result_time > $this->Config['bus_avaiable']) {
            $this->set('message', 'NOT_AVAILABLE_NOW');
            return;
        }

        $cond = "`Buscoordinates`.`bus_id` ='$id'";
        $fields = array('lat', 'lng');
        $bus = $this->Buscoordinates->getBus($cond, $fields);
        if (empty($bus)) {
            $this->set('message', 'NO_BUS_COORDINATES');
            return;
        }
        $this->set('result', $bus);
    }

    function ws_rate_service() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $student_id = intval(@$_POST['student_id']);
        $rate_value = intval(@$_POST['rate_value']);
        if ($rate_value <= 0 || $student_id <= 0) {
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
        //check if student exist
        $cond = "`Student`.`id` ='$student_id'";
        $student = $this->Student->getCount($cond);
        if (empty($student)) {
            $this->set('message', 'STUDENT_NOT_FOUND');
            return;
        }
        if ($rate_value <= 0 || $rate_value > $this->Config['service-rate']) {
            $this->set('message', 'RATE_VALUE_MUST_BE_BETWEEN_1_AND_' . $this->Config['service-rate']);
            return;
        }
        $rate_before = $this->Servicerate->check($student_id);
        if ($rate_before) {
            $this->Servicerate->updaterate($student_id, $rate_value);
            $this->set('message', 'RATE_DONE');
            return;
        } else {
            $rate['Servicerate']['id'] = null;
            $rate['Servicerate']['student_id'] = $student_id;
            $rate['Servicerate']['rate'] = $rate_value;
            if ($this->Servicerate->save($rate)) {
                $this->Confdb->updatefullrate();
                $this->set('message', 'RATE_DONE');
                return;
            }
        }
    }

    function ws_enabledisablenoti() {
        $this->Gui->layout('blank');
        $value = intval(@$_POST['value']);
        $student_id = intval(@$_POST['student_id']);
        if ($student_id <= 0) {
            $this->set('message', 'STUDENT_ID_REQUIRED');
            return;
        }
        $cond = "`Student`.`id` = '$student_id'";
        $fields = array('id',);
        $student = $this->Student->getStudent($cond, $fields);
        if (empty($student)) {
            $this->set('message', 'STUDENT_NOT_EXISTED');
            return;
        }
        if ($value > 1 || $value < -1) {
            $this->set('message', 'VALUE_MUST_BE_1_OR_-1');
            return;
        }
        if ($value == 0) {
            $this->set('message', 'VALUE_MUST_BE_1_OR_-1');
            return;
        }
        $this->Student->enabledisableNoti($student_id, $value);
        $this->set('message', 'DONE');
        return;
    }

    function beforeRender() {
        $this->Gui->DoGUIvar($this);
    }

}
