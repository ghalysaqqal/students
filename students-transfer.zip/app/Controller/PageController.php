<?php

App::uses('AppController', 'Controller');

class PageController extends AppController {

    public $name = 'Page';
    public $uses = array('Page', 'Pagetext', 'Lang');
    public $components = array('Conf', 'Gui', 'Auth', 'Acl', 'Jqimgcrop', 'Upload', 'Resize');
    public $helpers = array('Layout', 'Pagination', 'Row', 'Editor', 'Url', 'Cropimage');
    var $Config = array();

    public function index($url) {
        // SQL Safe
        App::uses('Sanitize', 'Utility');
        $url = Sanitize::escape($url);

        $cond = "`Pagetext`.`local` = '" . LANG . "' AND `Page`.`url` = '" . $url . "' AND `Page`.`active` = '1'";
        $fields = array('title', 'content', 'desc', 'Page.thumb', 'tags');
        $Page = $this->Pagetext->getPage($cond, $fields);

        if (!empty($Page)) {
            $this->set('Page', $Page);
        } else {
            $this->redirect('/');
            die();
        }

        // GUI
        $this->Gui->headline($Page['Pagetext']['title']);
        $this->Gui->pagetitle($Page['Pagetext']['title']);
        $this->Gui->description($Page['Pagetext']['desc']);
        $this->Gui->keywords($Page['Pagetext']['tags']);
        $this->Gui->navigation(__('homepage', true), '/');
        $this->Gui->navigation($Page['Pagetext']['title']);
    }

    public function admin_index() {
        $this->Auth->AuthAdmin($this, 'page', 'read');

        $this->Gui->layout('admin');
        $this->Gui->headline(__('browse', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_page', true), '/admin/page/');
        $this->Gui->navigation(__('browse', true));

        $fields = array('Page.thumb', 'Page.id', 'url', 'active');
        $this->set('pagetexts', $this->Page->getAll(null, $fields));
        $this->set('Langs', $this->Lang->getLangs());
    }

    public function admin_add() {
        $this->Auth->AuthAdmin($this, 'page', 'create');

        $this->Gui->layout('admin');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_page', true), '/admin/page/');
        $this->Gui->navigation(__('add', true));

        $this->set('Langs', $Langs = $this->Lang->getLangs());

        if (!empty($this->data)) {

            if ($this->Page->validates()) {
                $pp['Page']['id'] = NULL;
                $pp['Page']['url'] = $this->data['Page']['url'];
                $pp['Page']['postDate'] = date('Y-m-d H:i:s');
                $pp['Page']['active'] = intval($this->data['Page']['active']);

                if ($this->data['Page']['thumb']['error'] == 0 && $this->data['Page']['thumb']['size'] > 0) {
                    $path = WWW_ROOT . 'upload' . DS . 'pages' . DS;
                    $path_thum = $path . 'thum' . DS;

                    $NewFileName = $this->Upload->newname($this->data['Page']['thumb']['name']);
                    // Main File
                    if ($this->Upload->upload($this->data['Page']['thumb'], $path, 'image', $NewFileName)) {
                        $pp['Page']['thumb'] = $NewFileName;

                        $MainFilePath = $path . $NewFileName;
                        $ThumFilePath = $path_thum . $NewFileName;
                        $this->Resize->resize($MainFilePath, $ThumFilePath, $this->Config['thumb_width_crop']);

                        $redirect_url = '/admin/page/editthumb';
                    } else {
                        $this->log(print ('Uploading Error in File'));
                    }
                } else {
                    $pp['Page']['thumb'] = null;
                    $redirect_url = '/admin/page/index/?result=done';
                }


                if ($this->Page->save($pp['Page'])) {
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

                    $page_id = $this->Page->getLastInsertID();

                    foreach ($Langs as $lang) {
                        $text['Pagetext']['id'] = NULL;
                        $text['Pagetext']['page_id'] = $page_id;
                        $text['Pagetext']['local'] = $lang['Lang']['id'];
                        $text['Pagetext']['title'] = $this->data['Pagetext']['title_' . $lang['Lang']['id']];
                        $text['Pagetext']['desc'] = $this->data['Pagetext']['desc_' . $lang['Lang']['id']];
                        $text['Pagetext']['content'] = $this->removelines($this->data['Pagetext']['content_' . $lang['Lang']['id']]);
                        $text['Pagetext']['tags'] = $this->data['Pagetext']['tags_' . $lang['Lang']['id']];

                        $this->Pagetext->save($text);
                    }
                    $this->redirect($redirect_url . '/' . $page_id);
                }
            }
        }
    }

    function admin_editthumb($id) {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('editthumb');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_item', true), '/admin/page/');
        $this->Gui->navigation(__('add', true));

        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }

        $path = WWW_ROOT . 'upload' . DS . 'pages' . DS;
        $path_thum = $path . 'thum' . DS;
        $path_small = $path . 'small' . DS;

        $cond = "`Page`.`id` = '$id'";
        $fields = array('thumb');
        $this->set('item', $item = $this->Page->getPage($cond, $fields));
        $this->set('thumb', $item['Page']['thumb']);
        list($width, $height, $type, $attr) = getimagesize($path_thum . $item['Page']['thumb']);
        $redirectionUrl = '/admin/Page/index?result=done';

        $this->set('width', $width);
        $this->set('height', $height);
        $this->set('path_thum', $path_thum);

        if (!empty($this->data)) {
            $this->Jqimgcrop->cropImage($this->Config['width_thum_pages'], $this->data['x1'], $this->data['y1'], $this->data['x2'], $this->data['y2'], $this->data['w'], $this->data['h'], $this->data['imagePath'], $this->data['imagePath']);

            $thum = $item['Page']['thumb'];

            $ThumFilePath = $path_thum . $thum;
            $SmallThumFilePath = $path_small . $thum;

            $this->Resize->resize($ThumFilePath, $SmallThumFilePath, $this->Config['width_page_thum_small'], 75);

            $this->redirect($redirectionUrl);
        }
    }

    public function admin_edit($id) {
        $this->Auth->AuthAdmin($this, 'page', 'update');

        $id = intval($id);
        $cond = "`Page`.`id` = '$id'";
        $Page = $this->Page->getPage($cond);
        if (!is_array($Page)) {
            $this->redirect('/admin/page');
            die();
        }
        $this->set('page', $Page);

        $this->set('pagetext', $pagetext = $this->Pagetext->find('all', array('conditions' => "`Pagetext`.`page_id` = '" . $Page['Page']['id'] . "'")));

        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_page', true), '/admin/page/');

        if (!empty($this->data)) {
            $this->Page->set($this->data);

            if ($this->Page->validates()) {
                $pp['Page']['id'] = $id;
                $pp['Page']['active'] = intval($this->data['Page']['active']);

                if ($this->data['Page']['thumb']['error'] == 0 && $this->data['Page']['thumb']['size'] > 0) {
                    $path = WWW_ROOT . 'upload' . DS . 'pages' . DS;
                    $path_thum = $path . 'thum' . DS;
                    $path_small = $path . 'small' . DS;

                    $NewFileName = $this->Upload->newname($this->data['Page']['thumb']['name']);
                    // Main File
                    if ($this->Upload->upload($this->data['Page']['thumb'], $path, 'image', $NewFileName)) {
                        @unlink($path . $Page['Page']['thumb']);
                        @unlink($path_thum . $Page['Page']['thumb']);
                        @unlink($path_small . $Page['Page']['thumb']);

                        $pp['Page']['thumb'] = $NewFileName;

                        $MainFilePath = $path . $NewFileName;
                        $ThumFilePath = $path_thum . $NewFileName;
                        $this->Resize->resize($MainFilePath, $ThumFilePath, $this->Config['thumb_width_crop']);

                        $redirectionUrl = '/admin/Page/editthumb/' . $id;
                    } else {
                        $this->log(print ('Uploading Error in File'));
                    }
                } else {
                    $pp['Page']['thumb'] = $Page['Page']['thumb'];
                    $redirectionUrl = '/admin/Page/edit/' . $id . '/?result=done';
                }

                if ($this->Page->save($pp['Page'])) {
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

                    foreach ($pagetext as $data) {
                        $this->Pagetext->id = $data['Pagetext']['id'];
                        $this->Pagetext->data['title'] = $this->data['Pagetext']['title_' . $data['Pagetext']['local']];
                        $this->Pagetext->data['desc'] = $this->data['Pagetext']['desc_' . $data['Pagetext']['local']];
                        $this->Pagetext->data['content'] = $this->removelines($this->data['Pagetext']['content_' . $data['Pagetext']['local']]);
                        $this->Pagetext->data['tags'] = $this->data['Pagetext']['tags_' . $data['Pagetext']['local']];

                        $this->Pagetext->save($this->Pagetext->data, false, array('title', 'desc', 'content', 'tags'));
                    }

                    $this->redirect($redirectionUrl);
                }
            } else
                $this->render();
        }
        else {
            $this->Page->data = $this->Page;
        }
    }

    function removelines($output) {

        $output = str_replace(array("\r\n", "\r", "\n", "\t"), "", $output);
        $output =  str_replace('"', "", $output);
        $output = str_replace("'", "", $output);
        /*
          $lines = explode("\n", $output);
          $new_lines = array();

          foreach ($lines as $i => $line) {
          if(!empty($line))
          $new_lines[] = trim($line);
          }
         */
        return ($output);
    }

    public function admin_delete($id) {
        $this->Auth->AuthAdmin($this, 'page', 'delete');

        $cond = "`Page`.`id` = '$id'";
        $fields = array('thumb');
        $Page = $this->Page->getPage($cond, $fields);
        if (!is_array($Page)) {
            $this->redirect('/admin/page');
            die();
        }

        if ($this->Page->delete($id)) {
            $path = WWW_ROOT . 'upload' . DS . 'pages' . DS;
            $path_thum = $path . 'thum' . DS;
            $path_thum_small = $path . 'small' . DS;

            @unlink($path . $Page['Page']['thumb']);
            @unlink($path_thum . $Page['Page']['thumb']);
            @unlink($path_thum_small . $Page['Page']['thumb']);

            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

            $pagetext = $this->Pagetext->find('all', array('conditions' => "`Pagetext`.`page_id` = '$id'"));

            foreach ($pagetext as $data) {
                $this->Pagetext->delete($data['Pagetext']['id']);
            }

            $this->redirect('/admin/page/index');
        }
    }

    public function admin_deletepage($id) {
        $this->Auth->AuthAdmin($this, 'page', 'delete');
        $this->Gui->layout('blank');

        $cond = "`Page`.`id` = '$id'";
        $fields = array('thumb');
        $Page = $this->Page->getPage($cond, $fields);

        if ($this->Page->delete($id)) {
            $path = WWW_ROOT . 'upload' . DS . 'pages' . DS;
            $path_thum = $path . 'thum' . DS;
            $path_thum_small = $path . 'small' . DS;

            @unlink($path . $Page['Page']['thumb']);
            @unlink($path_thum . $Page['Page']['thumb']);
            @unlink($path_thum_small . $Page['Page']['thumb']);
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
            $pagetext = $this->Pagetext->find('all', array('conditions' => "`Pagetext`.`page_id` = '$id'"));
            foreach ($pagetext as $data) {
                $this->Pagetext->delete($data['Pagetext']['id']);
            }
        }
    }

    function admin_active($id) {
        $this->Auth->AuthAdmin($this, 'page', 'update');

        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }
        $cond = "`Page`.`id` = '$id'";
        $data = $this->Page->getPage($cond);
        $data['Page']['id'] = $data['Page']['id'];
        $data['Page']['active'] = $data['Page']['active'] * -1;
        if ($this->Page->save($data, false, array('active'))) {
            $this->redirect('/admin/page/index/');
        }
    }

    public function ws_page() {
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        App::uses('Sanitize', 'Utility');
        $url = Sanitize::escape($_POST['url']);
        if (empty($url)) {
            $this->set('message', 'PAGE_URL_REQUIRED');
            return;
        }
        $local = @$_POST['local'];
        if (empty($local)) {
            $local = 'ara';
        }
        $cond = "`Pagetext`.`local` = '$local' AND `Page`.`url` = '" . $url . "' AND `Page`.`active` = '1'";
        $Page = $this->Pagetext->getPage($cond);
        if (!empty($Page)) {
            $this->set('result', $Page);
        } else {
            $this->set('message', 'DATA_NOT_FOUND');
            return;
        }
    }

    public function beforeRender() {
        $this->Gui->DoGUIvar($this);
    }

}
