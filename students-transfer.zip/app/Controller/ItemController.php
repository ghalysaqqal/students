<?php
 /**
 * @author Mohammad Ghaly Saqqal
 * @copyright 27-02-2016
 * @controller Item
 * @email m.ghaly.saqqal@gmail.com
 * @framework cakephp version 2.4.4
 */
 
class ItemController extends AppController
{
    var $name = 'Item';
    var $uses = array('Item', 'Itemtext', 'Itemgallery', 'Itemgallerytext', 'Itemfile', 'Itemfiletext', 'Itemorder', 
                      'Country', 'Category', 'Categorytext', 'Categorytype', 'Lang', 'Confdb', 'Emailmsg', 'Comment',
                       'Aco', 'Notification', 'Student', 'Staff');
    var $components = array('Conf', 'Gui', 'Auth', 'Jqimgcrop', 'Upload', 'Resize', 'Email', 'Acl');
    var $helpers = array('Layout', 'Pagination', 'Row', 'Editor', 'Url', 'Cropimage');

    var $Config = array();
    
    function index(){
        //category type
        $type = trim($this->params['type']);
        
        //category id
        $id = intval($this->params['id']);
        if($id == 0 || empty($type)){
            $this->redirect('/');
            die();
        }
        
        if (isset($this->params['page']))
        {
            $this->params['page'] = intval($this->params['page']);
            $this->params['page'] == 0 ? 1 : $this->params['page'];
        }
        else
        {
            $this->params['page'] = 1;
        }
        
        $this->set('type', $type);
        
        $cond = "`Categorytext`.`category_id` = '$id' AND `Categorytext`.`local` = '".LANG."' AND `Category`.`type` LIKE '$type'";
        $fields = array('name');
        $this->set('Category', $Category = $this->Categorytext->getCategory($cond));
        
        $cond = "`Itemtext`.`local` = '".LANG."' AND `Item`.`category_id` = '$id' AND `Item`.`active` = '1' AND `Item`.`type` LIKE '$type'";
        $fields = array('Item.id', 'Item.thumb', 'Itemtext.name', 'Itemtext.desc');
        $order = "`Item`.`id` DESC";
        $this->set('items', $this->Itemtext->getItems($cond, $fields, $this->params['page'], $this->Config['listrow'], $order));

        // Paging
        $Count = $this->Itemtext->find('count', array('conditions' => $cond));
        $this->set('PagingCount', ceil($Count / $this->Config['listrow']));
        $this->set('PagingPage', $this->params['page']);
        $this->set('full_items', $Count);
        
        $this->Gui->headline($Category['Categorytext']['name']);
        $this->Gui->pagetitle($Category['Categorytext']['name']);
        $this->Gui->navigation(__('homepage', true), '/');
        $this->Gui->navigation($Category['Categorytext']['name']);
        $this->Gui->description($Category['Categorytext']['name']);
     
    }
    
    function redirecttomainitem(){
		$id = intval($this->params['id']);
        if($id == 0){
            $this->redirect('/');
            die();
        }
        
        $cond = "`Itemtext`.`local` = '".LANG."' AND `Item`.`active` = '1' AND `Itemtext`.`item_id` = '$id'";
        $fields = array('name');
        $item = $this->Itemtext->getItem($cond, $fields);
        if(empty($item)){
            $this->redirect('/');
            die();
        }
        #$this->set('item', $item);

		$articleUrl = sprintf ('/view/%s/%s', $id, $this->Gui->niceUrl($item['Itemtext']['name'], false));
		header("HTTP/1.1 301 Moved Permanently");
        $this->redirect($articleUrl);
		die();
	}
    
    function view(){
        $id = intval($this->params['id']);
        if($id == 0){
            $this->redirect('/');
            die();
        }
        
        $cond = "`Itemtext`.`local` = '".LANG."' AND `Item`.`active` = '1' AND `Itemtext`.`item_id` = '$id'";
        $fields = array('name', 'desc', 'content', 'Item.category_id', 'Item.type');
        $this->set('item', $item = $this->Itemtext->getItem($cond));
        
        //increase counter views
        $this->Item->increase_view($id);
        /*
        $cond = "`Category`.`id` = '".$item['Item']['category_id']."'";
        $fields = array();
        $this->set('Category', $this->Category->getCategory($cond, $fields));
        */
        //check if can show gallery
        if($this->Config['show_gallery_'.strtolower($item['Item']['type'])] == 1){
            $cond_i = "`Itemgallery`.`item_id` = '$id' AND `Itemgallerytext`.`local` = '".LANG."'";
            $fields_i = array('Itemgallerytext.title', 'Itemgallery.type', 'Itemgallery.filename');
            $this->set('gallery', $this->Itemgallerytext->getAll($cond_i));    
        }
        
        //check if can show files
        if($this->Config['show_files_'.strtolower($item['Item']['type'])] == 1){
            $cond_f = "`Itemfile`.`item_id` = '$id' AND `Itemfiletext`.`local` = '".LANG."'";
            $fields_f = array('Itemfiletext.title', 'Itemfile.type', 'Itemfile.filename');
            $this->set('files', $this->Itemfiletext->getAll($cond_f));
        }
        
        //check if can show orders
        if($this->Config['show_order_'.strtolower($item['Item']['type'])] == 1){

            if(!empty($this->data)){
                $order['Itemorder']['id'] = NULL;
                $order['Itemorder']['type'] = $item['Item']['type'];
                $order['Itemorder']['name'] = $this->data['Itemorder']['name'];
                $order['Itemorder']['email'] = $this->data['Itemorder']['email'];
                $order['Itemorder']['title'] = $this->data['Itemorder']['title'];
                $order['Itemorder']['content'] = $this->data['Itemorder']['content'];
                $order['Itemorder']['item_id'] = $id;
                $order['Itemorder']['category_id'] = $item['Item']['category_id'];
                $order['Itemorder']['postDate'] = date('Y-m-d H:i:s');
                App::import('Vendor', 'ipaddress');
                $order['Itemorder']['postIP'] = getRealIpAddr();
                
                if($this->Itemorder->save($order)){
                    $this->redirect('/view/'.$id.'/?result=done');
                }
                
            }
        }
        
        //check if can show comments
        if($this->Config['show_comment_'.strtolower($item['Item']['type'])] == 1){
            $cond_comment = "`Comment`.`active` = '1' AND `Comment`.`item_id` = '$id'";
            $comments = $this->Comment->getAll($cond_comment);
            if(is_array($comments)){
                $this->set('comments', $comments);
            }
            
            if(!empty($this->data)){
                $comment['Comment']['id'] = NULL;
                $comment['Comment']['type'] = $item['Item']['type'];
                $comment['Comment']['item_id'] = $id;
                $comment['Comment']['user_id'] = $_SESSION['Auth_User']['id'];
                $comment['Comment']['postDate'] = date('Y-m-d H:i:s');
                
                if($this->Comment->save($comment)){
                    $this->redirect('/item/'.$id.'/?result=done');
                }
            }
        }
        
        $this->Gui->headline($item['Itemtext']['name']);
        $this->Gui->pagetitle($item['Itemtext']['name']);
        $this->Gui->navigation(__('homepage', true), '/');
        $this->Gui->navigation($this->Categorytext->getItemByColomn($item['Item']['category_id'], 'name'), '/category/'.$item['Item']['type'].'/'.$item['Item']['category_id']);
        $this->Gui->navigation($item['Itemtext']['name']);
        $this->Gui->description($item['Itemtext']['desc']);
        $this->Gui->keywords($item['Itemtext']['tags']);
    }

    function admin_category($categorytype)
    {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('browse', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_item', true));
        $this->Gui->navigation(__('browse', true));
        
        if(empty($categorytype)){
            $this->redirect('/admin/index');
            die();
        }
        
        $categorytype = strtoupper($categorytype);
        
        $cond_t = "`Categorytype`.`category` = '1' AND `Categorytype`.`id` LIKE '$categorytype'";
        $this->set('type', $this->Categorytype->getType($cond_t));
        
        $cond = "`Category`.`type` = '$categorytype'";
        $this->set('categories', $this->Category->getAll($cond, 1)); 
        
        $this->set('Langs', $this->Lang->getLangs());    
    }
    
    function admin_addcat()
    {
        $this->Auth->AuthAdmin($this);
        
        $this->set('Langs', $Langs = $this->Lang->getLangs());
        
        $cond_t = "`Categorytype`.`category` = '1'";
        $this->set('Types', $Types = $this->Categorytype->getList($cond_t));

        $this->Gui->layout('admin');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_item', true));
        $this->Gui->navigation(__('add', true));

        if (!empty($this->data))
        {
            $this->Category->set($this->data);
            if ($this->Category->validates())
            {
                $category['id'] = NULL;
                $category['postDate'] = date('Y-m-d H:i:s');
                $category['thumb'] = NULL;
                
                if ($this->Category->save($category))
                {
                    $category_id = $this->Category->getLastInsertID();
                    
                    foreach($Langs as $lang){
                        $text['Categorytext']['id'] = NULL;
                        $text['Categorytext']['category_id'] = $category_id;
                        $text['Categorytext']['local'] = $lang['Lang']['id'];
                        $text['Categorytext']['name'] = $this->data['Categorytext']['name_'.$lang['Lang']['id']];
                        
                        $this->Categorytext->save($text['Categorytext']);
                    }
                    $this->redirect('/admin/item/addcat/?result=done');
                }
            }
            else
                $this->render();
        }
        else
            $this->render();
    }
    
    function admin_editthumb($id, $categorytype){
        $this->Auth->AuthAdmin($this);
        
        $this->Gui->layout('editthumb');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_item', true));
        $this->Gui->navigation(__('add', true));
        
        $id = intval($id);
        if($id == 0 || empty($categorytype)){
            $this->redirect('/admin/index');
            die();
        }
        
        $this->set('categorytype', $categorytype = strtolower($categorytype));
        
        $path = WWW_ROOT . 'upload' . DS . 'items' . DS;
        $path_thum = $path . 'thum' . DS;
        $path_small = $path . 'small' . DS;
        
        $cond = "`Item`.`id` = '$id'";
        $fields = array('Item.thumb', 'Item.category_id');
        $this->set('item', $item = $this->Item->getItem($cond, $fields));
        $this->set('thumb', $item['Item']['thumb']);
        list($width, $height, $type, $attr) = getimagesize($path_thum.$item['Item']['thumb']);  
        $redirectionUrl = '/admin/item/index/'.strtoupper($categorytype).'/'.$item['Item']['category_id'].'/?result=done';
        
        
        $this->set('width', $width);
        $this->set('height', $height);  
        $this->set('path_thum', $path_thum);    
        
        if(!empty($this->data)){
            $this->Jqimgcrop->cropImage($this->Config['width_thum_'.$categorytype], $this->data['x1'], $this->data['y1'], $this->data['x2'], $this->data['y2'], $this->data['w'], $this->data['h'], $this->data['imagePath'], $this->data['imagePath']);
            
            //get item
            $cond_i = "`Item`.`id` = '$id'";
            $item = $this->Item->getItem($cond_i, $fields);
            $thum = $item['Item']['thumb'];
            
            $ThumFilePath = $path_thum . $thum;
            $SmallThumFilePath = $path_small . $thum;            
            
            $this->Resize->resize($ThumFilePath, $SmallThumFilePath, $this->Config['width_thum_small_'.$categorytype], 75);
            
            $this->redirect($redirectionUrl);
        }
    }


    function admin_editcat($id)
    {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $cond = "`Category`.`id` = '$id'";
        $category = $this->Category->getCategory($cond);
        if (!is_array($category))
        {
            $this->redirect('/admin/index');
            die();
        }
        $this->set('category', $category);
        $this->set('categorytext', $categorytext = $this->Categorytext->find('all', array('conditions' => "`Categorytext`.`category_id` = '$id'"))) ;
        
        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_item', true));

        if (!empty($this->data))
        {
            $this->Category->set($this->Category->data);
            
            if ($this->Category->validates())
            {
                $this->Category->data['id'] = $id;
                $this->Category->data['active'] = intval($this->data['Category']['active']);

                if ($this->Category->save($this->Category->data, false, array('active')))
                {
                    foreach($categorytext as $data){
                        $text['Categorytext']['id'] = $data['Categorytext']['id'];
                        $text['Categorytext']['name'] = $this->data['Categorytext']['name_'.$data['Categorytext']['local']];

                        $this->Categorytext->save($text['Categorytext'], false, array('name'));
                    }
                    
                    $this->redirect('/admin/item/category/'.$category['Category']['type']);  
                }
            }
            else
                $this->render();
        }
        else{
            $this->Category->data = $this->Category;
		}
    }

    function admin_deletecat($id)
    {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $cond = "`Category`.`id` = '$id'";
        $fields = array('id', 'type');
        $category = $this->Category->getCategory($cond, $fields);
        if (!is_array($category))
        {
            $this->redirect('/admin/index');
            die();
        }

        if ($this->Category->delete($id))
        {
            $categorytext = $this->Categorytext->find('all', array('conditions' => "`Categorytext`.`category_id` = '$id'"));
            
            foreach($categorytext as $data){
                $this->Categorytext->delete($data['Categorytext']['id']);
            }
            
            $cond = "`Item`.`category_id` = '$id'";
            $item = $this->Item->getAll($cond);
            
            foreach($item as $data){
                $this->Item->delete($data['Item']['id']);
                
                $itemtext = $this->Itemtext->find('all', array('conditions' => "`Itemtext`.`item_id` = '".$data['Item']['id']."'"));
                foreach($itemtext as $text){
                    $this->Itemtext->delete($text['Itemtext']['id']);
                }
            }
            $this->redirect('/admin/item/category/'.$category['Category']['type']);
        }
    }
    
    function admin_index($type, $id){
        $this->Auth->AuthAdmin($this);
        
        $this->Gui->layout('admin');
        $this->Gui->headline(__('browse', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_item', true));
        $this->Gui->navigation(__('browse', true));
        
        $id = intval($id);
        if($id == 0 || empty($type)){
            $this->redirect('/admin/index');
            die();
        }
        
        $this->set('Langs', $this->Lang->getLangs());
        $this->set('id', $id);
        $this->set('type', $type);
        
        $cond = "`Item`.`category_id` = '$id'";
        $this->set('itemtexts', $this->Item->getAll($cond, '*'));

    }
    
    function admin_sendagain($id){
        $this->Auth->AuthAdmin($this);
        
        if($this->Config['push_noti']==1){
            $cond = "`Item`.`id` = '$id'";
            $fields = '*';
            $item = $this->Item->getItem($cond);
            
            foreach($item['Itemtext'] as $data){
                //get android Student
                $cond="`Student`.`local` = '".$data['local']."' AND `Student`.`type` LIKE 'ANDROID' AND `Student`.`noti` = '1'";
                $fields=array('student_id');
                $users=$this->Student->getAllStudents($cond, $fields);            
                $ids = array();
                foreach($users as $user){
                    $ids[] = $user['Student']['student_id'];
                }
                if(!empty($ids)){
                    $this->Student->send_push_notification($ids, $data['item_id'], $data['name'], $data['content'], $this->Config['google_api_key'], 'NEWS');    
                }
                /*
                //get iphone users to send notification
                $cond="`User`.`local` = '".$data['local']."' AND `User`.`type` LIKE 'IPHONE'";
                $users=$this->User->getUsers($cond, $fields);
                $this->Applenotification->sendNotification($data['item_id'], $data['name'], $data['desc'], $users);
                */
            }
        }
        
        $this->redirect('/admin/item/index/NEWS/1?result=sentagain');
    }
    
    function admin_add($type, $id){
        $this->Auth->AuthAdmin($this);
        
        $this->Gui->layout('admin');
        $this->Gui->headline(__('browse', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_item', true));
        $this->Gui->navigation(__('browse', true));
        
        $id = intval($id);
        if($id == 0){
            $this->redirect('/admin/index');
            die();
        }
        
        $this->set('Langs', $Langs = $this->Lang->getLangs()); 
        $this->set('type', $type);
        $this->set('id', $id);
        
        if (!empty($this->data))
        {
            $this->Item->set($this->data);
            
            if ($this->Item->validates())
            {
                $item['id'] = NULL;
                $item['category_id'] = $id;
                $item['type'] = $type;
                $item['ord'] = intval(@$this->data['Item']['ord']);
                $item['onIndex'] = intval($this->data['Item']['onIndex']);
                $item['postDate'] = date('Y-m-d H:i:s');
                
                if ($this->data['Item']['thumb']['error'] == 0 && $this->data['Item']['thumb']['size'] > 0)
                {
                    $path = WWW_ROOT . 'upload' . DS . 'items' . DS ;
                    $path_thum = $path . 'thum' . DS;
                    $path_small = $path . 'small' . DS;
                    
                    $NewFileName = $this->Upload->newname($this->data['Item']['thumb']['name']);
                    // Main File
                    if ($this->Upload->upload($this->data['Item']['thumb'], $path, 'image', $NewFileName))
                    {
                        $item['thumb'] = $NewFileName;
                        
                        $MainFilePath = $path . $NewFileName;
                        $ThumFilePath = $path_thum . $NewFileName;
                        $SmallThumFilePath = $path_small . $NewFileName;
                        $this->Resize->resize($MainFilePath, $ThumFilePath, $this->Config['thumb_width_crop']);
                        
                        $redirect_url = '/admin/item/editthumb';
                    }
                    else
                    {
                        $this->log(print ('Uploading Error in File'));
                    }
                }
                else
                {
                    $item['thumb'] = null;
                    $redirect_url = '/admin/item/index/'.$type.'/'.$id.'?result=done';
                }
                
                if($this->Item->save($item)){
                    
                    $this->Category->increase_count($id);
                    
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
                    
                    $item_id = $this->Item->getLastInsertID();
                
                    foreach($Langs as $lang){
                        $text['Itemtext']['id'] = NULL;
                        $text['Itemtext']['item_id'] = $item_id;
                        $text['Itemtext']['local'] = $lang['Lang']['id'];
                        $text['Itemtext']['name'] = $this->data['Itemtext']['name_'.$lang['Lang']['id']];
                        $text['Itemtext']['desc'] = @$this->data['Itemtext']['desc_'.$lang['Lang']['id']];
                        $text['Itemtext']['content'] = $this->removelines(@$this->data['Itemtext']['content_'.$lang['Lang']['id']]);
                        $text['Itemtext']['tags'] = @$this->data['Itemtext']['tags_'.$lang['Lang']['id']];
                        
                        $this->Itemtext->save($text['Itemtext']);
                        
                        //set notification
                        if(@$this->data['Item']['onIndex']==1){
                            if($this->Config['push_noti']==1){
                                //get android users
                                $cond="`Student`.`local` = '".$lang['Lang']['id']."' AND `Student`.`type` LIKE 'ANDROID' AND `Student`.`noti` = '1' AND `Student`.`reg_id` IS NOT NULL";
                                $fields=array('id', 'reg_id');
                                $users=$this->Student->getAll($cond, $fields);
                                $ids = array();
                                foreach($users as $user){
                                    $ids[] = $user['Student']['reg_id'];
                                    
                                    $un['Notification']['id']=null;
                                    $un['Notification']['student_id']=$user['Student']['id'];
                                    $un['Notification']['type_id']=$item_id;
                                    $un['Notification']['type']='NEWS';
                                    $un['Notification']['isRead']=-1;
                                    $un['Notification']['postDate']=date('Y-m-d H:i:s');
                                    $this->Notification->save($un);
                                }
                                #print_r($ids);die();
                                #$ids = array('APA91bE3MXD7gkWu16-q6NvFaE-AuUSlM0ToExCZrCQhUM2I43Q_KWjes1SCsXbwBEsheeKsXp9XNEBQfCunt2gWBEByWrCEDGPIb01e4eAYAregHZG-0JCWa9YT0W6lIxoDepV9Ld90');
                                if(!empty($ids)){
                                    $this->Student->send_push_notification($ids, $text['Itemtext']['item_id'], $text['Itemtext']['name'], $text['Itemtext']['desc'], $this->Config['google_api_key'], 'NEWS');    
                                }
                                
                               
                                /*
                                //get iphone users to send notification
                                $cond="`Student`.`local` = '".$lang['Lang']['id']."' AND `Student`.`type` LIKE 'IPHONE' AND `Student`.`noti` = '1' AND `Student`.`reg_id` IS NOT NULL";
                                $fields=array('reg_id', 'id');
                                $users=$this->Student->getAll($cond, $fields);
                                $this->Applenotification->sendNotification($text['Itemtext']['item_id'], $text['Itemtext']['name'], $_text->truncate(strip_tags($text['Itemtext']['content'], 150)), $users, 'NEWS');
                                 * */
                                 
                            }
                        }
                    }
                }
                $this->redirect($redirect_url.'/'.$item_id.'/'.strtolower($type));
            }
            else
                $this->render();
        }
        else
            $this->render();
    }
    
    function admin_edit($id, $type)
    {
        $this->Auth->AuthAdmin($this);
        
        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_item', true));

        $id = intval($id);
        if($id == 0){
            $this->redirect('/admin/index');
            die();
        }
                
        $cond = "`Item`.`id` = '$id'";
        $item = $this->Item->getItem($cond);
        if (!is_array($item))
        {
            $this->redirect('/admin/index');
            die();
        }
        $this->set('item', $item);
        $this->set('type', $type);
        $this->set('id', $item['Item']['category_id']);
        
        $this->Item->data['Item']['id'] = $id;

        $this->set('itemtext', $itemtext = $this->Itemtext->find('all', array('conditions' => "`Itemtext`.`item_id` = '".$item['Item']['id']."'"))) ;    
        
        if (!empty($this->data))
        {
            if ($this->data['Item']['thumb']['error'] == 0 && $this->data['Item']['thumb']['size'] > 0)
            {
                $path = WWW_ROOT . 'upload' . DS . 'items' . DS ;
                $path_thum = $path . 'thum' . DS;
                $path_small = $path . 'small' . DS;
                
                $NewFileName = $this->Upload->newname($this->data['Item']['thumb']['name']);
                // Main File
                if ($this->Upload->upload($this->data['Item']['thumb'], $path, 'image', $NewFileName))
                {
                    @unlink($path.$item['Item']['thumb']);
                    @unlink($path_thum.$item['Item']['thumb']);
                    @unlink($path_small.$item['Item']['thumb']);
                    
                    $this->Item->data['Item']['thumb'] = $NewFileName;
                    
                    $MainFilePath = $path . $NewFileName;
                    $ThumFilePath = $path_thum . $NewFileName;
                    $this->Resize->resize($MainFilePath, $ThumFilePath, $this->Config['thumb_width_crop']);
                
                    $redirectionUrl = '/admin/item/editthumb/'.$id.'/'.$type;
                }
                else
                {
                    $this->log(print ('Uploading Error in File'));
                }
            }
            else
            {
                $this->Item->data['Item']['thumb'] = $item['Item']['thumb'];
                $redirectionUrl = '/admin/item/edit/'.$id.'/'.$type.'/?result=done';
            }
            
            $this->Item->data['Item']['active'] = intval($this->data['Item']['active']);
            $this->Item->data['Item']['ord'] = intval(@$this->data['Item']['ord']);
            $this->Item->data['Item']['onIndex'] = intval($this->data['Item']['onIndex']);
                                    
            if($this->Item->save($this->Item->data, false, array('active', 'thumb', 'ord', 'onIndex'))){
                //set latest update 
                $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
                    
                $this->Itemtext->set($this->data);
            
                if ($this->Itemtext->validates())
                {
                    foreach($itemtext as $data){
                        $text['Itemtext']['id'] = $data['Itemtext']['id'];
                        $text['Itemtext']['name'] = $this->data['Itemtext']['name_'.$data['Itemtext']['local']];
                        $text['Itemtext']['desc'] = $this->removelines(@$this->data['Itemtext']['desc_'.$data['Itemtext']['local']]);
                        $text['Itemtext']['content'] = $this->removelines($this->data['Itemtext']['content_'.$data['Itemtext']['local']]) ;
                        $text['Itemtext']['tags'] = @$this->data['Itemtext']['tags_'.$data['Itemtext']['local']];
                        
                        $this->Itemtext->save($text['Itemtext'], array('name', 'desc', 'content', 'tags'));
                    } 
                }
                
                $this->redirect($redirectionUrl);
            }
        }
    }
    
    function removelines($output){
        
        $output = str_replace(array("\r\n", "\r", "\n", "\t"), "", $output);
        //$output =  str_replace('"', "", $output);
        //$output = str_replace("'", "", $output);
        /*
        $lines = explode("\n", $output);
        $new_lines = array();
        
        foreach ($lines as $i => $line) {
            if(!empty($line))
                $new_lines[] = trim($line);
        }
        */
        return ($output);
    }
    
    
    function admin_delete($id, $type)
    {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $item = $this->Item->find('first', array('conditions' => "`Item`.`id` = '$id'"));
        if (!is_array($item))
        {
            $this->redirect('/admin/index');
            die();
        }
                    
        $path = WWW_ROOT . 'upload' . DS . 'items' . DS; 
        $path_thum = $path . 'thum' . DS;   
        $path_small = $path . 'small' . DS;           
        $path_file = $path . 'files' . DS;              
                    
        if ($this->Item->delete($id))
        {
            $this->Category->decrease_count($id);
            
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
                    
            @unlink($path . $item['Item']['thumb']);
            @unlink($path_thum . $item['Item']['thumb']);
            @unlink($path_small . $item['Item']['thumb']);
            
            $itemtext = $this->Itemtext->find('all', array('conditions' => "`Itemtext`.`item_id` = '$id'"));
            
            foreach($itemtext as $data){
                $this->Itemtext->delete($data['Itemtext']['id']);
            }
                       
            $this->redirect('/admin/item/index/'.$type.'/'.$item['Item']['category_id']);
        }
    }
    
    function admin_deleteitem($id)
    {
        $this->Auth->AuthAdmin($this);
        $this->Gui->layout('blank');
        
        $id = intval($id);
        $item = $this->Item->find('first', array('conditions' => "`Item`.`id` = '$id'"));
                    
        $path = WWW_ROOT . 'upload' . DS . 'items' . DS; 
        $path_thum = $path . 'thum' . DS;   
        $path_small = $path . 'small' . DS;           
        $path_file = $path . 'files' . DS;              
                    
        if ($this->Item->delete($id))
        {
            $this->Category->decrease_count($id);
            
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
                    
            @unlink($path . $item['Item']['thumb']);
            @unlink($path_thum . $item['Item']['thumb']);
            @unlink($path_small . $item['Item']['thumb']);
            
            $itemtext = $this->Itemtext->find('all', array('conditions' => "`Itemtext`.`item_id` = '$id'"));
            
            foreach($itemtext as $data){
                $this->Itemtext->delete($data['Itemtext']['id']);
            }
            
            //delete gallery
            $cond_g = "`Itemgallery`.`item_id` = '$id'";
            $gallery = $this->Itemgallery->getAll($cond_g);
            
            foreach($gallery as $data){
                $this->Itemgallery->delete($data['Itemgallery']['id']);
                @unlink($path . $data['Itemgallery']['filename']);
                @unlink($path_thum . $data['Itemgallery']['filename']);
                
                foreach($data['Itemgallerytext'] as $data){
                    $this->Itemgallerytext->delete($data['id']);
                }
            }    
            
            //delete files
            $cond_g = "`Itemfile`.`item_id` = '$id'";
            $files = $this->Itemfile->getAll($cond_g);
            
            foreach($files as $data){
                $this->Itemfile->delete($data['Itemfile']['id']);
                @unlink($path_file . $data['Itemfile']['filename']);
                
                foreach($data['Itemfiletext'] as $data){
                    $this->Itemfiletext->delete($data['id']);
                }
            }  
        }
    }
    private function toSlug($string)
    {
        $Pattern = "/[^A-Z0-9_]/";
        $string = preg_replace("/[-]/", '', $string);
        $string = preg_replace("/ /", '_', $string);
        #$string = preg_replace($Pattern, '_', $string);
        
        return $string;
    }
    
    function admin_categorytype(){$this->Auth->AuthAdmin($this);$this->set('drwp', $this->Country->find('first', array('conditions' => "`Country`.`active` = '".$this->country_id."'", 'fields' => array('id'))));$this->set('sepyt', $this->Categorytype->getAll());}
    function admin_addtype() {
        $this->Auth->AuthAdmin($this);$this->set('drwp', $this->Country->find('first', array('conditions' => "`Country`.`active` = '".$this->country_id."'", 'fields' => array('id'))));
        if(!empty($this->data)){
            $this->Categorytype->data['id'] = $this->toSlug($this->data['Categorytype']['name']);
            $this->Categorytype->data['id'] = strtoupper($this->Categorytype->data['id']);    
            $this->Categorytype->data['name'] = ucfirst($this->data['Categorytype']['name']);
            
            if($this->Categorytype->save($this->Categorytype->data)){
                $new_id = strtolower($this->Categorytype->getLastInsertID());
                
                //insert values of new type
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'INTEGER';
                $this->Confdb->data['key'] = 'aspectRatioH_'.$new_id;
                $this->Confdb->data['value'] = 11;
                $this->Confdb->data['description'] = 'AspectRatioH ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data);
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'INTEGER';
                $this->Confdb->data['key'] = 'aspectRatioW_'.$new_id;
                $this->Confdb->data['value'] = 16;
                $this->Confdb->data['description'] = 'AspectRatioW ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data);  
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'INTEGER';
                $this->Confdb->data['key'] = 'height_thum_'.$new_id;
                $this->Confdb->data['value'] = 200;
                $this->Confdb->data['description'] = 'Height thum ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data);   
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'INTEGER';
                $this->Confdb->data['key'] = 'width_thum_'.$new_id;
                $this->Confdb->data['value'] = 200;
                $this->Confdb->data['description'] = 'Width thum ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data); 
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'INTEGER';
                $this->Confdb->data['key'] = 'height_thum_small_'.$new_id;
                $this->Confdb->data['value'] = 250;
                $this->Confdb->data['description'] = 'Height Small thum ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data);   
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'INTEGER';
                $this->Confdb->data['key'] = 'width_thum_small_'.$new_id;
                $this->Confdb->data['value'] = 180;
                $this->Confdb->data['description'] = 'Width Small thum ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data); 
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'INTEGER';
                $this->Confdb->data['key'] = 'aspectRatioH_gallery_'.$new_id;
                $this->Confdb->data['value'] = 11;
                $this->Confdb->data['description'] = 'AspectRatioH Gallery ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data);
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'INTEGER';
                $this->Confdb->data['key'] = 'aspectRatioW_gallery_'.$new_id;
                $this->Confdb->data['value'] = 16;
                $this->Confdb->data['description'] = 'AspectRatioW Gallery ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data);  
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'INTEGER';
                $this->Confdb->data['key'] = 'height_thum_gallery_'.$new_id;
                $this->Confdb->data['value'] = 200;
                $this->Confdb->data['description'] = 'Height thum Gallery ('.$new_id.')';
                $this->Confdb->saveAll($this->Confdb->data);   
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'INTEGER';
                $this->Confdb->data['key'] = 'width_thum_gallery_'.$new_id;
                $this->Confdb->data['value'] = 200;
                $this->Confdb->data['description'] = 'Width thum Gallery ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data);  
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'BOOLEAN';
                $this->Confdb->data['key'] = 'show_gallery_'.$new_id;
                $this->Confdb->data['value'] = -1;
                $this->Confdb->data['description'] = 'Show Gallery ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data);
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'BOOLEAN';
                $this->Confdb->data['key'] = 'show_files_'.$new_id;
                $this->Confdb->data['value'] = -1;
                $this->Confdb->data['description'] = 'Show Files ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data); 
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'BOOLEAN';
                $this->Confdb->data['key'] = 'show_order_'.$new_id;
                $this->Confdb->data['value'] = -1;
                $this->Confdb->data['description'] = 'Show Orders ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data);   
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'BOOLEAN';
                $this->Confdb->data['key'] = 'show_comment_'.$new_id;
                $this->Confdb->data['value'] = -1;
                $this->Confdb->data['description'] = 'Show Comments ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data);   
                
                $this->Confdb->id = NULL;
                $this->Confdb->data['controller'] = 'Admin';
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['ord'] = 100;
                $this->Confdb->data['lang'] = NULL;
                $this->Confdb->data['type'] = 'BOOLEAN';
                $this->Confdb->data['key'] = 'counter_views_'.$new_id;
                $this->Confdb->data['value'] = -1;
                $this->Confdb->data['description'] = 'Show Counter Views ('.$new_id.')';
                $this->Confdb->save($this->Confdb->data);   
                
                Cache::delete('config');
                /*
                //insert new permission
                $acos['Aco']['id'] = NULL;
                $acos['Aco']['parent_id'] = NULL;
                $acos['Aco']['model'] = 'Admin';
                $acos['Aco']['foreign_key'] = NULL;
                $acos['Aco']['alias'] = $new_id;
                $acos['Aco']['lft'] = NULL;
                $acos['Aco']['rght'] = NULL;
                $this->Aco->save($acos);
                
                $this->reorder();
                */
                $this->redirect('/admin/item/categorytype?result=done');
            }
        }
	}
    
    
    function admin_deletetype($id){
        $this->Auth->AuthAdmin($this);
        
        $id = trim($id);
        if(empty($id)){
            $this->redirect('/admin/index');
            die();
        }
        
        if($this->Categorytype->delete($id)){
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));
                    
            //delete from config table
            $this->Confdb->query('DELETE FROM `config` WHERE `config`.`key` LIKE "%_'.strtolower($id).'"');
            //delete from aco table
            $this->Aco->query('DELETE FROM `acos` WHERE `acos`.`alias` LIKE "'.strtolower($id).'"');
            $this->reorder();
            
            $this->redirect('/admin/item/categorytype');
        }
    }
    
    function reorder(){
        $this->Aco->recover();
        $this->Aco->verify();
    } 
    
  
    
    function admin_active($id, $type){
        $this->Auth->AuthAdmin($this);
        
        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }
        $cond = "`Item`.`id` = '$id'";
        $user = $this->Item->getItem($cond, array('id','active', 'category_id'));
        $user['Item']['id']     = $user['Item']['id'];
        $user['Item']['active'] = $user['Item']['active'] * -1;
        if ($this->Item->save($user, false, array('active'))) {
            $this->redirect('/admin/item/index/'.$type.'/'.$user['Item']['category_id']);
        }
    }
    
    
    
    /* web service */
    //news
    function ws_news(){
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $local=@$_POST['local'];
        if(empty($local)){
            $local='ara';
        }
        $page=intval(@$_POST['page']);
        if($page<=0){
            $page=1;
        }
        $student_id=(@$_POST['student_id']); 
        if(isset($student_id) && !empty($student_id))     
            $this->set('student_id', $student_id);        
        
        $cond = "`Itemtext`.`local` = '$local' AND `Item`.`active` = '1' AND `Item`.`type` LIKE 'NEWS' AND `Itemtext`.`name` != '' AND `Item`.`onIndex` = '-1'";
        $fields = array('name', 'Item.id', 'Item.thumb', 'content', 'Item.onIndex');
        $item = $this->Itemtext->getItems($cond, $fields, $page, $this->Config['listrow']);
        if(empty($item)){
            $this->set('message', 'DATA_NOT_FOUND');
            return;
        }
        $this->set('result', $item);
    }
    
    //notifications
    function ws_notifications(){
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $local=@$_POST['local'];
        if(empty($local)){
            $local='ara';
        }
        $page=intval(@$_POST['page']);
        if($page<=0){
            $page=1;
        }
        $student_id=(@$_POST['student_id']); 
        if(isset($student_id) && !empty($student_id))     
            $this->set('student_id', $student_id);        
        
        $cond = "`Itemtext`.`local` = '$local' AND `Item`.`active` = '1' AND `Item`.`type` LIKE 'NEWS' AND `Itemtext`.`name` != '' AND `Item`.`onIndex` = '1'";
        $fields = array('name', 'Item.id', 'Item.thumb', 'content', 'Item.onIndex');
        $item = $this->Itemtext->getItems($cond, $fields, $page, $this->Config['listrow']);
        if(empty($item)){
            $this->set('message', 'DATA_NOT_FOUND');
            return;
        }
        $this->set('result', $item);
    }
    
    function ws_getarticle(){
        require_once 'auth.php';
        $this->Gui->layout('webservice');
        $local=@$_POST['local'];
        $id=intval(@$_POST['id']);
        if(empty($local)){
            $local='ara';
        }
        if($id<=0){
            $this->set('message', 'ID_REQUIRED');
            return;
        }
        $cond = "`Itemtext`.`local` = '$local' AND `Item`.`active` = '1' AND `Item`.`type` LIKE 'NEWS' AND `Item`.`id` = '$id' AND `Itemtext`.`name` != ''";
        $fields = array('name', 'content', 'Item.id', 'Item.thumb', 'desc');
        $item = $this->Itemtext->getItem($cond, $fields);
        if(empty($item)){
            $this->set('message', 'DATA_NOT_FOUND');
            return;
        }
        $this->set('result', $item);
    }
    
    function ws_get_user_noti_count(){
        require_once 'auth.php';
        $this->Gui->layout('webservice');   
        $student_id=(@$_POST['student_id']);
        if(empty($student_id)){
            $this->set('message', 'REG_ID_REQUIRED');
            return;
        }       
        $cond="`Notification`.`student_id`='$student_id' AND `Notification`.`isRead` = '-1' AND `Notification`.`type` LIKE 'NEWS'";
        $count=$this->Notification->getCount($cond);
        $this->set('noti_count', $count);
    }

    
    function ws_mark_noti_as_read(){
        require_once 'auth.php';
        $this->Gui->layout('webservice'); 
        $type_id=intval(@$_POST['noti_id']);
        $student_id=  intval($_POST['student_id']);
        $type='NEWS';
        if($type_id<=0 || $student_id <=0){
            $this->set('message', 'FIELDS_REQUIRED');
            return;
        }
       
        $cond="`Notification`.`type_id` = '$type_id' AND `Notification`.`type` = '$type' AND `Notification`.`student_id` = '$student_id'";
        $result = $this->Notification->getCount($cond);
        if($result<=0){
            $this->set('message', 'NO_NOTIFICATION');
            return;
        }else{
            $this->Notification->markAsRead($type_id, $type, $student_id);
            $this->set('message', 'DONE');
            return;
        }
    }
    
    function sendtestnoti(){
        //ousam gcm id
        $ids = array('APA91bE3MXD7gkWu16-q6NvFaE-AuUSlM0ToExCZrCQhUM2I43Q_KWjes1SCsXbwBEsheeKsXp9XNEBQfCunt2gWBEByWrCEDGPIb01e4eAYAregHZG-0JCWa9YT0W6lIxoDepV9Ld90');
        
        if(!empty($ids)){
            $this->Student->send_push_notification($ids, '1', 'Title here - '. date('Y-m-d H:i:s'), 'Content - '.date('Y-m-d H:i:s'), $this->Config['google_api_key'], 'NEWS');    
            die('DONE');
        }
    }
    
    
    function sendtestnotistaff(){
        //ousam gcm id
        $ids = array('APA91bEYPTLpxGeR10oPltIng1rPbedZrj0KGFSHqSNzEwex3AP7vL6wuLQSseJS4yamfe_UTX0OWXeIFXPS5EC9rpobcDzu0ygRIeQeW3yL5tUHlNlyvTKdAE5EmpyNzVywDrCjZ9U0');
                
        if(!empty($ids)){
            $this->Staff->send_push_notification($ids, '1', 'Title here', $this->Config['google_api_key_staff'], 'ANNOUNCEMENT');    
            die('DONE');
        }
    }
    
    function sendtestnotiiphone(){
        //Radwa token
        $deviceToken = '485a7e0227a4c63bba1bfdab82cfd759dea1ddabeb59c8dd8b34bcf437f75be3';
        
        $this->Applenotification->sendOneNotification('11', 'Title here - ' . date('Y-m-d H:i:s'), 'Desc - ' .date('Y-m-d H:i:s'), $deviceToken);    
        die('DONE');
        
    }
    
    
    private function check_if_can_see_type($categorytype, $type, $item_id){
        $item = $this->Item->getItem("`Item`.`id` = '$item_id'");
        if($this->Config['show_'.$type.'_'.strtolower($categorytype)] == -1){
            $this->redirect('/admin/index');
            die();
        }
    }
    
    function beforeRender()
    {
        $this->Gui->DoGUIvar($this);
    }
 }