<?php

class ContactusController extends AppController {

    var $name = 'Contactus';
    var $uses = array('Department', 'Departmenttext', 'Request', 'Page', 'Pagetext', 'Emailmsg', 'Complaint', 
                      'Problem', );
    var $components = array('Conf', 'Gui', 'Auth', 'Email', 'Acl', );
    var $helpers = array('Layout', 'Row', 'Url');
    var $Config = array();

    function index() {
        // GUI
        $this->Gui->layout('contacts');
        $this->Gui->pagetitle(__('Contact us', true));
        $this->Gui->headline(__('Contact us', true));
        $this->Gui->navigation(__('homepage', true), '/');
        $this->Gui->navigation(__('Contact us', true));

        $cond_contactus = "`Pagetext`.`local` = '" . LANG . "' AND `Page`.`url` = 'contactus' AND `Page`.`active` = '1'";
        $fields = array('title', 'content');
        $this->set('contactus', $this->Pagetext->getPage($cond_contactus, $fields));

        $departments_enable = $this->Config['departments_enable'];
        if ($departments_enable == 1)
            $this->set('Departments', $this->Departmenttext->getDepartmentsList(LANG));

        if (!empty($this->data)) {
            $recaptcha = $this->data['g-recaptcha-response'];

            $google_url = "https://www.google.com/recaptcha/api/siteverify";
            $secret = $this->Config['google_secret_key'];
            $ip = $_SERVER['REMOTE_ADDR'];
            $url = $google_url . "?secret=" . $secret . "&response=" . $recaptcha . "&remoteip=" . $ip;
            App::import('Vendor', 'curl');
            $res = getCurlData($url);
            $res = json_decode($res, true);

            $errormessage = array();

            if (empty($res['success'])) {
                $errormessage[] = __('Please Check reCAPTCHA', true);
            }

            if (sizeof($errormessage) > 0) {
                $this->set('errormessage', $errormessage);
                $this->render();
            } else {
                if ($departments_enable == 1) {
                    $cond = "`Department`.`id` = '" . $this->data['Request']['cdID'] . "'";
                    $fields = array('email');
                    $dep = $this->Department->getItem($cond, $fields);
                }

                //saving data
                $request['Request']['id'] = NULL;
                $request['Request']['department_id'] = @$this->data['Request']['cdID'];
                $request['Request']['name'] = $this->data['Request']['name'];
                $request['Request']['email'] = $this->data['Request']['email'];
                $request['Request']['mobile'] = $this->data['Request']['mob'];
                $request['Request']['subject'] = $this->data['Request']['subject'];
                $request['Request']['content'] = $this->data['Request']['text'];
                $request['Request']['type'] = 'CONTACTUS';

                $request['Request']['postDate'] = date('Y-m-d H:i:s');
                App::import('Vendor', 'ipaddress');
                $request['Request']['postIP'] = getRealIpAddr();

                $this->Request->save($request);

                $this->Email->from = sprintf('%s <%s>', $this->Config['from'], $this->Config['fromaddress']);
                if ($departments_enable == 1)
                    $this->Email->to = $dep['Department']['email'];
                else
                    $this->Email->to = $this->Config['email_monitor'];
                $this->Email->subject = $this->data['Request']['subject'];
                $this->Email->template = 'sentemail';
                $this->Email->sendAs = 'html';
                //get email msg
                $msg = $this->Emailmsg->getMsg(LANG, 'CONTACTUS');

                $messge = $msg['Emailmsg']['content'];

                $messge = str_replace('$SENDERNAME', $request['Request']['name'], $messge);
                $messge = str_replace('$SENDEREMAIL', $request['Request']['email'], $messge);
                $messge = str_replace('$MSG_CONTENT', $request['Request']['content'], $messge);

                $this->set('msg', $messge);

                if ($this->Email->send()) {
                    $this->redirect('/contactus?result=done');
                }
            }
        }
    }

    function sendemail() {
        $this->Gui->layout('blank');

        $name = $_POST['name'];
        $email = $_POST['email'];
        $message = $_POST['message'];
        $phone = $_POST['phone'];

        if (!empty($name) || !empty($email) || !empty($message)) {

            //saving data
            $request['Request']['id'] = NULL;
            $request['Request']['department_id'] = 0;
            $request['Request']['name'] = $name;
            $request['Request']['email'] = $email;
            $request['Request']['mobile'] = $phone;
            $request['Request']['subject'] = __('New Message', true);
            $request['Request']['content'] = $message;
            $request['Request']['type'] = 'CONTACTUS';

            $request['Request']['postDate'] = date('Y-m-d H:i:s');
            App::import('Vendor', 'ipaddress');
            $request['Request']['postIP'] = getRealIpAddr();

            $this->Request->save($request);

            $this->Email->from = sprintf('%s <%s>', $this->Config['from'], $this->Config['fromaddress']);
            $this->Email->to = $this->Config['email_monitor'];
            $this->Email->subject = __('New Message', true);
            $this->Email->template = 'sentemail';
            $this->Email->sendAs = 'html';
            //get email msg
            $msg = $this->Emailmsg->getMsg(LANG, 'CONTACTUS');

            $messge = $msg['Emailmsg']['content'];

            $messge = str_replace('$SENDERNAME', $name, $messge);
            $messge = str_replace('$SENDEREMAIL', $email, $messge);
            $messge = str_replace('$MSG_CONTENT', $message, $messge);

            $this->set('msg', $messge);

            if ($this->Email->send()) {
                $this->set('msgtype', 'ok');
                $this->set('msg2', __('Your message has been sent successfully', true));
            } else {
                $this->set('msgtype', 'error');
                $this->set('msg2', __('Error in Sending, try again', true));
            }
        } else {
            $this->set('msgtype', 'error');
            $this->set('msg2', __('Error in Sending, try again', true));
        }
    }

    function admin_viewreq($id) {
        $this->Auth->AuthAdmin($this);

        $this->set('Request', $request = $this->Request->getRequest($id));

        $this->Request->id = $request['Request']['id'];
        $this->Request->data['isRead'] = 1;

        $this->Request->save($this->Request->data, false, array('isRead'));

        if (!empty($this->data)) {
            $this->Email->from = sprintf('%s <%s>', $this->Config['from'], $this->Config['fromaddress']);
            $this->Email->to = $request['Request']['email'];
            $this->Email->subject = __('Reply from ' . $this->Config['name_' . LANG], true);
            $this->Email->template = 'sentemail';
            $this->Email->sendAs = 'html';
            //get email msg
            $msg = $this->Emailmsg->getMsg(LANG, 'REPLY_MSG');

            $messge = nl2br($this->data['Request']['content']);

            $this->set('msg', $messge);

            if ($this->Email->send()) {
                $this->redirect('/admin/contactus/viewreq/' . $id . '?result=done');
            }
        }

        $this->Gui->layout('admin');
        $this->Gui->headline(__('View Request', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_contactus', true), '/admin/contactus/');
        $this->Gui->navigation(__('View Request', true));
    }

    function admin_add() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('add', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_contactus', true), '/admin/contactus/');
        $this->Gui->navigation(__('add', true));

        $this->set('Langs', $Langs = $this->Lang->getLangs());

        if (!empty($this->data)) {

            if ($this->Department->validates()) {
                $this->Department->id = null;

                if ($this->Department->save($this->data)) {
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

                    $dept_id = $this->Department->getLastInsertID();

                    foreach ($Langs as $lang) {
                        $text['Departmenttext']['id'] = NULL;
                        $text['Departmenttext']['department_id'] = $dept_id;
                        $text['Departmenttext']['local'] = $lang['Lang']['id'];
                        $text['Departmenttext']['name'] = $this->data['Departmenttext']['name_' . $lang['Lang']['id']];

                        $this->Departmenttext->save($text['Departmenttext']);
                    }

                    $this->redirect('/admin/contactus/index?result=done');
                }
            } else
                $this->render();
        } else
            $this->render();
    }

    function admin_index() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('Browse Departments', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_contactus', true), '/admin/contactus/');
        $this->Gui->navigation(__('Browse Departments', true));

        $this->set('departmenttexts', $this->Department->getAll());
        $this->set('Langs', $this->Lang->getLangs());
    }

    function admin_edit($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $cond = "`Department`.`id` = '$id'";
        $dept = $this->Department->getItem($cond);
        if (!is_array($dept)) {
            $this->redirect('/admin/page');
            die();
        }
        $this->set('dept', $dept);

        $this->set('depttext', $depttext = $this->Departmenttext->find('all', array('conditions' => "`Departmenttext`.`department_id` = '" . $dept['Department']['id'] . "'")));

        $this->Gui->layout('admin');
        $this->Gui->headline(__('edit', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_contactus', true), '/admin/contactus/');

        if (!empty($this->data)) {
            $this->Department->set($this->data);
            if ($this->Department->validates()) {
                $this->Department->id = $id;

                if ($this->Department->save($this->Department->data)) {
                    //set latest update 
                    $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

                    foreach ($depttext as $data) {
                        $this->Departmenttext->id = $data['Departmenttext']['id'];
                        $this->Departmenttext->data['name'] = $this->data['Departmenttext']['name_' . $data['Departmenttext']['local']];

                        $this->Departmenttext->save($this->Departmenttext->data, false, array('name'));
                    }

                    $this->redirect('/admin/contactus/edit/' . $id . '/?result=done');
                }
            } else
                $this->render();
        }
        else {
            $this->Department->data = $this->Department;
        }
    }

    function admin_delete($id) {
        $this->Auth->AuthAdmin($this);

        $id = intval($id);
        $dept = $this->Department->find('first', array('conditions' => "`Department`.`id` = '$id'"));
        if (!is_array($dept)) {
            $this->redirect('/admin/contactus');
            die();
        }

        if ($this->Department->delete($id)) {
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

            $text = $this->Departmenttext->find('all', array('conditions' => "`Departmenttext`.`department_id` = '$id'"));

            foreach ($text as $data) {
                $this->Departmenttext->delete($data['Departmenttext']['id']);
            }

            $this->redirect('/admin/contactus/index');
        }
    }

    function admin_deletecontactus($id) {
        $this->Auth->AuthAdmin($this);
        $this->Gui->layout('blank');

        $id = intval($id);
        $dept = $this->Department->find('first', array('conditions' => "`Department`.`id` = '$id'"));
        if ($this->Department->delete($id)) {
            //set latest update 
            $this->Confdb->update_key_value('latest_update_website', date('Y-m-d H:i:s'));

            $text = $this->Departmenttext->find('all', array('conditions' => "`Departmenttext`.`department_id` = '$id'"));

            foreach ($text as $data) {
                $this->Departmenttext->delete($data['Departmenttext']['id']);
            }
        }
    }

    function admin_requests($page = 1) {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('Requests', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('admincp_manage_contactus', true), '/admin/contactus/');
        $this->Gui->navigation(__('Requests', true));

        $this->set('Requests', $this->Request->find('all', array('page' => $page,
                    'limit' => $this->Config['listrow'],
                    'order' => "`Request`.`id` DESC"
        )));

        // Paging
        $Count = $this->Request->find('count', array('conditions' => NULL));

        $this->set('PagingCount', ceil($Count / $this->Config['listrow']));
        $this->set('PagingPage', $page);
    }

    function admin_deletemsg($ID) {
        $this->Auth->AuthAdmin($this, 'contactus', 'delete');

        $ID = intval($ID);

        $msg = $this->Request->find('first', array('conditions' => "`Request`.`id` = '$ID'"));

        if (empty($msg)) {
            $this->redirect('/admin/index');
            die();
        }

        if ($this->Request->delete($ID)) {
            $this->redirect('/admin/contactus/requests/');
        }
    }

    function admin_active($id) {
        $this->Auth->AuthAdmin($this, 'contactus', 'update');

        $id = intval($id);
        if ($id == 0) {
            $this->redirect('/admin/index');
            die();
        }
        $cond = "`Department`.`id` = '$id'";
        $data = $this->Department->getItem($cond);
        $data['Department']['id'] = $data['Department']['id'];
        $data['Department']['active'] = $data['Department']['active'] * -1;
        if ($this->Department->save($data, false, array('active'))) {
            $this->redirect('/admin/contactus/index/');
        }
    }

    function admin_complaints() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('Complaints', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Complaints', true));

        $this->set('complaints',  $this->Complaint->getComplaints());
    }

    function admin_viewcomplaint($id) {
        $this->Auth->AuthAdmin($this);

        $this->set('Complaint', $request = $this->Complaint->getComplaint($id));

        $this->Complaint->id = $request['Complaint']['id'];
        $this->Complaint->data['isRead'] = 1;
        $this->Complaint->save($this->Complaint->data, false, array('isRead'));

        $this->Gui->layout('admin');
        $this->Gui->headline(__('View Complaint', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('View Complaint', true));
    }

    function admin_deletecomplaint($ID) {
        $this->Auth->AuthAdmin($this, 'contactus', 'delete');

        $ID = intval($ID);
        $msg = $this->Complaint->find('first', array('conditions' => "`Complaint`.`id` = '$ID'"));

        if (empty($msg)) {
            $this->redirect('/admin/index');
            die();
        }

        if ($this->Complaint->delete($ID)) {
            $this->redirect('/admin/complaint/');
        }
    }
    
    function admin_problems() {
        $this->Auth->AuthAdmin($this);

        $this->Gui->layout('admin');
        $this->Gui->headline(__('Problems', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('Problems', true));

        $this->set('problems',  $this->Problem->getProblems());
    }

    function admin_viewproblem($id) {
        $this->Auth->AuthAdmin($this);

        $this->set('problem', $request = $this->Problem->getProblem($id));

        $this->Problem->id = $request['Problem']['id'];
        $this->Problem->data['isRead'] = 1;
        $this->Problem->save($this->Problem->data, false, array('isRead'));

        $this->Gui->layout('admin');
        $this->Gui->headline(__('View Problem', true));
        $this->Gui->navigation(__('admincp_index', true), '/admin/index');
        $this->Gui->navigation(__('View Problem', true));
    }

    function admin_deleteproblem($ID) {
        $this->Auth->AuthAdmin($this);

        $ID = intval($ID);
        $msg = $this->Problem->find('first', array('conditions' => "`Problem`.`id` = '$ID'"));

        if (empty($msg)) {
            $this->redirect('/admin/index');
            die();
        }

        if ($this->Problem->delete($ID)) {
            $this->redirect('/admin/contactus/problems/');
        }
    }

    function beforeRender() {
        $this->Gui->DoGUIvar($this);
    }

}
