<?php

class Servicerate extends AppModel {

    var $name = 'Servicerate';
    var $useTable = 'service_rate';
    var $primaryKey = 'id';
    
    function getRateSum(){
        $cond=null;
        $fields=array('SUM( rate ) AS rate');
        $bus=  $this->getRate($cond, $fields);
        return $bus[0]['rate'];
    }
    
    function getAll($cond = null, $fields = '*') {
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
    }

    function getRate($cond, $fields = null) {
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
    }
    
    function check($student_id){
        $result=  $this->find('count', array('conditions'=>"`Servicerate`.`student_id` = '$student_id'"));
        if($result>0)
            return true;
        else
            return false;
    }

    function updaterate($student_id, $rate_value){
        $this->query("UPDATE `".$this->useTable."` SET  `rate` =  '$rate_value' WHERE  `".$this->useTable."`.`student_id` ='$student_id'");
    }
}
