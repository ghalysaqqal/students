<?php
class Itemgallery extends AppModel {
   var $name = 'Itemgallery';
   var $useTable = 'item_gallery';

   var $primaryKey = 'id';
   
    public $hasMany = array(
        
        'Itemgallerytext' => array(
            'className' => 'Itemgallerytext',
            'foreignKey'   => 'item_gallery_id',
            
        ),
        
   );
   
   
   function getItem($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   function getAll($cond = NULL){
        return $this->find('all', array('conditions' => $cond));
   }
   
   function getYTid($ytURL) {
            $ytvIDlen = 11; // This is the length of YouTube's video IDs
            $idStarts = strpos($ytURL, "?v=");
            if($idStarts === FALSE)
                    $idStarts = strpos($ytURL, "&v=");
            if($idStarts === FALSE)
                    die("YouTube video ID not found. Please double-check your URL.");
            $idStarts +=3;
            $ytvID = substr($ytURL, $idStarts, $ytvIDlen);
            return $ytvID;
    }
   
  
}