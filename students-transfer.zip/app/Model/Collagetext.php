<?php
class Collagetext extends AppModel {
   var $name = 'Collagetext';
   var $useTable = 'collage_text';

   var $primaryKey = 'id';
   
    public $belongsTo = array(
        'Collage' => array(
            'className' => 'Collage',
            'foreignKey'   => 'collage_id',
        ),
   );
   
   function getCollage($cond, $fields = '*'){
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
   }
   
   
   function getAll($cond = NULL, $fields = '*', $order = '`Collagetext`.`collage` ASC') {
        return $this->find('all', array('conditions' => $cond,
                                        'fields' => $fields,
                                        'order' => $order));
   }
   
   function getList($cond = NULL){
        return $this->find('list', array('conditions' => $cond,
                                         'fields' => array('collage_id', 'collage'),
                                         'order' => "`Collagetext`.`id` ASC"
                                         ));
   }
   
   function getValueByKey($key, $value){
        $result = $this->find('first', array('conditions' => "`".$this->name."`.`collage_id` = '$key' AND `".$this->name."`.`local` = '".LANG."'",
                                           'fields' => array($value)
                                           ));
        return $result[$this->name][$value];
   }

}