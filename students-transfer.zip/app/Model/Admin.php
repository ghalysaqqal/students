<?php
class Admin extends AppModel {
   var $name = 'Admin';
   var $useTable = 'admin';

   var $primaryKey = 'adminID';
   
   function changeEmailAdmin($username = 'admin', $email){
        $this->query("UPDATE `admin` SET `email` = '$email' WHERE `admin`.`username` = '$username'")  ;  
   }
   
   function getAdmin($cond){
        return $this->find('first', array('conditions' => $cond));
   }
}