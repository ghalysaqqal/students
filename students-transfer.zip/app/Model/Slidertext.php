<?php
class Slidertext extends AppModel {
   var $name = 'Slidertext';
   var $useTable = 'slider_text';

   var $primaryKey = 'id';
   
    public $belongsTo = array(
        
        'Slider' => array(
            'className' => 'Slider',
            'foreignKey'   => 'slider_id',
            
        ),
        
   );
   
   function getSlider($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   function getAll($cond = NULL, $limit, $fields = '*') {
        return $this->find('all', array('conditions' => $cond,
                                        'limit' => $limit,
                                        'fields' => $fields
                                        ));
   }
   
   function getSliders($lang, $category_id, $page, $limit){
        return $this->find('all', array('conditions' => "`Slidertext`.`local` = '$lang' AND `Slider`.`active` = '1' ",
                                        'limit' => $limit,
                                        'page' => $page,
                                        'fields' => array('Slider.id', 'Slidertext.title'),
                                        'order' => "`Slider`.`id` DESC"));
   }
}