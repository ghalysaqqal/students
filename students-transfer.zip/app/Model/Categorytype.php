<?php
class Categorytype extends AppModel {
   var $name = 'Categorytype';
   var $useTable = 'category_type';

   var $primaryKey = 'id';
   
   
   function getList($cond = NULL){
        return $this->find('list', array('conditions' => $cond,
                                         'fields' => array('id', 'name'),
                                         'order' => "`Categorytype`.`name` ASC"
                                         ));
   }
   
   function getAll(){
        return $this->find('all');
   }
   
   function getType($cond = NULL){
        return $this->find('first', array('conditions' => $cond));
   }

}