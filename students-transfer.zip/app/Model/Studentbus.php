<?php

class Studentbus extends AppModel {

    var $name = 'Studentbus';
    var $useTable = 'student_bus';
    var $primaryKey = 'id';

}
