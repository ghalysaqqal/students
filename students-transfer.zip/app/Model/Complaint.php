<?php
class Complaint extends AppModel {
   var $name = 'Complaint';
   var $useTable = 'complaint';

   var $primaryKey = 'id';
   
   public $belongsTo = array(
        'Student' => array(
            'className' => 'Student',
            'foreignKey'   => 'student_id',
            'fields' => array('name', 'email')
        ), 
   );
   
   function getComplaints(){
       return $this->find('all', array('order' => "`Complaint`.`id` DESC"));
   }
   
   function getComplaint($id){
       return $this->find('first', array('conditions' => "`Complaint`.`id` = '$id'"));
   }
   
   
}