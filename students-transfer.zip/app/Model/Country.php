<?php
class Country extends AppModel {
   var $name = 'Country';
   var $useTable = 'country';

   var $primaryKey = 'id';
   
   public $hasMany = array(
        
        'Countrytext' => array(
            'className' => 'Countrytext',
            'foreignKey'   => 'country_id',
            
        ),

        
   );
   
   
   function getCountry($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   function getAll($cond = NULL){
        return $this->find('all', array('conditions' => $cond));
   }
   
   function getList($cond = NULL){
        return $this->find('list', array('conditions' => $cond));
   }
}
