<?php

class Menu extends AppModel
{
    var $name = 'Menu';
    var $useTable = 'menu';
    var $primaryKey = 'id';

    var $actsAs = array('Tree' => array('parent' => 'parentID', 'left' => 'left', 'right' => 'right'));
    
    public $hasMany = array(
        
        'Menutext' => array(
            'className' => 'Menutext',
            'foreignKey'   => 'menu_id',
            
        ),
        
   );

    function getMenu($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   function getAll($cond = NULL){
        return $this->find('all', array('conditions' => $cond));
   }
    
    function BuildMenuTree($lang)
    {
        $Buff = $this->find('all', array('conditions' => "`Menu`.`lang` = '" . $lang . "' AND `Menu`.`parentID` IS NULL  AND `Menu`.`active` > '0'", 'order' => "`Menu`.`ord` ASC", 'fields' => array('menuID', 'menuTitle', 'menuPath', 'hasChildren')));
        $Level = array();
        foreach ($Buff as $menu)
        {
            $menuID = $menu['Menu']['menuID'];
            $Level[$menuID] = array('title' => $menu['Menu']['menuTitle'], 'url' => $menu['Menu']['menuPath']);
            if ($menu['Menu']['hasChildren'] > 0 && $this->childCount($menuID, true) > 0)
            {
                $Level[$menuID]['hasChildren'] = 1;
                $Level[$menuID]['Children'] = $this->GetChildren($menuID);
            }
        }
        unset($Buff);
        return $Level;
    }

    function GetChildren($menuID)
    {
        $Buff = $this->find('all', array('conditions' => "`Menu`.`parentID` = '$menuID' AND `Menu`.`active` > '0'", 'order' => "`Menu`.`ord` ASC", 'fields' => array('menuID', 'menuTitle', 'menuPath', 'hasChildren')));
        $Level = array();
        foreach ($Buff as $menu)
        {
            $menuID = $menu['Menu']['id'];
            $Level[$menuID] = array('title' => $menu['Menu']['menuTitle'], 'url' => $menu['Menu']['menuPath']);
            if ($menu['Menu']['hasChildren'] > 0 && $this->childCount($menuID, true) > 0)
            {
                $Level[$menuID]['hasChildren'] = 1;
                $Level[$menuID]['Children'] = $this->GetChildren($menuID);
            }
        }
        unset($Buff);
        return $Level;
    }
    
    function GetPathMap($menuID){
        $path = $this->getpath ($menuID);
        return Set::combine($path, '{n}.Menu.id', '{n}.Menu.id');
    }
    
    function GetMenuListTree($lang){
      return $this->generatetreelist ("`Menu`.`lang` = '".$lang."' AND `Menu`.`active` = '1'", "{n}.Menu.menuID", "{n}.Menu.menuTitle", '----');
    }
}