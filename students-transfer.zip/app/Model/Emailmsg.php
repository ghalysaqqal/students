<?php
class Emailmsg extends AppModel {
   var $name = 'Emailmsg';
   var $useTable = 'email_msg';

   var $primaryKey = 'id';
   

   function getMsgs(){
        return $this->find('all');
   }
   
   function getMsg($local, $type){
        return $this->find('first', array('conditions' => "`Emailmsg`.`local` = '$local' AND `Emailmsg`.`type` = '$type'"));
   }
   
}