<?php
class Category extends AppModel {
   var $name = 'Category';
   var $useTable = 'category';

   var $primaryKey = 'id';
   
   public $hasMany = array(
        
        'Categorytext' => array(
            'className' => 'Categorytext',
            'foreignKey'   => 'category_id',
            
        ),
        
        'Item' => array(
            'className' => 'Item',
            'foreignKey'   => 'category_id',
            
        ),
        
   );
   
   
   function getCategory($cond, $fields = '*'){
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields,));
   }
   
   function getAll($cond = NULL, $recursive = 1, $limit = -1, $fields = '*', $order = "`Category`.`type` ASC"){
        return $this->find('all', array('conditions' => $cond,
                                        'limit' => $limit,
                                        'recursive' => $recursive,
                                        'fields' => $fields,
                                        'order' => $order
                                        ));
   }
   
   function increase_count($id){
        $query = sprintf ("update `%s` set `itemCount`=`itemCount`+1 where `id`='%s'", $this->useTable, $id);
	   	$this->query($query);
   }
   
   function decrease_count($id){
        $query = sprintf ("update `%s` set `itemCount`=`itemCount`-1 where `id`='%s'", $this->useTable, $id);
	   	$this->query($query);
   }
}