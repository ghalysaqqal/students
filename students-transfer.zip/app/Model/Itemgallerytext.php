<?php
class Itemgallerytext extends AppModel {
   var $name = 'Itemgallerytext';
   var $useTable = 'item_gallery_text';

   var $primaryKey = 'id';
   
    public $belongsTo = array(
        
        'Itemgallery' => array(
            'className' => 'Itemgallery',
            'foreignKey'   => 'item_gallery_id',
            
        ),
        
   );
   
   function getItem($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   function getAll($cond = NULL, $fields = '*'){
        return $this->find('all', array('conditions' => $cond,
                                        'fields' => $fields
                                        ));
   }
   
    function get_items($cond = NULL, $recursive = 1, $limit, $order = NULL, $page = 1){
        return $this->find('all', array('conditions' => $cond,
                                        'recursive' => $recursive,
                                        'limit' => $limit,
                                        'order' => $order,
                                        'page' => $page
                                        ));
   }
   
   function getItems($cond = NULL, $page, $limit, $fields = '*', $order = "`Item`.`ord` ASC"){
        return $this->find('all', array('conditions' => $cond,
                                        'limit' => $limit,
                                        'page' => $page,
                                        'fields' => $fields,
                                        'order' => $order));
   }
}