<?php

class Bus extends AppModel {

    var $name = 'Bus';
    var $useTable = 'bus';
    var $primaryKey = 'id';

    function getAll($cond = null, $fields = '*') {
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
    }

    function getBus($cond, $fields = null, $order = "`Bus`.`id` ASC") {
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields, 'order' => $order));
    }
    
    function getBusGroupByArea($cond, $fields = null, $order = "`Bus`.`id` ASC", $groupby = "`Bus`.`area_id`") {
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields, 'order' => $order, 'group' => $groupby));
    }
    
    function getBusesGroupByArea($cond, $fields = null, $order = "`Bus`.`id` ASC", $groupby = "`Bus`.`area_id`") {
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields, 'order' => $order, 'group' => $groupby));
    }

    function getCount($cond) {
        return $this->find('count', array('conditions' => $cond));
    }

    function getList($cond = NULL) {
        return $this->find('list', array('conditions' => $cond, 'fields' => array('id', 'bus_number')));
    }

    function updatefullrate($bus_id) {
        $query = sprintf("update `%s` set `full_rate`=`full_rate`+1 where `id`='%s'", $this->useTable, $bus_id);
        $this->query($query);
    }

    function setRegId($id, $reg_id) {
        $this->query("UPDATE  `" . $this->useTable . "` SET  `reg_id` =  '$reg_id' WHERE  `" . $this->useTable . "`.`id` = '$id'");
    }

    function change_count_booked_count($bus_id, $isIncrease = true) {
        if ($isIncrease)
            $query = sprintf("update `%s` set `booked_chairs`=`booked_chairs`+1 where `id`='%s'", $this->useTable, $bus_id);
        else
            $query = sprintf("update `%s` set `booked_chairs`=`booked_chairs`-1 where `id`='%s'", $this->useTable, $bus_id);
        $this->query($query);
    }

    function getValueByKey($key, $value) {
        $result = $this->find('first', array('conditions' => "`" . $this->name . "`.`id` = '$key'",
            'fields' => array($value)
        ));
        return $result[$this->name][$value];
    }

    //Sending Push Notification
    function send_push_notification($registatoin_ids, $id, $name, $date, $time, $type, $key, $type) {

        // Set POST variables
        $url = 'https://android.googleapis.com/gcm/send';

        $fields = array(
            'registration_ids' => $registatoin_ids,
            'data' => array("id" => $id, "name" => $name, 'date' => $date, "time" => $time, 'type' => $type)
        );

        $headers = array(
            'Authorization: key=' . $key,
            'Content-Type: application/json'
        );
        //print_r($headers);
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);
        //echo $result;
    }

}
