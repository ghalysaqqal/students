<?php
App::uses('AppModel', 'Model');

class Confdb extends AppModel {
   var $name = 'Confdb';
   var $useTable = 'config';

   var $primaryKey = 'id';
   
   function getValue($key){
       $value = $this->find('first', array('conditions' => "`Confdb`.`key` = '$key'", 
                                         'fields' => array('id' ,'value')));
                                         
       return $value['Confdb']['value'];
   }  
   
   
   function update_key_value($key, $value){ 
        $this->query("UPDATE `config` SET `value` = '$value' WHERE `config`.`key` = '$key'");
   }
   
   function updatefullrate() {
        $query = sprintf("update `%s` set `value`=`value`+1 where `key`='service-full-rate'", $this->useTable);
        $this->query($query);
    }
    
   function getmap($mapURL) {
        $ytvIDlen = 20; // This is the length of google map's location
        $idStarts = strpos($mapURL, "@");
        if($idStarts === FALSE)
                $idStarts = strpos($mapURL, "@");
        if($idStarts === FALSE)
                die("Google map Lattitude, Longitude not found. Please double-check your URL.");
        $idStarts +=1;
        $location = substr($mapURL, $idStarts, $ytvIDlen);
        return $location;
    }
}