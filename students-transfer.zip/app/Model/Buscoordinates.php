<?php

class Buscoordinates extends AppModel {

    var $name = 'Buscoordinates';
    var $useTable = 'bus_coordinates';
    var $primaryKey = 'id';

    function getAll($cond = null, $fields = '*') {
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
    }

    function getBus($cond, $fields = null) {
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
    }

    function update_coordinates($bus_id, $lat, $lng){
        $this->query("UPDATE `bus_coordinates` SET  `lng` =  '$lng', `lat` =  '$lat' WHERE  `bus_coordinates`.`bus_id` ='$bus_id'");
    }
    
    function deletebus($bus_id){
        $this->query("DELETE FROM  `bus_coordinates` WHERE `bus_coordinates`.`bus_id` = $bus_id");
    }

}
