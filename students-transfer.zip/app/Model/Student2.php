<?php
class Student2 extends AppModel {

    var $name = 'Student2';
    var $useTable = 'student2';
    var $primaryKey = 'id';
  
    function getAll($cond = null, $fields = '*') {
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
    }

    function getStudent($cond, $fields = null) {
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
    }

    function getCount($cond) {
        return $this->find('count', array('conditions' => $cond));
    }
    
    function getValueByKey($key, $value){
        $result = $this->find('first', array('conditions' => "`".$this->name."`.`id` = '$key'",
                                           'fields' => array($value)
                                           ));
        return $result[$this->name][$value];
   }
   
   function markAsDone($student_number){
       $this->query("UPDATE  `student2` SET  `done` =  '1' WHERE  `student2`.`student_number` = '$student_number'");
   }
  
}
