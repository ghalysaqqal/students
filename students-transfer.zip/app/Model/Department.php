<?php
class Department extends AppModel {
   var $name = 'Department';
   var $useTable = 'department';

   var $primaryKey = 'id';

   public $hasMany = array(
        
        'Departmenttext' => array(
            'className' => 'Departmenttext',
            'foreignKey'   => 'department_id',
            
        ),
        
   );
   
   function getItem($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   function getAll($cond = NULL){
        return $this->find('all', array('conditions' => $cond));
   }
   
    function getDepartmentsList($lang){
        return $this->find('list', array('conditions' => "`Departmenttext`.`local` = '$lang'", 
                                         'fields' => array('id', 'name'),
                                         'order' => "`Departmenttext`.`name` ASC",
                                         ));
    }
}