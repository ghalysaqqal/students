<?php
class Area extends AppModel {
   var $name = 'Area';
   var $useTable = 'area';

   var $primaryKey = 'id';
   
   public $hasMany = array(
        'Areatext' => array(
            'className' => 'Areatext',
            'foreignKey'   => 'area_id',
        ), 
   );
   
   
   function getArea($cond, $fields = '*'){
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
   }
   
   function getAll($cond = NULL, $fields = '*'){
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
   }
   
   function getList($cond = NULL){
        return $this->find('list', array('conditions' => $cond));
   }
}
