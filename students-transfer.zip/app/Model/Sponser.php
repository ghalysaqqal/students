<?php
class Sponser extends AppModel {
   var $name = 'Sponser';
   var $useTable = 'sponser';

   var $primaryKey = 'id';
   
   public $hasMany = array(
        
        'Sponsertext' => array(
            'className' => 'Sponsertext',
            'foreignKey'   => 'sponser_id',
            
        ),
        
   );
   
   
   function getSponser($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   function getAll($cond = NULL){
        return $this->find('all', array('conditions' => $cond));
   }
   
   function getSponsers($cond = NULL, $limit, $order, $page = 1){
        return $this->find('all', array('conditions' => $cond,
                                        'limit' => $limit,
                                        'order' => $order,
                                        'page' => $page
                                        ));
   }
}