<?php
class Page extends AppModel {
   var $name = 'Page';
   var $useTable = 'page';
   var $primaryKey = 'id';
   
    public $hasMany = array(
        'Pagetext' => array(
            'className' => 'Pagetext',
            'foreignKey'   => 'page_id',
            
        ),
   );
   
   function getPage($cond, $fields = '*'){
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
   }
   
   function getAll($cond = NULL, $fields = '*'){
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
   }
}