<?php
class Itemfile extends AppModel {
   var $name = 'Itemfile';
   var $useTable = 'item_file';

   var $primaryKey = 'id';
   
    public $hasMany = array(
        
        'Itemfiletext' => array(
            'className' => 'Itemfiletext',
            'foreignKey'   => 'item_file_id',
            
        ),
        
   );
   
   
   function getItem($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   function getAll($cond = NULL){
        return $this->find('all', array('conditions' => $cond));
   }

  
}