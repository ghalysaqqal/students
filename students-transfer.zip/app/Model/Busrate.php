<?php

class Busrate extends AppModel {

    var $name = 'Busrate';
    var $useTable = 'bus_rate';
    var $primaryKey = 'id';

    public $belongsTo = array(
        'Bus' => array(
            'className' => 'Bus',
            'foreignKey'   => 'bus_id'
        ),
   );
    
    function getRateSum($bus_id){
        $cond="`Busrate`.`bus_id` ='$bus_id'";
        $fields=array('SUM( rate ) AS rate');
        $bus=  $this->getRate($cond, $fields);
        return $bus[0]['rate'];
    }
    
    function getAll($cond = null, $fields = '*') {
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
    }

    function getRate($cond, $fields = null) {
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
    }
    
    function check($student_id, $bus_id){
        $result=  $this->find('count', array('conditions'=>"`Busrate`.`student_id` = '$student_id' AND `Busrate`.`bus_id` = '$bus_id'"));
        if($result>0)
            return true;
        else
            return false;
    }

    function updaterate($student_id, $bus_id, $rate_value){
        $this->query("UPDATE `".$this->useTable."` SET  `rate` =  '$rate_value' WHERE  `".$this->useTable."`.`bus_id` ='$bus_id' AND `".$this->useTable."`.`student_id` ='$student_id'");
    }
}
