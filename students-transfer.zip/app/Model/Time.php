<?php

class Time extends AppModel {

    var $name = 'Time';
    var $useTable = 'time';
    var $primaryKey = 'id';
    
    function getValueByKey($id, $key){
        $item = $this->find('first', array('conditions' => "`".$this->name."`.`id` = '$id'",
                                           'fields' => array($key)
                                           ));
        return $item[$this->name][$key];
    }

    function getAll($cond = null, $fields = '*') {
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
    }

    function getTime($cond, $fields = null) {
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
    }

    function getCount($cond) {
        return $this->find('count', array('conditions' => $cond));
    }
    
    function getList($type){
        return $this->find('list', array('conditions' => "`Time`.`type` LIKE '$type'", 
                                         'fields' => array('id', 'time')));
    }
}
