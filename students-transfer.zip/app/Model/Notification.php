<?php
class Notification extends AppModel {
   var $name = 'Notification';
   var $useTable = 'notification';

   var $primaryKey = 'id';
   
   function getAll($cond = null, $fields = '*', $order = "`Notification`.`id` DESC"){
       return $this->find('all', array('conditions' => $cond, 'fields' => $fields, 'order' => $order));
   }
   
   function getNotification($cond, $fields = null){
       return $this->find('first', array('conditions' => $cond, 'fields' => $fields ));
   }
   
   function getCount($cond= null){
       return $this->find('count', array('conditions' => $cond));
   }
   
   function getCountByUserId($user_id){
       $cond="`Usernoti`.`user_id` = '$user_id' AND `Usernoti`.`isRead` = '-1'";
       return $this->find('count', array('conditions' => $cond));
   }
   
   function markAsRead($noti_id, $type = 'NEWS', $student_id){
        $sql = "UPDATE `notification` SET `isRead` = '1' WHERE `notification`.`type_id` = '$noti_id' AND `notification`.`type` = '$type' AND `notification`.`student_id` = '$student_id'";
        $this->query($sql);
   }
   
   function isRead($item_id, $student_id, $type = 'NEWS'){ 
        $cond="`Notification`.`type_id` = '$item_id' AND `Notification`.`student_id` = '$student_id' AND `Notification`.`type` LIKE '$type'";
        $fields=array('isRead');
        $result=$this->getNotification($cond, $fields);
        
        if(empty($result)){
            return -1;
        }else
            return $result['Notification']['isRead'];
        return -1;
        
   }
}