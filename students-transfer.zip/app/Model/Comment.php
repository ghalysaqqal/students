<?php
class Comment extends AppModel {
   var $name = 'Comment';
   var $useTable = 'comment';

   var $primaryKey = 'id';
   
   public $belongsTo = array(
        
        'Itemtext' => array(
            'className' => 'Itemtext',
            'foreignKey'   => 'item_id',
            'fields' => array('name') 
        ),
        
   );
   
   
   function getComment($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   function getAll($cond = NULL){
        return $this->find('all', array('conditions' => $cond));
   }
   
   function getComments($cond = NULL, $fields = '*', $order = "`Comment`.`id` DESC", $limit = -1, $page = 1){
        return $this->find('all', array('conditions' => $cond,
                                        'limit' => $limit,
                                        'order' => $order,
                                        'page' => $page,
                                        'fields' => $fields
                                        ));
   }
}