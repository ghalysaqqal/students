<?php
class Sponsertext extends AppModel {
   var $name = 'Sponsertext';
   var $useTable = 'sponser_text';

   var $primaryKey = 'id';
   
    public $belongsTo = array(
        
        'Sponser' => array(
            'className' => 'Sponser',
            'foreignKey'   => 'sponser_id',
        ),
        
   );
   
   function getSponser($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   function getAll($cond = NULL, $fields = '*'){
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields,));
   }
   
   function getSponsers($cond, $fields = '*', $page, $limit, $order = "`Sponser`.`id` DESC"){
        return $this->find('all', array('conditions' => $cond,
                                        'limit' => $limit,
                                        'page' => $page,
                                        'fields' => $fields,
                                        'order' => $order 
                                        ));
   }
}