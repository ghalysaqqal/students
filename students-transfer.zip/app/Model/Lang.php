<?php
App::uses('AppModel', 'Model');

class Lang extends AppModel {
   var $name = 'Lang';
   var $useTable = 'language';

   var $primaryKey = 'id';
   
   function getLangs(){
        return $this->find('all');
   }
   
   function getList(){
        return $this->find('list', array('fields' => array('id', 'language')));
   }
}