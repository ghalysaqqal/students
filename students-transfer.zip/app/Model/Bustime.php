<?php

class Bustime extends AppModel {

    var $name = 'Bustime';
    var $useTable = 'bus_time';
    var $primaryKey = 'id';

    function getAll($cond = null, $fields = '*') {
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
    }

    function getTime($cond, $fields = null) {
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
    }
    
    function getListByBus($type, $bus_id){
        return $this->find('list', array('conditions' => "`Bustime`.`type` LIKE '$type' AND `Bustime`.`bus_id` = '$bus_id'", 
                                         'fields' => array('id', 'time_id')));
    }
  
    function updateTimes($time_id, $time){
        $this->query("UPDATE  `bus_time` SET  `time` =  '$time' WHERE  `bus_time`.`time_id` =$time_id");
    }
}
