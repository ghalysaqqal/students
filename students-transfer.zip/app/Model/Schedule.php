<?php

class Schedule extends AppModel {

    var $name = 'Schedule';
    var $useTable = 'schedule';
    var $primaryKey = 'id';
  
    public $belongsTo = array(
        'Student' => array(
            'className' => 'Student',
            'foreignKey' => 'student_id',
            'fields'=>array('name', 'lat', 'lng')
        ),
    );

    function getAll($cond = null, $fields = '*') {
        return $this->find('all', array('conditions' => $cond));
    }

    function getSchedule($cond, $fields = null, $order = "`Schedule`.`id` DESC") {
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields, 'order' => $order));
    }
    
    function getSchedules($cond, $fields = null, $page = 1, $limit = -1, $order = "`Schedule`.`id` DESC") {
        return $this->find('all', array('conditions' => $cond, 
                                          'fields' => $fields, 
                                          'order' => $order,
                                          'page' => $page,
                                          'limit' => $limit));
    }

    function getCount($cond) {
        return $this->find('count', array('conditions' => $cond));
    }
    
    function emptyDates($id, $date){
        $this->query("DELETE FROM `".$this->useTable."` WHERE `".$this->useTable."`.`student_id` = '$id' AND `".$this->useTable."`.`date` > '$date' ");
    }
    
    function emptyDatesByDay($id, $date, $day){
        $this->query("DELETE FROM `".$this->useTable."` WHERE `".$this->useTable."`.`student_id` = '$id' AND `".$this->useTable."`.`date` > '$date' AND `".$this->useTable."`.`day` like '$day' ");
    }
    
    function changestatus($id, $column, $date){
        $this->query("UPDATE `schedule` SET  `$column` =  '1', `risetime` =  '$date' WHERE  `schedule`.`id` =$id");
    }
    
    function updateTimes($time_id, $time){
        $current_date=date('Y-m-d');
        $this->query("UPDATE `schedule` SET  `time` =  '$time' WHERE  `schedule`.`time_id` ='$time_id' AND `schedule`.`date` > '$current_date' ");
    }
    
    function changeBus($student_id, $bus_id){
        $current_date=date('Y-m-d');
        $this->query("UPDATE `schedule` SET  `bus_id` =  '$bus_id' WHERE  `schedule`.`student_id` ='$student_id' AND `schedule`.`date` > '$current_date' ");
    }
}
