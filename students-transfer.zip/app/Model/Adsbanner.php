<?php
App::uses('AppModel', 'Model');

class Adsbanner extends AppModel {
	var $name = 'Adsbanner';
	var $useTable = 'ads_banner';

	var $primaryKey = 'adsBID';
    
    function getBanner($cond, $fields = '*'){
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields,));
   }
}