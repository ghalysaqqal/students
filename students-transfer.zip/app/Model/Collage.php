<?php
class Collage extends AppModel {
   var $name = 'Collage';
   var $useTable = 'collage';

   var $primaryKey = 'id';
   
   public $hasMany = array(
        'Collagetext' => array(
            'className' => 'Collagetext',
            'foreignKey'   => 'collage_id',
        ), 
   );
   
   
   function getCollage($cond, $fields = '*'){
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
   }
   
   function getAll($cond = NULL, $fields = '*'){
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
   }
   
   function getList($cond = NULL){
        return $this->find('list', array('conditions' => $cond));
   }
}
