<?php
App::uses('AppModel', 'Model');

class Adszone extends AppModel {
	var $name = 'Adszone';
	var $useTable = 'ads_zone';

	var $primaryKey = 'adsZID';
}