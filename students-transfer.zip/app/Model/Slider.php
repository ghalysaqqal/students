<?php
class Slider extends AppModel {
   var $name = 'Slider';
   var $useTable = 'slider';

   var $primaryKey = 'id';
   
    public $hasMany = array(
        
        'Slidertext' => array(
            'className' => 'Slidertext',
            'foreignKey'   => 'slider_id',
            
        ),
        
   );
   
   function getSlider($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   function getAll($cond = NULL){
        return $this->find('all', array('conditions' => $cond, 'order' => "`Slider`.`ord` ASC"));
   }
}