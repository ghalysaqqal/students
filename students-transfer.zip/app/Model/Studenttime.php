<?php

class Studenttime extends AppModel {

    var $name = 'Studenttime';
    var $useTable = 'student_times';
    var $primaryKey = 'id';

    function emptyTimes($id){
        $this->query("DELETE FROM `".$this->useTable."` WHERE `".$this->useTable."`.`student_id` = $id");
    }
    
    function getTime($cond, $fields = null) {
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
    }
    
    function getTimes($cond, $fields = null) {
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
    }
    
    function updateGoingTimes($time_id, $time){
        $this->query("UPDATE `student_times` SET  `going` = '$time' WHERE  `student_times`.`going_id` =$time_id");
    }
    
    function updateReturnTimes($time_id, $time){
        $this->query("UPDATE `student_times` SET  `return` = '$time' WHERE  `student_times`.`return_id` =$time_id");
    }
}
