<?php
class Statistics extends AppModel {
   var $name = 'Statistics';
   var $useTable = 'statistics';

   var $primaryKey = 'id';
   
   function updatevalue( $column, $value = 1, $type = true){
        if($type)
            $query = sprintf ("update `%s` set `%s`=`%s`+%s", $this->useTable, $column, $column, $value);
        else
            $query = sprintf ("update `%s` set `%s`=`%s`-%s", $this->useTable, $column, $column, $value);
	$this->query($query);
   }
   
   function getLastValue($col){
        $result = $this->find('first', array('conditions' => null, 'fields' => array($col)));
        return $result[$this->name][$col] +1;
   }
   
   function getItem($cond = null, $fields = '*'){
       return $this->find('first', array('conditions' => $cond, 'fields' => $fields,));
   }
   
   function getAll($cond = null, $fields = '*'){
       return $this->find('all', array('conditions' => $cond, 'fields' => $fields,));
   }
}