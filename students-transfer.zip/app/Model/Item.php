<?php

class Item extends AppModel {

    var $name = 'Item';
    var $useTable = 'item';
    var $primaryKey = 'id';
    public $hasMany = array(
        'Itemtext' => array(
            'className' => 'Itemtext',
            'foreignKey' => 'item_id',
        ),
    );

    function getValueByKey($key, $value) {
        $result = $this->find('first', array('conditions' => "`" . $this->name . "`.`id` = '$key'",
            'fields' => array($value)
        ));
        return $result[$this->name][$value];
    }

    function getItem($cond, $fields = '*') {
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields,));
    }

    function getAll($cond = NULL, $recursive = 1) {
        return $this->find('all', array('conditions' => $cond,
                    'recursive' => $recursive));
    }

    function getItems($cond = NULL, $page = 1, $limit = -1, $fields = '*', $order = "`Item`.`id` DESC") {
        return $this->find('all', array('conditions' => $cond,
                    'limit' => $limit,
                    'page' => $page,
                    'fields' => $fields,
                    'order' => $order));
    }

    function increase_view($id) {
        $query = sprintf("update `%s` set `counterView`=`counterView`+1 where `id`='%s'", $this->useTable, $id);
        $this->query($query);
    }

}
