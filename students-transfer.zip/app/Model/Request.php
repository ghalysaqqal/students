<?php
class Request extends AppModel {
   var $name = 'Request';
   var $useTable = 'request';

   var $primaryKey = 'id';
   
   function getRequests(){
       return $this->find('all', array('order' => "`Request`.`id` DESC"));
   }
   
   function getRequest($id){
       return $this->find('first', array('conditions' => "`Request`.`id` = '$id'"));
   }
   
   
}