<?php
class Areatext extends AppModel {
   var $name = 'Areatext';
   var $useTable = 'area_text';

   var $primaryKey = 'id';
   
    public $belongsTo = array(
        'Area' => array(
            'className' => 'Area',
            'foreignKey'   => 'area_id',
        ),
   );
   
   function getArea($cond, $fields = '*'){
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
   }
   
   
   function getAll($cond = NULL, $fields = '*', $order = '`Areatext`.`area` ASC') {
        return $this->find('all', array('conditions' => $cond,
                                        'fields' => $fields,
                                        'order' => $order));
   }
   
   function getList($cond = NULL){
        return $this->find('list', array('conditions' => $cond,
                                         'fields' => array('area_id', 'area'),
                                         'order' => "`Areatext`.`id` ASC"
                                         ));
   }
   
   function getValueByKey($key, $value){
        $result = $this->find('first', array('conditions' => "`".$this->name."`.`area_id` = '$key' AND `".$this->name."`.`local` = '".LANG."'",
                                           'fields' => array($value)
                                           ));
        return $result[$this->name][$value];
   }

}