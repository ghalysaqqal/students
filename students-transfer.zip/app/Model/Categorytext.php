<?php
class Categorytext extends AppModel {
   var $name = 'Categorytext';
   var $useTable = 'category_text';

   var $primaryKey = 'id';
   
    public $belongsTo = array(
        
        'Category' => array(
            'className' => 'Category',
            'foreignKey'   => 'category_id',
            
        ),
        
   );
    
    function getItemByColomn($id, $colomn){
        $item = $this->find('first', array('conditions' => "`Categorytext`.`category_id` = '$id' AND `Categorytext`.`local` = '".LANG."'",
                                           'fields' => array($colomn)
                                           ));
        return $item['Categorytext'][$colomn];
   }
   
   function getCategory($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   
   function getAll($cond = NULL, $fields = '*'){
        return $this->find('all', array('conditions' => $cond,
                                        'fields' => $fields
                                        ));
   }
   
   function getList($cond = NULL){
        return $this->find('list', array('conditions' => $cond,
                                         'fields' => array('category_id', 'name'),
                                         'order' => "`Categorytext`.`name` ASC"
                                         ));
   }

}