<?php
class Itemtext extends AppModel {
   var $name = 'Itemtext';
   var $useTable = 'item_text';

   var $primaryKey = 'id';
   
    public $belongsTo = array(
        
        'Item' => array(
            'className' => 'Item',
            'foreignKey'   => 'item_id',
            
        ),
        
   );
   
   function getValueByKey($key, $value){
        $result = $this->find('first', array('conditions' => "`".$this->name."`.`item_id` = '$key' AND `".$this->name."`.`local` = '".LANG."'",
                                           'fields' => array($value)
                                           ));
        return $result[$this->name][$value];
   }
   
   function getItem($cond, $fields = '*'){
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
   }
   
   function getAll($cond = NULL, $fields = '*'){
        return $this->find('all', array('conditions' => $cond,
                                        'fields' => $fields
                                        ));
   }
   
    function get_items($cond = NULL, $recursive = 1, $limit, $order = NULL, $page = 1){
        return $this->find('all', array('conditions' => $cond,
                                        'recursive' => $recursive,
                                        'limit' => $limit,
                                        'order' => $order,
                                        'page' => $page
                                        ));
   }
   
   function getItems($cond = NULL, $fields = '*', $page = 1, $limit= -1, $order = "`Item`.`id` DESC", $group = NULL){
        return $this->find('all', array('conditions' => $cond,
                                        'limit' => $limit,
                                        'page' => $page,
                                        'fields' => $fields,
                                        'order' => $order,
                                        'group' => $group
                                        ));
   }
}