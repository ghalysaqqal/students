<?php
class Departmenttext extends AppModel {
   var $name = 'Departmenttext';
   var $useTable = 'department_text';

   var $primaryKey = 'id';
   
   var $title = NULL;

    public $belongsTo = array(
        'Department' => array(
            'className' => 'Department',
            'foreignKey'   => 'department_id',
            
        ),        
   );
   
   function getItem($cond, $fields = '*'){
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
   }
   
   function getAll($cond = NULL, $fields = '*'){
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
   }
    
   function getDepartmentsList($lang){
        return $this->find('list', array('conditions' => "`Departmenttext`.`local` = '$lang'", 
                                         'fields' => array('department_id', 'name'),
                                         'order' => "`Departmenttext`.`name` ASC",
                                         ));
    }
    
    function getDeptNameById($id, $lang){
        $dept = $this->find('first', array('conditions' => "`Departmenttext`.`department_id` = '$id' AND `Departmenttext`.`local` = '$lang'",
                                           'fields' => array('name')
                                           ));
        return $dept['Departmenttext']['name'];
   }
}