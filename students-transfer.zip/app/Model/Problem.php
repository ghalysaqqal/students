<?php
class Problem extends AppModel {
   var $name = 'Problem';
   var $useTable = 'problem';

   var $primaryKey = 'id';
   
   public $belongsTo = array(
        'Bus' => array(
            'className' => 'Bus',
            'foreignKey'   => 'bus_id',
            'fields' => array('bus_number', )
        ), 
   );
   
   function getProblems(){
       return $this->find('all', array('order' => "`Problem`.`id` DESC"));
   }
   
   function getProblem($id){
       return $this->find('first', array('conditions' => "`Problem`.`id` = '$id'"));
   }
   
   
}