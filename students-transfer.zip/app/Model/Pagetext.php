<?php
class Pagetext extends AppModel {
   var $name = 'Pagetext';
   var $useTable = 'page_text';
   var $primaryKey = 'id';
   
   public $belongsTo = array(
        'Page' => array(
            'className' => 'Page',
            'foreignKey' => 'page_id',
        ),        
   );
   
   function getPage($cond, $fields = '*'){
        return $this->find('first', array('conditions' => $cond, 'fields' => $fields));
   }
   
   function getAll($cond = NULL, $fields = '*'){
        return $this->find('all', array('conditions' => $cond, 'fields' => $fields));
   }
   
   function getPages($cond = NULL, $fields = '*', $page = 1, $limit = -1, $order = "`Pagetext`.`title` ASC"){
        return $this->find('all', array('conditions' => "`Pagetext`.`local` = '$lang' AND `Page`.`active` = '1' ",
                                        'limit' => $limit,
                                        'page' => $page,
                                        'fields' => array('Page.id', 'Pagetext.title'),
                                        'order' => "`Page`.`id` DESC"));
   }
   
   function getValueByKey($key, $value){
        $result = $this->find('first', array('conditions' => "`".$this->name."`.`page_id` = '$key' AND `".$this->name."`.`local` = '".LANG."'",
                                           'fields' => array($value)
                                           ));
        return $result[$this->name][$value];
   }
}