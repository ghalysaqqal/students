<?php
class User extends AppModel {
   var $name = 'User';
   var $useTable = 'user';

   var $primaryKey = 'id';
   
   function getUsers($cond, $limit, $page){
       return $this->find('all', array('conditions' => $cond,
                                        'limit' => $limit,
                                        'page' => $page
                                        ));
   }
   
   function getAllUsers($cond = NULL){
       return $this->find('all', array('conditions' => $cond));
   }
   
   function getUser($id, $fields = NULL){
       return $this->find('first', array('conditions' => "`User`.`id` = '$id'", 
                                         'fields' => $fields 
                                         ));
   }
   
   
   function checkUserByFullname($name){
        return $this->find('first', array('conditions' => "`User`.`fullname` LIKE '$name'" ));
   }  

   function getCount($cond){
        return $this->find('count', array('conditions' => $cond));
   }
   
   function getData($cond){
        return $this->find('all', array('conditions' => $cond));
   }
   
   function getUserEmail($id){
        return $this->find('first', array('conditions' => "`User`.`id` = '".$id."'",
                                          'fields' => array('id', 'email', 'fullname')
                                           ));
   }
   
   function getFullnameUserById($user_id){
        $user = $this->find('first', array('conditions' => "`User`.`id` = '$user_id'",
                                           'fields' => array('fullname')
                                           ));
        return $user['User']['fullname'];
   }


}