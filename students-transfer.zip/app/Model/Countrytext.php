<?php
class Countrytext extends AppModel {
   var $name = 'Countrytext';
   var $useTable = 'country_text';

   var $primaryKey = 'id';
   
    public $belongsTo = array(
        
        'Country' => array(
            'className' => 'Country',
            'foreignKey'   => 'country_id',
            
        ),
        
   );
   
   function getCountry($cond){
        return $this->find('first', array('conditions' => $cond));
   }
   
   
   function getAll($cond = NULL, $fields = '*', $order = '`Countrytext`.`country` ASC') {
        return $this->find('all', array('conditions' => $cond,
                                        'fields' => $fields,
                                        'order' => $order));
   }
   
   function getList($cond = NULL){
        return $this->find('list', array('conditions' => $cond,
                                         'fields' => array('country_id', 'country'),
                                         'order' => "`Countrytext`.`country` ASC"
                                         ));
   }

}